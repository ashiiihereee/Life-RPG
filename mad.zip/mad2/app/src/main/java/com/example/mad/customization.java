package com.example.mad;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class customization extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;

    private ListView customizationListView;
    private ArrayList<CustomizationAdapter.CustomizationItem> customizationItems;
    private CustomizationAdapter customizationAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customization);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(this, "Player not found.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        TextView btnBack = findViewById(R.id.btnBack);
        customizationListView = findViewById(R.id.customizationListView);

        btnBack.setOnClickListener(v -> finish());

        customizationItems = new ArrayList<>();

        customizationAdapter = new CustomizationAdapter(
                this,
                customizationItems,
                item -> equipItem(item.itemId, item.category)
        );

        customizationListView.setAdapter(customizationAdapter);

        loadCustomizationItems();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (db != null && userId != -1) {
            loadCustomizationItems();
        }
    }

    private void loadCustomizationItems() {

        customizationItems.clear();

        Cursor cursor = db.rawQuery(
                "SELECT s.item_id, s.name, s.category, s.price, s.icon, " +
                        "s.description, s.rarity, o.equipped " +
                        "FROM shop_items s " +
                        "INNER JOIN owned_items o ON s.item_id = o.item_id " +
                        "WHERE o.user_id = ? " +
                        "ORDER BY s.category ASC, s.item_id ASC",
                new String[]{String.valueOf(userId)}
        );

        while (cursor.moveToNext()) {

            int itemId = cursor.getInt(
                    cursor.getColumnIndexOrThrow("item_id")
            );

            String name = cursor.getString(
                    cursor.getColumnIndexOrThrow("name")
            );

            String category = cursor.getString(
                    cursor.getColumnIndexOrThrow("category")
            );

            int price = cursor.getInt(
                    cursor.getColumnIndexOrThrow("price")
            );

            String icon = cursor.getString(
                    cursor.getColumnIndexOrThrow("icon")
            );

            String description = cursor.getString(
                    cursor.getColumnIndexOrThrow("description")
            );

            String rarity = cursor.getString(
                    cursor.getColumnIndexOrThrow("rarity")
            );

            boolean equipped = cursor.getInt(
                    cursor.getColumnIndexOrThrow("equipped")
            ) == 1;

            customizationItems.add(
                    new CustomizationAdapter.CustomizationItem(
                            itemId,
                            name,
                            category,
                            price,
                            icon,
                            description,
                            rarity,
                            equipped
                    )
            );
        }

        cursor.close();

        customizationAdapter.notifyDataSetChanged();
    }

    private void equipItem(int itemId, String category) {

        db.beginTransaction();

        try {

            db.execSQL(
                    "UPDATE owned_items SET equipped = 0 " +
                            "WHERE user_id = ? " +
                            "AND item_id IN " +
                            "(SELECT item_id FROM shop_items WHERE category = ?)",
                    new String[]{
                            String.valueOf(userId),
                            category
                    }
            );

            db.execSQL(
                    "UPDATE owned_items SET equipped = 1 " +
                            "WHERE user_id = ? AND item_id = ?",
                    new String[]{
                            String.valueOf(userId),
                            String.valueOf(itemId)
                    }
            );

            db.setTransactionSuccessful();

            Toast.makeText(
                    this,
                    "Equipped successfully!",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Could not equip item.",
                    Toast.LENGTH_SHORT
            ).show();

        } finally {

            db.endTransaction();
        }

        loadCustomizationItems();
    }
}
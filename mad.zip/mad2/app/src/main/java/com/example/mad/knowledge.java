package com.example.mad;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class knowledge extends AppCompatActivity {

    private LinearLayout notesContainer;
    private TextView txtNoteCount;
    private EditText searchNotes;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;

    private String selectedCategory = "ALL";

    private final String[] categories = {
            "STUDY",
            "IDEAS",
            "PERSONAL"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_knowledge);


        // =====================================
        // GET USER ID
        // =====================================

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );


        if (userId == -1) {

            finish();

            return;
        }


        // =====================================
        // DATABASE
        // =====================================

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();


        // =====================================
        // CONNECT XML
        // =====================================

        notesContainer =
                findViewById(
                        R.id.notesContainer
                );

        txtNoteCount =
                findViewById(
                        R.id.txtNoteCount
                );

        searchNotes =
                findViewById(
                        R.id.searchNotes
                );

        TextView btnBack =
                findViewById(
                        R.id.btnBack
                );

        TextView btnNewNote =
                findViewById(
                        R.id.btnNewNote
                );

        TextView categoryAll =
                findViewById(
                        R.id.categoryAll
                );

        TextView categoryStudy =
                findViewById(
                        R.id.categoryStudy
                );

        TextView categoryIdeas =
                findViewById(
                        R.id.categoryIdeas
                );

        TextView categoryPersonal =
                findViewById(
                        R.id.categoryPersonal
                );


        // =====================================
        // MIGRATE OLD NOTES
        // =====================================

        migrateOldNotes();


        // =====================================
        // LOAD NOTES
        // =====================================

        loadNotes();


        // =====================================
        // BACK
        // =====================================

        btnBack.setOnClickListener(
                view -> finish()
        );


        // =====================================
        // NEW NOTE
        // =====================================

        btnNewNote.setOnClickListener(
                view -> showNoteDialog(null)
        );


        // =====================================
        // SEARCH
        // =====================================

        searchNotes.addTextChangedListener(
                new TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count) {

                        loadNotes();
                    }

                    @Override
                    public void afterTextChanged(
                            Editable s) {
                    }
                }
        );


        // =====================================
        // CATEGORIES
        // =====================================

        categoryAll.setOnClickListener(
                view -> {

                    selectedCategory =
                            "ALL";

                    updateCategoryButtons(
                            categoryAll,
                            categoryStudy,
                            categoryIdeas,
                            categoryPersonal
                    );

                    loadNotes();
                }
        );


        categoryStudy.setOnClickListener(
                view -> {

                    selectedCategory =
                            "STUDY";

                    updateCategoryButtons(
                            categoryAll,
                            categoryStudy,
                            categoryIdeas,
                            categoryPersonal
                    );

                    loadNotes();
                }
        );


        categoryIdeas.setOnClickListener(
                view -> {

                    selectedCategory =
                            "IDEAS";

                    updateCategoryButtons(
                            categoryAll,
                            categoryStudy,
                            categoryIdeas,
                            categoryPersonal
                    );

                    loadNotes();
                }
        );


        categoryPersonal.setOnClickListener(
                view -> {

                    selectedCategory =
                            "PERSONAL";

                    updateCategoryButtons(
                            categoryAll,
                            categoryStudy,
                            categoryIdeas,
                            categoryPersonal
                    );

                    loadNotes();
                }
        );
    }


    // =========================================
    // UPDATE CATEGORY BUTTONS
    // =========================================

    private void updateCategoryButtons(
            TextView all,
            TextView study,
            TextView ideas,
            TextView personal) {

        setCategoryButton(
                all,
                selectedCategory.equals("ALL")
        );

        setCategoryButton(
                study,
                selectedCategory.equals("STUDY")
        );

        setCategoryButton(
                ideas,
                selectedCategory.equals("IDEAS")
        );

        setCategoryButton(
                personal,
                selectedCategory.equals("PERSONAL")
        );
    }


    private void setCategoryButton(
            TextView button,
            boolean selected) {

        if (selected) {

            button.setTextColor(
                    Color.rgb(
                            53,
                            32,
                            56
                    )
            );

            button.setBackgroundColor(
                    Color.rgb(
                            232,
                            169,
                            216
                    )
            );

        } else {

            button.setTextColor(
                    Color.rgb(
                            220,
                            201,
                            229
                    )
            );

            button.setBackgroundColor(
                    Color.rgb(
                            48,
                            38,
                            64
                    )
            );
        }
    }


    // =========================================
    // SHOW CREATE / EDIT DIALOG
    // =========================================

    private void showNoteDialog(
            NoteData existingNote) {

        boolean editing =
                existingNote != null;


        LinearLayout layout =
                new LinearLayout(this);

        layout.setOrientation(
                LinearLayout.VERTICAL
        );

        layout.setPadding(
                45,
                10,
                45,
                5
        );


        // =====================================
        // TITLE
        // =====================================

        EditText title =
                new EditText(this);

        title.setHint(
                "Note title"
        );

        title.setSingleLine(true);

        if (editing) {

            title.setText(
                    existingNote.title
            );
        }

        layout.addView(
                title
        );


        // =====================================
        // CONTENT
        // =====================================

        EditText content =
                new EditText(this);

        content.setHint(
                "Write your knowledge..."
        );

        content.setMinLines(5);

        content.setGravity(
                Gravity.TOP
        );

        if (editing) {

            content.setText(
                    existingNote.content
            );
        }

        LinearLayout.LayoutParams contentParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        contentParams.setMargins(
                0,
                8,
                0,
                8
        );

        content.setLayoutParams(
                contentParams
        );

        layout.addView(
                content
        );


        // =====================================
        // CATEGORY
        // =====================================

        TextView categoryLabel =
                new TextView(this);

        categoryLabel.setText(
                "CATEGORY"
        );

        categoryLabel.setTextSize(
                10
        );

        categoryLabel.setTextColor(
                Color.DKGRAY
        );

        categoryLabel.setTypeface(
                null,
                Typeface.BOLD
        );

        layout.addView(
                categoryLabel
        );


        Spinner categorySpinner =
                new Spinner(this);

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        categories
                );

        categorySpinner.setAdapter(
                adapter
        );


        if (editing) {

            for (int i = 0; i < categories.length; i++) {

                if (categories[i].equals(
                        existingNote.category
                )) {

                    categorySpinner.setSelection(
                            i
                    );

                    break;
                }
            }
        }

        layout.addView(
                categorySpinner
        );


        // =====================================
        // FAVORITE
        // =====================================

        android.widget.CheckBox favorite =
                new android.widget.CheckBox(this);

        favorite.setText(
                "⭐ Mark as favorite"
        );

        if (editing) {

            favorite.setChecked(
                    existingNote.favorite
            );
        }

        layout.addView(
                favorite
        );


        // =====================================
        // LEARNED
        // =====================================

        android.widget.CheckBox learned =
                new android.widget.CheckBox(this);

        learned.setText(
                "🧠 Mark as learned"
        );

        if (editing) {

            learned.setChecked(
                    existingNote.learned
            );
        }

        layout.addView(
                learned
        );


        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);


        builder.setTitle(
                editing
                        ? "EDIT KNOWLEDGE"
                        : "NEW KNOWLEDGE"
        );


        builder.setView(
                layout
        );


        builder.setNegativeButton(
                "CANCEL",
                null
        );


        builder.setPositiveButton(
                editing
                        ? "SAVE CHANGES"
                        : "SAVE",
                (dialog, which) -> {

                    String noteTitle =
                            title.getText()
                                    .toString()
                                    .trim();

                    String noteContent =
                            content.getText()
                                    .toString()
                                    .trim();

                    String category =
                            categorySpinner
                                    .getSelectedItem()
                                    .toString();

                    boolean isFavorite =
                            favorite.isChecked();

                    boolean isLearned =
                            learned.isChecked();


                    if (noteTitle.isEmpty()) {

                        Toast.makeText(
                                this,
                                "Enter a title.",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }


                    if (editing) {

                        updateNote(
                                existingNote.id,
                                noteTitle,
                                noteContent,
                                category,
                                isFavorite,
                                isLearned
                        );

                    } else {

                        saveNote(
                                noteTitle,
                                noteContent,
                                category,
                                isFavorite,
                                isLearned
                        );
                    }
                }
        );


        builder.show();
    }


    // =========================================
    // SAVE NOTE
    // =========================================

    private void saveNote(
            String title,
            String content,
            String category,
            boolean favorite,
            boolean learned) {

        ContentValues values =
                new ContentValues();

        values.put(
                "user_id",
                userId
        );

        values.put(
                "title",
                title
        );

        values.put(
                "content",
                content
        );

        values.put(
                "category",
                category
        );

        values.put(
                "is_favorite",
                favorite ? 1 : 0
        );

        values.put(
                "is_learned",
                learned ? 1 : 0
        );

        String now =
                getCurrentDate();

        values.put(
                "created_date",
                now
        );

        values.put(
                "updated_date",
                now
        );


        long id =
                db.insert(
                        "knowledge",
                        null,
                        values
                );


        if (id != -1) {

            loadNotes();

            Toast.makeText(
                    this,
                    "Knowledge saved.",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            Toast.makeText(
                    this,
                    "Could not save knowledge.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =========================================
    // UPDATE NOTE
    // =========================================

    private void updateNote(
            long id,
            String title,
            String content,
            String category,
            boolean favorite,
            boolean learned) {

        ContentValues values =
                new ContentValues();

        values.put(
                "title",
                title
        );

        values.put(
                "content",
                content
        );

        values.put(
                "category",
                category
        );

        values.put(
                "is_favorite",
                favorite ? 1 : 0
        );

        values.put(
                "is_learned",
                learned ? 1 : 0
        );

        values.put(
                "updated_date",
                getCurrentDate()
        );


        int updated =
                db.update(
                        "knowledge",
                        values,
                        "knowledge_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(id),
                                String.valueOf(userId)
                        }
                );


        if (updated > 0) {

            loadNotes();

            Toast.makeText(
                    this,
                    "Knowledge updated.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =========================================
    // LOAD NOTES
    // =========================================

    private void loadNotes() {

        notesContainer.removeAllViews();


        String search =
                searchNotes == null
                        ? ""
                        : searchNotes.getText()
                          .toString()
                          .trim();


        ArrayList<NoteData> notes =
                new ArrayList<>();


        String selection =
                "user_id = ?";

        ArrayList<String> args =
                new ArrayList<>();

        args.add(
                String.valueOf(userId)
        );


        if (!selectedCategory.equals("ALL")) {

            selection +=
                    " AND category = ?";

            args.add(
                    selectedCategory
            );
        }


        if (!search.isEmpty()) {

            selection +=
                    " AND (title LIKE ? OR content LIKE ? OR category LIKE ?)";

            String searchValue =
                    "%" +
                            search +
                            "%";

            args.add(searchValue);
            args.add(searchValue);
            args.add(searchValue);
        }


        Cursor cursor =
                db.query(
                        "knowledge",
                        null,
                        selection,
                        args.toArray(
                                new String[0]
                        ),
                        null,
                        null,
                        "is_favorite DESC, updated_date DESC"
                );


        while (cursor.moveToNext()) {

            long id =
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    "knowledge_id"
                            )
                    );

            String title =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "title"
                            )
                    );

            String content =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "content"
                            )
                    );

            String category =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "category"
                            )
                    );

            boolean favorite =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "is_favorite"
                            )
                    ) == 1;

            boolean learned =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "is_learned"
                            )
                    ) == 1;


            NoteData note =
                    new NoteData(
                            id,
                            title,
                            content,
                            category,
                            favorite,
                            learned
                    );

            notes.add(note);
        }


        cursor.close();


        for (NoteData note : notes) {

            addNoteCard(
                    note
            );
        }


        updateCount();
    }


    // =========================================
    // ADD NOTE CARD
    // =========================================

    private void addNoteCard(
            NoteData note) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL
        );

        card.setPadding(
                18,
                15,
                18,
                15
        );


        GradientDrawable background =
                new GradientDrawable();

        background.setColor(
                Color.rgb(
                        43,
                        34,
                        58
                )
        );

        background.setCornerRadius(
                22
        );


        card.setBackground(
                background
        );


        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );


        params.setMargins(
                0,
                0,
                0,
                10
        );


        card.setLayoutParams(
                params
        );


        // =====================================
        // TITLE ROW
        // =====================================

        LinearLayout titleRow =
                new LinearLayout(this);

        titleRow.setOrientation(
                LinearLayout.HORIZONTAL
        );

        titleRow.setGravity(
                Gravity.CENTER_VERTICAL
        );


        TextView titleView =
                new TextView(this);

        titleView.setText(
                note.title
        );

        titleView.setTextColor(
                Color.WHITE
        );

        titleView.setTextSize(
                16
        );

        titleView.setTypeface(
                null,
                Typeface.BOLD
        );


        LinearLayout.LayoutParams titleParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                );

        titleView.setLayoutParams(
                titleParams
        );


        TextView favoriteView =
                new TextView(this);

        favoriteView.setText(
                note.favorite
                        ? "⭐"
                        : ""
        );

        favoriteView.setTextSize(
                18
        );


        titleRow.addView(
                titleView
        );

        titleRow.addView(
                favoriteView
        );


        // =====================================
        // CATEGORY
        // =====================================

        TextView categoryView =
                new TextView(this);

        categoryView.setText(
                note.category
        );

        categoryView.setTextColor(
                Color.rgb(
                        232,
                        169,
                        216
                )
        );

        categoryView.setTextSize(
                9
        );

        categoryView.setTypeface(
                null,
                Typeface.BOLD
        );

        categoryView.setPadding(
                0,
                5,
                0,
                5
        );


        // =====================================
        // CONTENT
        // =====================================

        TextView contentView =
                new TextView(this);

        contentView.setText(
                note.content
        );

        contentView.setTextColor(
                Color.rgb(
                        190,
                        177,
                        199
                )
        );

        contentView.setTextSize(
                12
        );

        contentView.setMaxLines(
                3
        );


        // =====================================
        // STATUS
        // =====================================

        TextView statusView =
                new TextView(this);

        if (note.learned) {

            statusView.setText(
                    "✓ LEARNED"
            );

            statusView.setTextColor(
                    Color.rgb(
                            156,
                            220,
                            174
                    )
            );

        } else {

            statusView.setText(
                    "○ NOT LEARNED"
            );

            statusView.setTextColor(
                    Color.rgb(
                            150,
                            137,
                            160
                    )
            );
        }

        statusView.setTextSize(
                9
        );

        statusView.setTypeface(
                null,
                Typeface.BOLD
        );

        statusView.setPadding(
                0,
                7,
                0,
                0
        );


        card.addView(
                titleRow
        );

        card.addView(
                categoryView
        );

        card.addView(
                contentView
        );

        card.addView(
                statusView
        );


        // =====================================
        // CLICK NOTE
        // =====================================

        card.setOnClickListener(
                view -> showNoteDetails(
                        note
                )
        );


        notesContainer.addView(
                card
        );
    }


    // =========================================
    // NOTE DETAILS
    // =========================================

    private void showNoteDetails(
            NoteData note) {

        LinearLayout layout =
                new LinearLayout(this);

        layout.setOrientation(
                LinearLayout.VERTICAL
        );

        layout.setPadding(
                30,
                5,
                30,
                5
        );


        TextView category =
                new TextView(this);

        category.setText(
                "CATEGORY: " +
                        note.category
        );

        category.setTextSize(
                10
        );

        category.setTextColor(
                Color.DKGRAY
        );

        category.setTypeface(
                null,
                Typeface.BOLD
        );


        TextView content =
                new TextView(this);

        content.setText(
                note.content
        );

        content.setTextSize(
                14
        );

        content.setTextColor(
                Color.DKGRAY
        );

        content.setPadding(
                0,
                15,
                0,
                15
        );


        TextView status =
                new TextView(this);

        status.setText(
                note.learned
                        ? "✓ LEARNED"
                        : "○ NOT LEARNED"
        );

        status.setTextSize(
                11
        );

        status.setTypeface(
                null,
                Typeface.BOLD
        );


        layout.addView(
                category
        );

        layout.addView(
                content
        );

        layout.addView(
                status
        );


        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle(
                                (note.favorite
                                        ? "⭐ "
                                        : "") +
                                        note.title
                        )
                        .setView(layout)
                        .setPositiveButton(
                                "CLOSE",
                                null
                        )
                        .setNeutralButton(
                                "EDIT",
                                null
                        )
                        .setNegativeButton(
                                "DELETE",
                                null
                        )
                        .create();


        dialog.setOnShowListener(
                d -> {

                    dialog.getButton(
                            AlertDialog.BUTTON_NEUTRAL
                    ).setOnClickListener(
                            view -> {

                                dialog.dismiss();

                                showNoteDialog(
                                        note
                                );
                            }
                    );


                    dialog.getButton(
                            AlertDialog.BUTTON_NEGATIVE
                    ).setOnClickListener(
                            view -> {

                                dialog.dismiss();

                                confirmDelete(
                                        note
                                );
                            }
                    );
                }
        );


        dialog.show();
    }


    // =========================================
    // DELETE CONFIRMATION
    // =========================================

    private void confirmDelete(
            NoteData note) {

        new AlertDialog.Builder(this)

                .setTitle(
                        "DELETE KNOWLEDGE?"
                )

                .setMessage(
                        "This note will be permanently deleted."
                )

                .setNegativeButton(
                        "CANCEL",
                        null
                )

                .setPositiveButton(
                        "DELETE",
                        (dialog, which) ->
                                deleteNote(
                                        note.id
                                )
                )

                .show();
    }


    // =========================================
    // DELETE NOTE
    // =========================================

    private void deleteNote(
            long id) {

        int deleted =
                db.delete(
                        "knowledge",
                        "knowledge_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(id),
                                String.valueOf(userId)
                        }
                );


        if (deleted > 0) {

            loadNotes();

            Toast.makeText(
                    this,
                    "Knowledge deleted.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =========================================
    // UPDATE COUNT
    // =========================================

    private void updateCount() {

        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) FROM knowledge WHERE user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );


        int count = 0;


        if (cursor.moveToFirst()) {

            count =
                    cursor.getInt(0);
        }


        cursor.close();


        txtNoteCount.setText(
                count +
                        " NOTE" +
                        (count == 1 ? "" : "S")
        );
    }


    // =========================================
    // MIGRATE OLD SHARED PREFERENCES NOTES
    // =========================================

    private void migrateOldNotes() {

        SharedPreferences preferences =
                getSharedPreferences(
                        "KnowledgeVault",
                        MODE_PRIVATE
                );


        boolean migrated =
                preferences.getBoolean(
                        "migrated_to_sqlite",
                        false
                );


        if (migrated) {
            return;
        }


        int oldCount =
                preferences.getInt(
                        "note_count",
                        0
                );


        for (
                int i = 1;
                i <= oldCount;
                i++
        ) {

            String title =
                    preferences.getString(
                            "note_" + i + "_title",
                            ""
                    );

            String content =
                    preferences.getString(
                            "note_" + i + "_content",
                            ""
                    );


            if (title.trim().isEmpty()) {
                continue;
            }


            ContentValues values =
                    new ContentValues();

            values.put(
                    "user_id",
                    userId
            );

            values.put(
                    "title",
                    title
            );

            values.put(
                    "content",
                    content
            );

            values.put(
                    "category",
                    "STUDY"
            );

            values.put(
                    "is_favorite",
                    0
            );

            values.put(
                    "is_learned",
                    0
            );

            String now =
                    getCurrentDate();

            values.put(
                    "created_date",
                    now
            );

            values.put(
                    "updated_date",
                    now
            );


            db.insert(
                    "knowledge",
                    null,
                    values
            );
        }


        preferences
                .edit()
                .putBoolean(
                        "migrated_to_sqlite",
                        true
                )
                .apply();
    }


    // =========================================
    // CURRENT DATE
    // =========================================

    private String getCurrentDate() {

        SimpleDateFormat format =
                new SimpleDateFormat(
                        "yyyy-MM-dd HH:mm:ss",
                        Locale.getDefault()
                );

        return format.format(
                new Date()
        );
    }


    // =========================================
    // NOTE DATA CLASS
    // =========================================

    private static class NoteData {

        long id;

        String title;

        String content;

        String category;

        boolean favorite;

        boolean learned;


        NoteData(
                long id,
                String title,
                String content,
                String category,
                boolean favorite,
                boolean learned) {

            this.id = id;

            this.title = title;

            this.content = content;

            this.category = category;

            this.favorite = favorite;

            this.learned = learned;
        }
    }
}
package com.example.mad;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class progress extends AppCompatActivity {

    private LinearLayout historyContainer;

    private TextView txtLevel;
    private TextView txtXP;
    private TextView txtNextLevel;

    private TextView txtCompleted;
    private TextView txtQuests;
    private TextView txtGoals;
    private TextView txtStreak;

    private ProgressBar xpProgress;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_progress);

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getReadableDatabase();

        historyContainer =
                findViewById(R.id.historyContainer);

        txtLevel =
                findViewById(R.id.txtLevel);

        txtXP =
                findViewById(R.id.txtXP);

        txtNextLevel =
                findViewById(R.id.txtNextLevel);

        txtCompleted =
                findViewById(R.id.txtCompleted);

        txtQuests =
                findViewById(R.id.txtQuests);

        txtGoals =
                findViewById(R.id.txtGoals);

        txtStreak =
                findViewById(R.id.txtStreak);

        xpProgress =
                findViewById(R.id.xpProgress);

        TextView btnBack =
                findViewById(R.id.btnBack);

        btnBack.setOnClickListener(
                view -> finish()
        );

        loadProgress();
    }

    @Override
    protected void onResume() {

        super.onResume();

        if (db != null && userId != -1) {
            loadProgress();
        }
    }

    private void loadProgress() {

        if (userId == -1) {
            return;
        }

        int xp = 0;
        int level = 1;

        Cursor userCursor =
                db.query(
                        "users",
                        new String[]{
                                "xp",
                                "level"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (userCursor.moveToFirst()) {

            xp =
                    userCursor.getInt(
                            userCursor.getColumnIndexOrThrow(
                                    "xp"
                            )
                    );

            level =
                    userCursor.getInt(
                            userCursor.getColumnIndexOrThrow(
                                    "level"
                            )
                    );
        }

        userCursor.close();

        int startXP =
                getLevelStartXP(level);

        int nextXP =
                getNextLevelXP(level);

        int currentLevelXP =
                xp - startXP;

        int requiredLevelXP =
                nextXP - startXP;

        if (level >= 10) {

            currentLevelXP =
                    xp - startXP;

            requiredLevelXP = 1;
        }

        if (currentLevelXP < 0) {
            currentLevelXP = 0;
        }

        if (currentLevelXP > requiredLevelXP) {
            currentLevelXP = requiredLevelXP;
        }

        txtLevel.setText(
                "LEVEL " +
                        String.format(
                                "%02d",
                                level
                        )
        );

        txtXP.setText(
                xp + " XP"
        );

        if (level >= 10) {

            txtNextLevel.setText(
                    "MAX LEVEL"
            );

        } else {

            txtNextLevel.setText(
                    (nextXP - xp) +
                            " XP to next level"
            );
        }

        xpProgress.setMax(
                Math.max(
                        requiredLevelXP,
                        1
                )
        );

        xpProgress.setProgress(
                currentLevelXP
        );

        loadQuestStats();

        loadGoalStats();

        loadStreak();

        loadHistory();
    }

    private void loadQuestStats() {

        int totalQuests = 0;
        int completedQuests = 0;

        Cursor cursor =
                db.rawQuery(
                        "SELECT " +
                                "COUNT(*) AS total, " +
                                "SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) AS completed " +
                                "FROM quests " +
                                "WHERE user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        if (cursor.moveToFirst()) {

            totalQuests =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "total"
                            )
                    );

            completedQuests =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "completed"
                            )
                    );
        }

        cursor.close();

        txtQuests.setText(
                String.valueOf(
                        totalQuests
                )
        );

        txtCompleted.setText(
                String.valueOf(
                        completedQuests
                )
        );
    }

    private void loadGoalStats() {

        int totalGoals = 0;

        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) AS total " +
                                "FROM goals " +
                                "WHERE user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        if (cursor.moveToFirst()) {

            totalGoals =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "total"
                            )
                    );
        }

        cursor.close();

        txtGoals.setText(
                String.valueOf(
                        totalGoals
                )
        );
    }

    private void loadStreak() {

        int streak = 0;

        Cursor cursor =
                db.query(
                        "streaks",
                        new String[]{
                                "current_streak"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (cursor.moveToFirst()) {

            streak =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "current_streak"
                            )
                    );
        }

        cursor.close();

        txtStreak.setText(
                String.valueOf(
                        streak
                )
        );
    }

    private void loadHistory() {

        historyContainer.removeAllViews();

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "title",
                                "category",
                                "xp",
                                "completed_date"
                        },
                        "user_id = ? AND status = 'Completed'",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        "quest_id DESC"
                );

        if (!cursor.moveToFirst()) {

            TextView empty =
                    new TextView(this);

            empty.setText(
                    "Your journey starts here.\n\n" +
                            "Complete a quest to build your history."
            );

            empty.setGravity(
                    Gravity.CENTER
            );

            empty.setTextColor(
                    Color.rgb(
                            160,
                            150,
                            170
                    )
            );

            empty.setTextSize(13);

            empty.setPadding(
                    20,
                    60,
                    20,
                    60
            );

            historyContainer.addView(
                    empty
            );

            cursor.close();

            return;
        }

        do {

            String title =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "title"
                            )
                    );

            String category =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "category"
                            )
                    );

            int xp =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "xp"
                            )
                    );

            String date =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "completed_date"
                            )
                    );

            addHistoryCard(
                    title,
                    category,
                    date,
                    xp
            );

        } while (cursor.moveToNext());

        cursor.close();
    }

    private void addHistoryCard(
            String title,
            String type,
            String date,
            int xp
    ) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.HORIZONTAL
        );

        card.setGravity(
                Gravity.CENTER_VERTICAL
        );

        card.setPadding(
                16,
                14,
                16,
                14
        );

        GradientDrawable background =
                new GradientDrawable();

        background.setColor(
                Color.rgb(
                        43,
                        34,
                        58
                )
        );

        background.setCornerRadius(
                22
        );

        card.setBackground(
                background
        );

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        params.setMargins(
                0,
                0,
                0,
                10
        );

        card.setLayoutParams(
                params
        );

        TextView typeView =
                new TextView(this);

        typeView.setText(
                "QUEST"
        );

        typeView.setGravity(
                Gravity.CENTER
        );

        typeView.setTextColor(
                Color.rgb(
                        55,
                        38,
                        58
                )
        );

        typeView.setTextSize(9);

        typeView.setTypeface(
                null,
                Typeface.BOLD
        );

        GradientDrawable typeBackground =
                new GradientDrawable();

        typeBackground.setColor(
                Color.rgb(
                        235,
                        174,
                        218
                )
        );

        typeBackground.setCornerRadius(
                30
        );

        typeView.setBackground(
                typeBackground
        );

        card.addView(
                typeView,
                new LinearLayout.LayoutParams(
                        55,
                        38
                )
        );

        LinearLayout info =
                new LinearLayout(this);

        info.setOrientation(
                LinearLayout.VERTICAL
        );

        info.setPadding(
                14,
                0,
                10,
                0
        );

        LinearLayout.LayoutParams infoParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                );

        TextView titleView =
                new TextView(this);

        titleView.setText(
                title
        );

        titleView.setTextColor(
                Color.WHITE
        );

        titleView.setTextSize(14);

        titleView.setTypeface(
                null,
                Typeface.BOLD
        );

        TextView dateView =
                new TextView(this);

        dateView.setText(
                type +
                        "  •  " +
                        date
        );

        dateView.setTextColor(
                Color.rgb(
                        160,
                        150,
                        170
                )
        );

        dateView.setTextSize(10);

        info.addView(
                titleView
        );

        info.addView(
                dateView
        );

        card.addView(
                info,
                infoParams
        );

        TextView xpView =
                new TextView(this);

        xpView.setText(
                "+" +
                        xp +
                        " XP"
        );

        xpView.setTextColor(
                Color.rgb(
                        240,
                        183,
                        221
                )
        );

        xpView.setTextSize(12);

        xpView.setTypeface(
                null,
                Typeface.BOLD
        );

        card.addView(
                xpView
        );

        historyContainer.addView(
                card
        );
    }

    private int getLevelStartXP(
            int level
    ) {

        if (level >= 10) return 5850;
        else if (level == 9) return 4800;
        else if (level == 8) return 3850;
        else if (level == 7) return 3000;
        else if (level == 6) return 2250;
        else if (level == 5) return 1600;
        else if (level == 4) return 1050;
        else if (level == 3) return 600;
        else if (level == 2) return 250;
        else return 0;
    }

    private int getNextLevelXP(
            int level
    ) {

        if (level >= 10) return 5850;
        else if (level == 9) return 5850;
        else if (level == 8) return 4800;
        else if (level == 7) return 3850;
        else if (level == 6) return 3000;
        else if (level == 5) return 2250;
        else if (level == 4) return 1600;
        else if (level == 3) return 1050;
        else if (level == 2) return 600;
        else return 250;
    }
}
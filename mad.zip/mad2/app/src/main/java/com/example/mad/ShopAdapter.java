package com.example.mad;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ShopAdapter extends BaseAdapter {

    public static class ShopItem {

        int itemId;
        String name;
        String category;
        int price;
        String icon;
        String description;
        String rarity;
        boolean owned;

        public ShopItem(
                int itemId,
                String name,
                String category,
                int price,
                String icon,
                String description,
                String rarity,
                boolean owned) {

            this.itemId = itemId;
            this.name = name;
            this.category = category;
            this.price = price;
            this.icon = icon;
            this.description = description;
            this.rarity = rarity;
            this.owned = owned;
        }
    }

    public interface OnBuyClickListener {

        void onBuyClick(
                ShopItem item
        );
    }

    private Context context;

    private ArrayList<ShopItem> items;

    private OnBuyClickListener listener;

    public ShopAdapter(
            Context context,
            ArrayList<ShopItem> items,
            OnBuyClickListener listener) {

        this.context = context;

        this.items = items;

        this.listener = listener;
    }

    @Override
    public int getCount() {

        return items.size();
    }

    @Override
    public Object getItem(int position) {

        return items.get(position);
    }

    @Override
    public long getItemId(int position) {

        return items.get(position).itemId;
    }

    @Override
    public View getView(
            int position,
            View convertView,
            ViewGroup parent) {

        ViewHolder holder;

        if (convertView == null) {

            convertView =
                    LayoutInflater.from(context)
                            .inflate(
                                    R.layout.shop_item,
                                    parent,
                                    false
                            );

            holder = new ViewHolder();

            holder.imgShopItem =
                    convertView.findViewById(
                            R.id.imgShopItem
                    );

            holder.txtItemName =
                    convertView.findViewById(
                            R.id.txtItemName
                    );

            holder.txtItemInfo =
                    convertView.findViewById(
                            R.id.txtItemInfo
                    );

            holder.txtItemDescription =
                    convertView.findViewById(
                            R.id.txtItemDescription
                    );

            holder.btnBuy =
                    convertView.findViewById(
                            R.id.btnBuy
                    );

            convertView.setTag(holder);

        } else {

            holder =
                    (ViewHolder) convertView.getTag();
        }

        ShopItem item =
                items.get(position);

        holder.txtItemName.setText(
                item.name
        );

        holder.txtItemInfo.setText(
                item.category +
                        " • " +
                        item.rarity
        );

        holder.txtItemDescription.setText(
                item.description
        );

        int imageResource =
                getImageResource(item.name);

        if (imageResource != 0) {

            holder.imgShopItem.setImageResource(
                    imageResource
            );

        }

        if (item.owned) {

            holder.btnBuy.setText(
                    "OWNED ✓"
            );

            holder.btnBuy.setTextColor(
                    Color.WHITE
            );

            holder.btnBuy.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(
                            Color.parseColor("#625F63")
                    )
            );

        } else {

            holder.btnBuy.setText(
                    "🪙 " +
                            item.price
            );

            holder.btnBuy.setTextColor(
                    Color.WHITE
            );

            holder.btnBuy.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(
                            Color.parseColor("#625F63")
                    )
            );
        }

        holder.btnBuy.setOnClickListener(
                view -> {

                    if (listener != null) {

                        listener.onBuyClick(
                                item
                        );
                    }
                }
        );

        return convertView;
    }

    private int getImageResource(
            String itemName) {

        if (itemName.equals("Cool Cap")) {

            return R.drawable.cap;

        } else if (itemName.equals("Sunglasses")) {

            return R.drawable.sunglasses;

        } else if (itemName.equals("Black Hoodie")) {

            return R.drawable.blackhoodie;

        } else if (itemName.equals("Backpack")) {

            return R.drawable.backpack;

        } else if (itemName.equals("Streetwear Set")) {

            return R.drawable.streetwear;

        } else if (itemName.equals("Winter Outfit")) {

            return R.drawable.winter;

        } else if (itemName.equals("Crown")) {

            return R.drawable.crown;

        } else if (itemName.equals("Dragon Companion")) {

            return R.drawable.pet;
        }

        return 0;
    }

    private static class ViewHolder {

        ImageView imgShopItem;

        TextView txtItemName;

        TextView txtItemInfo;

        TextView txtItemDescription;

        Button btnBuy;
    }
}
package com.example.mad;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.FetchPlaceResponse;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsResponse;
import com.google.android.libraries.places.api.net.PlacesClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class lifemap extends AppCompatActivity
        implements OnMapReadyCallback {

    private GoogleMap googleMap;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private PlacesClient placesClient;
    private AutocompleteSessionToken sessionToken;

    private long userId;

    private Button btnAddLocation;
    private Button btnBackHome;

    private TextView txtMapHint;
    private TextView txtLocationCount;
    private TextView txtAddMode;

    private AutoCompleteTextView searchPlace;

    private boolean addLocationMode = false;

    private LatLng selectedSearchLocation = null;
    private String selectedSearchName = "";

    private final Map<Marker, Long> markerIds =
            new HashMap<>();

    private final List<AutocompletePrediction> predictions =
            new ArrayList<>();

    private ArrayAdapter<String> searchAdapter;

    private final Handler searchHandler =
            new Handler(Looper.getMainLooper());

    private Runnable searchRunnable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_lifemap
        );


        // =====================================
        // USER
        // =====================================

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );


        if (userId == -1) {

            finish();

            return;
        }


        // =====================================
        // DATABASE
        // =====================================

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();


        // =====================================
        // XML
        // =====================================

        btnAddLocation =
                findViewById(
                        R.id.btnAddLocation
                );

        btnBackHome =
                findViewById(
                        R.id.btnBackHome
                );

        txtMapHint =
                findViewById(
                        R.id.txtMapHint
                );

        txtLocationCount =
                findViewById(
                        R.id.txtLocationCount
                );

        txtAddMode =
                findViewById(
                        R.id.txtAddMode
                );

        searchPlace =
                findViewById(
                        R.id.searchPlace
                );


        // =====================================
        // PLACES SDK
        // =====================================

        String apiKey =
                getString(
                        R.string.google_maps_key
                );

        if (
                TextUtils.isEmpty(apiKey)
        ) {

            Toast.makeText(
                    this,
                    "Google Maps API key is missing",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }


        if (
                !Places.isInitialized()
        ) {

            Places.initializeWithNewPlacesApiEnabled(
                    getApplicationContext(),
                    apiKey
            );
        }


        placesClient =
                Places.createClient(this);


        // =====================================
        // SEARCH ADAPTER
        // =====================================

        searchAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_dropdown_item_1line,
                        new ArrayList<>()
                );

        searchPlace.setAdapter(
                searchAdapter
        );


        // =====================================
        // SEARCH TEXT
        // =====================================

        searchPlace.addTextChangedListener(
                new android.text.TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }


                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count) {

                        String query =
                                s.toString().trim();


                        if (
                                searchRunnable != null
                        ) {

                            searchHandler.removeCallbacks(
                                    searchRunnable
                            );
                        }


                        if (
                                query.length() < 2
                        ) {

                            predictions.clear();

                            searchAdapter.clear();

                            searchAdapter.notifyDataSetChanged();

                            return;
                        }


                        searchRunnable =
                                () -> searchPlaces(
                                        query
                                );


                        searchHandler.postDelayed(
                                searchRunnable,
                                350
                        );
                    }


                    @Override
                    public void afterTextChanged(
                            android.text.Editable s) {
                    }
                }
        );


        // =====================================
        // SEARCH RESULT CLICK
        // =====================================

        searchPlace.setOnItemClickListener(
                (parent, view, position, id) -> {

                    if (
                            position >= predictions.size()
                    ) {

                        return;
                    }


                    AutocompletePrediction prediction =
                            predictions.get(
                                    position
                            );


                    fetchSelectedPlace(
                            prediction
                    );
                }
        );


        // =====================================
        // GOOGLE MAP
        // =====================================

        SupportMapFragment mapFragment =
                (SupportMapFragment)
                        getSupportFragmentManager()
                                .findFragmentById(
                                        R.id.map
                                );

        if (mapFragment != null) {

            mapFragment.getMapAsync(
                    this
            );
        }


        // =====================================
        // ADD LOCATION
        // =====================================

        btnAddLocation.setOnClickListener(
                v -> {

                    if (!addLocationMode) {

                        addLocationMode = true;

                        txtAddMode.setText(
                                "Now tap anywhere on the map to choose a place."
                        );

                        btnAddLocation.setText(
                                "CANCEL ADDING"
                        );

                        Toast.makeText(
                                this,
                                "Tap a location on the map",
                                Toast.LENGTH_SHORT
                        ).show();

                    } else {

                        cancelAddMode();
                    }
                }
        );


        // =====================================
        // BACK HOME
        // =====================================

        btnBackHome.setOnClickListener(
                v -> finish()
        );


        updateLocationCount();
    }


    // =====================================
    // SEARCH PLACES
    // =====================================

    private void searchPlaces(
            String query) {

        if (
                placesClient == null
        ) {

            return;
        }


        sessionToken =
                AutocompleteSessionToken
                        .newInstance();


        FindAutocompletePredictionsRequest request =
                FindAutocompletePredictionsRequest
                        .builder()
                        .setQuery(query)
                        .setCountries(
                                java.util.Collections
                                        .singletonList("IN")
                        )
                        .setRegionCode("IN")
                        .setSessionToken(
                                sessionToken
                        )
                        .build();


        placesClient
                .findAutocompletePredictions(
                        request
                )
                .addOnSuccessListener(
                        response -> {

                            updateSearchResults(
                                    response
                            );
                        }
                )
                .addOnFailureListener(
                        exception -> {

                            predictions.clear();

                            searchAdapter.clear();

                            searchAdapter.notifyDataSetChanged();
                        }
                );
    }


    // =====================================
    // UPDATE SEARCH RESULTS
    // =====================================

    private void updateSearchResults(
            FindAutocompletePredictionsResponse response) {

        predictions.clear();

        searchAdapter.clear();


        List<AutocompletePrediction>
                results =
                response
                        .getAutocompletePredictions();


        predictions.addAll(
                results
        );


        for (
                AutocompletePrediction prediction
                : results
        ) {

            searchAdapter.add(
                    prediction.getFullText(
                            null
                    ).toString()
            );
        }


        searchAdapter.notifyDataSetChanged();


        if (
                !results.isEmpty()
        ) {

            searchPlace.showDropDown();
        }
    }


    // =====================================
    // FETCH SELECTED PLACE
    // =====================================

    private void fetchSelectedPlace(
            AutocompletePrediction prediction) {

        List<Place.Field> placeFields =
                java.util.Arrays.asList(
                        Place.Field.ID,
                        Place.Field.DISPLAY_NAME,
                        Place.Field.LOCATION,
                        Place.Field.FORMATTED_ADDRESS
                );


        FetchPlaceRequest request =
                FetchPlaceRequest.builder(
                                prediction.getPlaceId(),
                                placeFields
                        )
                        .setSessionToken(
                                sessionToken
                        )
                        .build();


        Task<FetchPlaceResponse> task =
                placesClient.fetchPlace(
                        request
                );


        task.addOnSuccessListener(
                response -> {

                    Place place =
                            response.getPlace();


                    LatLng location =
                            place.getLocation();


                    if (
                            location == null
                    ) {

                        Toast.makeText(
                                this,
                                "Location could not be found",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }


                    selectedSearchLocation =
                            location;


                    if (
                            place.getDisplayName()
                                    != null
                    ) {

                        selectedSearchName =
                                place.getDisplayName()
                                        .toString();

                    } else {

                        selectedSearchName =
                                prediction
                                        .getPrimaryText(
                                                null
                                        )
                                        .toString();
                    }


                    // =====================================
                    // MOVE MAP
                    // =====================================

                    if (
                            googleMap != null
                    ) {

                        googleMap.animateCamera(
                                CameraUpdateFactory
                                        .newLatLngZoom(
                                                location,
                                                16f
                                        )
                        );


                        googleMap.addMarker(
                                new MarkerOptions()
                                        .position(
                                                location
                                        )
                                        .title(
                                                selectedSearchName
                                        )
                        );
                    }


                    searchPlace.setText(
                            selectedSearchName
                    );

                    searchPlace.dismissDropDown();


                    txtMapHint.setText(
                            selectedSearchName +
                                    " found. Tap ADD LOCATION to save it."
                    );


                    Toast.makeText(
                            this,
                            "Place found. Tap ADD LOCATION to save it.",
                            Toast.LENGTH_SHORT
                    ).show();


                    sessionToken = null;
                }
        );


        task.addOnFailureListener(
                exception -> {

                    Toast.makeText(
                            this,
                            "Could not find this place",
                            Toast.LENGTH_SHORT
                    ).show();
                }
        );
    }


    // =====================================
    // MAP READY
    // =====================================

    @Override
    public void onMapReady(
            GoogleMap map) {

        googleMap = map;


        // =====================================
        // MAP SETTINGS
        // =====================================

        googleMap.getUiSettings()
                .setZoomControlsEnabled(
                        true
                );

        googleMap.getUiSettings()
                .setCompassEnabled(
                        true
                );

        googleMap.getUiSettings()
                .setMapToolbarEnabled(
                        true
                );


        // =====================================
        // INITIAL CAMERA
        // =====================================

        LatLng chandigarh =
                new LatLng(
                        30.7333,
                        76.7794
                );

        googleMap.moveCamera(
                CameraUpdateFactory
                        .newLatLngZoom(
                                chandigarh,
                                11f
                        )
        );


        // =====================================
        // LOAD SAVED LOCATIONS
        // =====================================

        loadSavedLocations();


        // =====================================
        // MAP CLICK
        // =====================================

        googleMap.setOnMapClickListener(
                latLng -> {

                    if (addLocationMode) {

                        showAddLocationDialog(
                                latLng
                        );
                    }
                }
        );


        // =====================================
        // MARKER CLICK
        // =====================================

        googleMap.setOnMarkerClickListener(
                marker -> {

                    Long locationId =
                            markerIds.get(
                                    marker
                            );

                    if (locationId != null) {

                        showLocationDetails(
                                locationId
                        );

                        return true;
                    }

                    return false;
                }
        );
    }


    // =====================================
    // ADD LOCATION DIALOG
    // =====================================

    private void showAddLocationDialog(
            LatLng latLng) {

        LinearLayoutContainer container =
                new LinearLayoutContainer(
                        this
                );


        EditText nameInput =
                container.getNameInput();

        EditText descriptionInput =
                container.getDescriptionInput();


        if (
                !TextUtils.isEmpty(
                        selectedSearchName
                )
                        &&
                        selectedSearchLocation != null
                        &&
                        Math.abs(
                                selectedSearchLocation.latitude
                                        - latLng.latitude
                        ) < 0.0001
                        &&
                        Math.abs(
                                selectedSearchLocation.longitude
                                        - latLng.longitude
                        ) < 0.0001
        ) {

            nameInput.setText(
                    selectedSearchName
            );
        }


        AlertDialog dialog =
                new AlertDialog.Builder(
                        this
                )
                        .setTitle(
                                "SAVE LOCATION"
                        )
                        .setView(
                                container
                        )
                        .setNegativeButton(
                                "CANCEL",
                                (d, which) -> {
                                    cancelAddMode();
                                }
                        )
                        .setPositiveButton(
                                "SAVE",
                                null
                        )
                        .create();


        dialog.setOnShowListener(
                d -> {

                    Button saveButton =
                            dialog.getButton(
                                    AlertDialog.BUTTON_POSITIVE
                            );


                    saveButton.setOnClickListener(
                            v -> {

                                String name =
                                        nameInput
                                                .getText()
                                                .toString()
                                                .trim();


                                String description =
                                        descriptionInput
                                                .getText()
                                                .toString()
                                                .trim();


                                if (
                                        name.isEmpty()
                                ) {

                                    nameInput.setError(
                                            "Enter a location name"
                                    );

                                    return;
                                }


                                saveLocation(
                                        name,
                                        description,
                                        latLng
                                );


                                dialog.dismiss();

                                cancelAddMode();
                            }
                    );
                }
        );


        dialog.show();
    }


    // =====================================
    // SAVE LOCATION
    // =====================================

    private void saveLocation(
            String name,
            String description,
            LatLng latLng) {

        ContentValues values =
                new ContentValues();


        values.put(
                "user_id",
                userId
        );

        values.put(
                "name",
                name
        );

        values.put(
                "description",
                description
        );

        values.put(
                "latitude",
                latLng.latitude
        );

        values.put(
                "longitude",
                latLng.longitude
        );

        values.put(
                "created_date",
                System.currentTimeMillis()
        );


        long locationId =
                db.insert(
                        "locations",
                        null,
                        values
                );


        if (
                locationId == -1
        ) {

            Toast.makeText(
                    this,
                    "Location could not be saved",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        if (
                googleMap != null
        ) {

            Marker marker =
                    googleMap.addMarker(
                            new MarkerOptions()
                                    .position(
                                            latLng
                                    )
                                    .title(
                                            name
                                    )
                                    .snippet(
                                            description
                                    )
                    );


            if (
                    marker != null
            ) {

                markerIds.put(
                        marker,
                        locationId
                );
            }
        }


        updateLocationCount();


        Toast.makeText(
                this,
                "Location saved",
                Toast.LENGTH_SHORT
        ).show();
    }


    // =====================================
    // LOAD SAVED LOCATIONS
    // =====================================

    private void loadSavedLocations() {

        if (
                googleMap == null
        ) {

            return;
        }


        googleMap.clear();

        markerIds.clear();


        Cursor cursor =
                db.rawQuery(
                        "SELECT location_id, name, description, latitude, longitude " +
                                "FROM locations " +
                                "WHERE user_id = ? " +
                                "ORDER BY location_id DESC",
                        new String[]{
                                String.valueOf(
                                        userId
                                )
                        }
                );


        while (
                cursor.moveToNext()
        ) {

            long locationId =
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    "location_id"
                            )
                    );


            String name =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "name"
                            )
                    );


            String description =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "description"
                            )
                    );


            double latitude =
                    cursor.getDouble(
                            cursor.getColumnIndexOrThrow(
                                    "latitude"
                            )
                    );


            double longitude =
                    cursor.getDouble(
                            cursor.getColumnIndexOrThrow(
                                    "longitude"
                            )
                    );


            LatLng position =
                    new LatLng(
                            latitude,
                            longitude
                    );


            Marker marker =
                    googleMap.addMarker(
                            new MarkerOptions()
                                    .position(
                                            position
                                    )
                                    .title(
                                            name
                                    )
                                    .snippet(
                                            description
                                    )
                    );


            if (
                    marker != null
            ) {

                markerIds.put(
                        marker,
                        locationId
                );
            }
        }


        cursor.close();


        updateLocationCount();
    }


    // =====================================
    // LOCATION DETAILS
    // =====================================

    private void showLocationDetails(
            long locationId) {

        Cursor cursor =
                db.rawQuery(
                        "SELECT name, description, latitude, longitude " +
                                "FROM locations " +
                                "WHERE location_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(
                                        locationId
                                ),
                                String.valueOf(
                                        userId
                                )
                        }
                );


        if (
                !cursor.moveToFirst()
        ) {

            cursor.close();

            return;
        }


        String name =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "name"
                        )
                );


        String description =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "description"
                        )
                );


        double latitude =
                cursor.getDouble(
                        cursor.getColumnIndexOrThrow(
                                "latitude"
                        )
                );


        double longitude =
                cursor.getDouble(
                        cursor.getColumnIndexOrThrow(
                                "longitude"
                        )
                );


        cursor.close();


        String message =
                "Description:\n"
                        +
                        (
                                description == null
                                        ||
                                        description
                                                .trim()
                                                .isEmpty()
                                        ? "No description"
                                        : description
                        )
                        +
                        "\n\n"
                        +
                        "Coordinates:\n"
                        +
                        String.format(
                                java.util.Locale.getDefault(),
                                "%.5f, %.5f",
                                latitude,
                                longitude
                        );


        new AlertDialog.Builder(
                this
        )
                .setTitle(
                        "📍 " + name
                )
                .setMessage(
                        message
                )
                .setNegativeButton(
                        "CLOSE",
                        null
                )
                .setPositiveButton(
                        "DELETE",
                        (dialog, which) -> {

                            confirmDeleteLocation(
                                    locationId,
                                    name
                            );

                        }
                )
                .show();
    }


    // =====================================
    // DELETE CONFIRMATION
    // =====================================

    private void confirmDeleteLocation(
            long locationId,
            String name) {

        new AlertDialog.Builder(
                this
        )
                .setTitle(
                        "Delete Location?"
                )
                .setMessage(
                        "Remove \"" +
                                name +
                                "\" from your Life Map?"
                )
                .setNegativeButton(
                        "CANCEL",
                        null
                )
                .setPositiveButton(
                        "DELETE",
                        (dialog, which) -> {

                            deleteLocation(
                                    locationId
                            );

                        }
                )
                .show();
    }


    // =====================================
    // DELETE LOCATION
    // =====================================

    private void deleteLocation(
            long locationId) {

        int deleted =
                db.delete(
                        "locations",
                        "location_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(
                                        locationId
                                ),
                                String.valueOf(
                                        userId
                                )
                        }
                );


        if (
                deleted > 0
        ) {

            if (
                    googleMap != null
            ) {

                loadSavedLocations();
            }


            updateLocationCount();


            Toast.makeText(
                    this,
                    "Location deleted",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            Toast.makeText(
                    this,
                    "Location could not be deleted",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================
    // CANCEL ADD MODE
    // =====================================

    private void cancelAddMode() {

        addLocationMode = false;


        txtAddMode.setText(
                "Tap ADD LOCATION, then tap anywhere on the map."
        );


        btnAddLocation.setText(
                "+  ADD LOCATION"
        );
    }


    // =====================================
    // LOCATION COUNT
    // =====================================

    private void updateLocationCount() {

        if (
                db == null
        ) {

            return;
        }


        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) " +
                                "FROM locations " +
                                "WHERE user_id = ?",
                        new String[]{
                                String.valueOf(
                                        userId
                                )
                        }
                );


        int count = 0;


        if (
                cursor.moveToFirst()
        ) {

            count =
                    cursor.getInt(
                            0
                    );
        }


        cursor.close();


        txtLocationCount.setText(
                count +
                        " SAVED PLACE" +
                        (
                                count == 1
                                        ? ""
                                        : "S"
                        )
        );
    }


    // =====================================
    // SIMPLE DIALOG INPUT CONTAINER
    // =====================================

    private static class LinearLayoutContainer
            extends android.widget.LinearLayout {

        private final EditText nameInput;
        private final EditText descriptionInput;


        public LinearLayoutContainer(
                android.content.Context context) {

            super(context);


            setOrientation(
                    VERTICAL
            );


            setPadding(
                    24,
                    8,
                    24,
                    4
            );


            nameInput =
                    new EditText(
                            context
                    );


            nameInput.setHint(
                    "Location name"
            );


            nameInput.setTextColor(
                    android.graphics.Color.WHITE
            );


            nameInput.setHintTextColor(
                    android.graphics.Color
                            .parseColor(
                                    "#8F829F"
                            )
            );


            nameInput.setSingleLine(
                    true
            );


            descriptionInput =
                    new EditText(
                            context
                    );


            descriptionInput.setHint(
                    "Description (optional)"
            );


            descriptionInput.setTextColor(
                    android.graphics.Color.WHITE
            );


            descriptionInput.setHintTextColor(
                    android.graphics.Color
                            .parseColor(
                                    "#8F829F"
                            )
            );


            descriptionInput.setGravity(
                    android.view.Gravity.TOP
            );


            descriptionInput.setMinLines(
                    3
            );


            descriptionInput.setInputType(
                    InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_FLAG_MULTI_LINE
            );


            android.widget.LinearLayout.LayoutParams
                    nameParams =
                    new android.widget.LinearLayout.LayoutParams(
                            LayoutParams.MATCH_PARENT,
                            LayoutParams.WRAP_CONTENT
                    );


            nameParams.setMargins(
                    0,
                    0,
                    0,
                    12
            );


            android.widget.LinearLayout.LayoutParams
                    descriptionParams =
                    new android.widget.LinearLayout.LayoutParams(
                            LayoutParams.MATCH_PARENT,
                            LayoutParams.WRAP_CONTENT
                    );


            addView(
                    nameInput,
                    nameParams
            );


            addView(
                    descriptionInput,
                    descriptionParams
            );
        }


        public EditText getNameInput() {

            return nameInput;
        }


        public EditText getDescriptionInput() {

            return descriptionInput;
        }
    }
}
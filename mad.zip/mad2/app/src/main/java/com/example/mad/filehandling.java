package com.example.mad;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class filehandling extends AppCompatActivity {

    private LinearLayout btnExportTxt;
    private LinearLayout btnExportCsv;
    private TextView btnBack;
    private TextView txtPlayerName;
    private TextView txtLastExport;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;
    private String playerName = "PLAYER";

    private static final int REQUEST_SAVE_TXT = 1001;
    private static final int REQUEST_SAVE_CSV = 1002;

    private String pendingTxt;
    private File pendingCsvZip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_filehandling);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getReadableDatabase();

        txtPlayerName =
                findViewById(R.id.txtPlayerName);

        txtLastExport =
                findViewById(R.id.txtLastExport);

        btnBack =
                findViewById(R.id.btnBack);

        btnExportTxt =
                findViewById(R.id.btnExportTxt);

        btnExportCsv =
                findViewById(R.id.btnExportCsv);

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        if (userId == -1) {
            finish();
            return;
        }

        loadPlayerName();

        btnBack.setOnClickListener(view -> {

            animateClick(view);

            finish();
        });

        btnExportTxt.setOnClickListener(view -> {

            animateClick(view);

            exportTxt();
        });

        btnExportCsv.setOnClickListener(view -> {

            animateClick(view);

            exportCsv();
        });

        animatePage();
    }


    // =========================================
    // LOAD PLAYER NAME
    // =========================================

    private void loadPlayerName() {

        Cursor cursor =
                db.query(
                        "users",
                        new String[]{
                                "name"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (cursor.moveToFirst()) {

            playerName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "name"
                            )
                    );
        }

        cursor.close();

        txtPlayerName.setText(
                playerName
        );
    }


    // =========================================
    // EXPORT TXT
    // =========================================

    private void exportTxt() {

        try {

            pendingTxt =
                    buildTxtExport();

            Intent intent =
                    new Intent(
                            Intent.ACTION_CREATE_DOCUMENT
                    );

            intent.addCategory(
                    Intent.CATEGORY_OPENABLE
            );

            intent.setType(
                    "text/plain"
            );

            intent.putExtra(
                    Intent.EXTRA_TITLE,
                    "LifeRPG_Backup_" +
                            timestampForFile() +
                            ".txt"
            );

            startActivityForResult(
                    intent,
                    REQUEST_SAVE_TXT
            );

        } catch (Exception e) {

            pendingTxt = null;

            Toast.makeText(
                    this,
                    "Could not prepare TXT export.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =========================================
    // EXPORT CSV
    // =========================================

    private void exportCsv() {

        try {

            pendingCsvZip =
                    buildCsvZip();

            Intent intent =
                    new Intent(
                            Intent.ACTION_CREATE_DOCUMENT
                    );

            intent.addCategory(
                    Intent.CATEGORY_OPENABLE
            );

            intent.setType(
                    "application/zip"
            );

            intent.putExtra(
                    Intent.EXTRA_TITLE,
                    "LifeRPG_CSV_Export_" +
                            timestampForFile() +
                            ".zip"
            );

            startActivityForResult(
                    intent,
                    REQUEST_SAVE_CSV
            );

        } catch (Exception e) {

            pendingCsvZip = null;

            Toast.makeText(
                    this,
                    "Could not prepare CSV export.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =========================================
    // SAVE RESULT
    // =========================================

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (
                resultCode != Activity.RESULT_OK ||
                        data == null
        ) {

            pendingTxt = null;

            deletePendingZip();

            return;
        }

        Uri uri =
                data.getData();

        if (uri == null) {

            pendingTxt = null;

            deletePendingZip();

            return;
        }

        if (
                requestCode ==
                        REQUEST_SAVE_TXT
        ) {

            saveTxtToUri(uri);

        } else if (
                requestCode ==
                        REQUEST_SAVE_CSV
        ) {

            saveZipToUri(uri);
        }
    }


    // =========================================
    // SAVE TXT
    // =========================================

    private void saveTxtToUri(Uri uri) {

        if (pendingTxt == null) {
            return;
        }

        try (
                OutputStream outputStream =
                        getContentResolver()
                                .openOutputStream(uri)
        ) {

            if (outputStream == null) {
                throw new Exception(
                        "Unable to open file."
                );
            }

            outputStream.write(
                    pendingTxt.getBytes(
                            StandardCharsets.UTF_8
                    )
            );

            outputStream.flush();

            txtLastExport.setText(
                    "Last Export: TXT • " +
                            timestampForDisplay()
            );

            Toast.makeText(
                    this,
                    "TXT backup exported successfully.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Could not save TXT backup.",
                    Toast.LENGTH_SHORT
            ).show();

        } finally {

            pendingTxt = null;
        }
    }


    // =========================================
    // SAVE CSV ZIP
    // =========================================

    private void saveZipToUri(Uri uri) {

        if (
                pendingCsvZip == null ||
                        !pendingCsvZip.exists()
        ) {
            return;
        }

        try (
                FileInputStream inputStream =
                        new FileInputStream(
                                pendingCsvZip
                        );

                OutputStream outputStream =
                        getContentResolver()
                                .openOutputStream(uri)
        ) {

            if (outputStream == null) {
                throw new Exception(
                        "Unable to open file."
                );
            }

            byte[] buffer =
                    new byte[8192];

            int length;

            while (
                    (length =
                            inputStream.read(buffer))
                            != -1
            ) {

                outputStream.write(
                        buffer,
                        0,
                        length
                );
            }

            outputStream.flush();

            txtLastExport.setText(
                    "Last Export: CSV • " +
                            timestampForDisplay()
            );

            Toast.makeText(
                    this,
                    "CSV export created successfully.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Could not save CSV export.",
                    Toast.LENGTH_SHORT
            ).show();

        } finally {

            deletePendingZip();
        }
    }


    // =========================================
    // BUILD TXT
    // =========================================

    private String buildTxtExport() {

        StringBuilder text =
                new StringBuilder();

        text.append(
                "LIFE RPG DATA BACKUP\n"
        );

        text.append(
                "====================\n\n"
        );

        text.append(
                "Exported: "
        );

        text.append(
                timestampForDisplay()
        );

        text.append("\n");

        text.append(
                "Player: "
        );

        text.append(
                playerName
        );

        text.append("\n\n");

        appendProfileText(text);

        appendStatsText(text);

        appendStreakText(text);

        appendGoalsText(text);

        appendQuestsText(text);

        appendAchievementsText(text);

        appendCalendarText(text);

        appendRemindersText(text);

        appendVaultText(text);

        appendLocationsText(text);

        appendKnowledgeText(text);

        text.append(
                "\nEND OF BACKUP\n"
        );

        return text.toString();
    }


    // =========================================
    // PROFILE
    // =========================================

    private void appendProfileText(
            StringBuilder text) {

        text.append(
                "PLAYER PROFILE\n"
        );

        text.append(
                "--------------\n"
        );

        Cursor cursor =
                db.query(
                        "users",
                        new String[]{
                                "name",
                                "email",
                                "avatar",
                                "level",
                                "xp",
                                "coins"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (cursor.moveToFirst()) {

            appendField(
                    text,
                    "Name",
                    cursor,
                    "name"
            );

            appendField(
                    text,
                    "Email",
                    cursor,
                    "email"
            );

            appendField(
                    text,
                    "Avatar",
                    cursor,
                    "avatar"
            );

            appendField(
                    text,
                    "Level",
                    cursor,
                    "level"
            );

            appendField(
                    text,
                    "Total XP",
                    cursor,
                    "xp"
            );

            appendField(
                    text,
                    "Coins",
                    cursor,
                    "coins"
            );
        }

        cursor.close();

        text.append("\n");
    }


    // =========================================
    // STATS
    // =========================================

    private void appendStatsText(
            StringBuilder text) {

        text.append(
                "STATS\n"
        );

        text.append(
                "-----\n"
        );

        Cursor cursor =
                db.query(
                        "stats",
                        new String[]{
                                "intelligence",
                                "strength",
                                "health",
                                "discipline",
                                "creativity"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (cursor.moveToFirst()) {

            appendField(
                    text,
                    "Intelligence",
                    cursor,
                    "intelligence"
            );

            appendField(
                    text,
                    "Strength",
                    cursor,
                    "strength"
            );

            appendField(
                    text,
                    "Health",
                    cursor,
                    "health"
            );

            appendField(
                    text,
                    "Discipline",
                    cursor,
                    "discipline"
            );

            appendField(
                    text,
                    "Creativity",
                    cursor,
                    "creativity"
            );
        }

        cursor.close();

        text.append("\n");
    }


    // =========================================
    // STREAKS
    // =========================================

    private void appendStreakText(
            StringBuilder text) {

        text.append(
                "STREAKS\n"
        );

        text.append(
                "-------\n"
        );

        Cursor cursor =
                db.query(
                        "streaks",
                        new String[]{
                                "current_streak",
                                "best_streak",
                                "last_completed_date"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (cursor.moveToFirst()) {

            appendField(
                    text,
                    "Current Streak",
                    cursor,
                    "current_streak"
            );

            appendField(
                    text,
                    "Best Streak",
                    cursor,
                    "best_streak"
            );

            appendField(
                    text,
                    "Last Completed Date",
                    cursor,
                    "last_completed_date"
            );
        }

        cursor.close();

        text.append("\n");
    }


    // =========================================
    // GOALS
    // =========================================

    private void appendGoalsText(
            StringBuilder text) {

        text.append(
                "GOALS\n"
        );

        text.append(
                "-----\n"
        );

        Cursor cursor =
                db.query(
                        "goals",
                        new String[]{
                                "title",
                                "category",
                                "deadline",
                                "progress",
                                "status",
                                "created_date"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        "goal_id ASC"
                );

        int count = 0;

        while (cursor.moveToNext()) {

            count++;

            text.append(
                    "Goal "
            );

            text.append(
                    count
            );

            text.append("\n");

            appendField(
                    text,
                    "Title",
                    cursor,
                    "title"
            );

            appendField(
                    text,
                    "Category",
                    cursor,
                    "category"
            );

            appendField(
                    text,
                    "Deadline",
                    cursor,
                    "deadline"
            );

            appendField(
                    text,
                    "Progress",
                    cursor,
                    "progress"
            );

            appendField(
                    text,
                    "Status",
                    cursor,
                    "status"
            );

            appendField(
                    text,
                    "Created",
                    cursor,
                    "created_date"
            );

            text.append("\n");
        }

        if (count == 0) {

            text.append(
                    "No goals saved.\n\n"
            );
        }

        cursor.close();
    }


    // =========================================
    // QUESTS
    // =========================================

    private void appendQuestsText(
            StringBuilder text) {

        text.append(
                "QUESTS\n"
        );

        text.append(
                "------\n"
        );

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "title",
                                "description",
                                "category",
                                "difficulty",
                                "duration",
                                "deadline",
                                "status",
                                "xp",
                                "created_date",
                                "completed_date"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        "quest_id ASC"
                );

        int count = 0;

        while (cursor.moveToNext()) {

            count++;

            text.append(
                    "Quest "
            );

            text.append(
                    count
            );

            text.append("\n");

            appendField(
                    text,
                    "Title",
                    cursor,
                    "title"
            );

            appendField(
                    text,
                    "Description",
                    cursor,
                    "description"
            );

            appendField(
                    text,
                    "Category",
                    cursor,
                    "category"
            );

            appendField(
                    text,
                    "Difficulty",
                    cursor,
                    "difficulty"
            );

            appendField(
                    text,
                    "Duration",
                    cursor,
                    "duration"
            );

            appendField(
                    text,
                    "Deadline",
                    cursor,
                    "deadline"
            );

            appendField(
                    text,
                    "Status",
                    cursor,
                    "status"
            );

            appendField(
                    text,
                    "XP",
                    cursor,
                    "xp"
            );

            appendField(
                    text,
                    "Created",
                    cursor,
                    "created_date"
            );

            appendField(
                    text,
                    "Completed",
                    cursor,
                    "completed_date"
            );

            text.append("\n");
        }

        if (count == 0) {

            text.append(
                    "No quests saved.\n\n"
            );
        }

        cursor.close();
    }


    // =========================================
    // ACHIEVEMENTS
    // =========================================

    private void appendAchievementsText(
            StringBuilder text) {

        text.append(
                "ACHIEVEMENTS\n"
        );

        text.append(
                "------------\n"
        );

        Cursor cursor =
                db.query(
                        "achievements",
                        new String[]{
                                "achievement_key",
                                "title",
                                "description",
                                "unlocked",
                                "unlocked_date"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        "achievement_id ASC"
                );

        int count = 0;

        while (cursor.moveToNext()) {

            count++;

            text.append(
                    "Achievement "
            );

            text.append(
                    count
            );

            text.append("\n");

            appendField(
                    text,
                    "Key",
                    cursor,
                    "achievement_key"
            );

            appendField(
                    text,
                    "Title",
                    cursor,
                    "title"
            );

            appendField(
                    text,
                    "Description",
                    cursor,
                    "description"
            );

            appendField(
                    text,
                    "Unlocked",
                    cursor,
                    "unlocked"
            );

            appendField(
                    text,
                    "Unlocked Date",
                    cursor,
                    "unlocked_date"
            );

            text.append("\n");
        }

        if (count == 0) {

            text.append(
                    "No achievements saved.\n\n"
            );
        }

        cursor.close();
    }


    // =========================================
    // CALENDAR
    // =========================================

    private void appendCalendarText(
            StringBuilder text) {

        text.append(
                "LIFE CALENDAR\n"
        );

        text.append(
                "-------------\n"
        );

        Cursor cursor =
                db.query(
                        "calendar_events",
                        new String[]{
                                "title",
                                "type",
                                "description",
                                "date",
                                "time",
                                "repeat",
                                "reminder",
                                "created_date"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        "event_id ASC"
                );

        int count = 0;

        while (cursor.moveToNext()) {

            count++;

            text.append(
                    "Event "
            );

            text.append(
                    count
            );

            text.append("\n");

            appendField(
                    text,
                    "Title",
                    cursor,
                    "title"
            );

            appendField(
                    text,
                    "Type",
                    cursor,
                    "type"
            );

            appendField(
                    text,
                    "Description",
                    cursor,
                    "description"
            );

            appendField(
                    text,
                    "Date",
                    cursor,
                    "date"
            );

            appendField(
                    text,
                    "Time",
                    cursor,
                    "time"
            );

            appendField(
                    text,
                    "Repeat",
                    cursor,
                    "repeat"
            );

            appendField(
                    text,
                    "Reminder",
                    cursor,
                    "reminder"
            );

            appendField(
                    text,
                    "Created",
                    cursor,
                    "created_date"
            );

            text.append("\n");
        }

        if (count == 0) {

            text.append(
                    "No calendar events saved.\n\n"
            );
        }

        cursor.close();
    }


    // =========================================
    // REMINDERS
    // =========================================

    private void appendRemindersText(
            StringBuilder text) {

        text.append(
                "CALENDAR REMINDERS\n"
        );

        text.append(
                "------------------\n"
        );

        Cursor cursor =
                db.rawQuery(
                        "SELECT er.reminder_id, " +
                                "er.event_id, " +
                                "er.reminder_time, " +
                                "ce.title AS event_title " +
                                "FROM event_reminders er " +
                                "LEFT JOIN calendar_events ce " +
                                "ON er.event_id = ce.event_id " +
                                "WHERE ce.user_id = ? " +
                                "ORDER BY er.reminder_id ASC",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        int count = 0;

        while (cursor.moveToNext()) {

            count++;

            text.append(
                    "Reminder "
            );

            text.append(
                    count
            );

            text.append("\n");

            appendField(
                    text,
                    "Event",
                    cursor,
                    "event_title"
            );

            appendField(
                    text,
                    "Event ID",
                    cursor,
                    "event_id"
            );

            appendField(
                    text,
                    "Reminder Time",
                    cursor,
                    "reminder_time"
            );

            text.append("\n");
        }

        if (count == 0) {

            text.append(
                    "No reminders saved.\n\n"
            );
        }

        cursor.close();
    }


    // =========================================
    // LIFE VAULT
    // =========================================

    private void appendVaultText(
            StringBuilder text) {

        text.append(
                "LIFE VAULT FILES\n"
        );

        text.append(
                "----------------\n"
        );

        Cursor cursor =
                db.query(
                        "vault_files",
                        new String[]{
                                "title",
                                "file_name",
                                "file_type",
                                "category",
                                "is_important",
                                "created_date"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        "file_id ASC"
                );

        int count = 0;

        while (cursor.moveToNext()) {

            count++;

            text.append(
                    "File "
            );

            text.append(
                    count
            );

            text.append("\n");

            appendField(
                    text,
                    "Title",
                    cursor,
                    "title"
            );

            appendField(
                    text,
                    "File Name",
                    cursor,
                    "file_name"
            );

            appendField(
                    text,
                    "File Type",
                    cursor,
                    "file_type"
            );

            appendField(
                    text,
                    "Category",
                    cursor,
                    "category"
            );

            appendField(
                    text,
                    "Important",
                    cursor,
                    "is_important"
            );

            appendField(
                    text,
                    "Created",
                    cursor,
                    "created_date"
            );

            text.append("\n");
        }

        if (count == 0) {

            text.append(
                    "No Life Vault files saved.\n\n"
            );
        }

        cursor.close();
    }


    // =========================================
    // LIFE MAP
    // =========================================

    private void appendLocationsText(
            StringBuilder text) {

        text.append(
                "LIFE MAP LOCATIONS\n"
        );

        text.append(
                "------------------\n"
        );

        Cursor cursor =
                db.query(
                        "locations",
                        new String[]{
                                "name",
                                "description",
                                "latitude",
                                "longitude",
                                "created_date"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        "location_id ASC"
                );

        int count = 0;

        while (cursor.moveToNext()) {

            count++;

            text.append(
                    "Location "
            );

            text.append(
                    count
            );

            text.append("\n");

            appendField(
                    text,
                    "Name",
                    cursor,
                    "name"
            );

            appendField(
                    text,
                    "Description",
                    cursor,
                    "description"
            );

            appendField(
                    text,
                    "Latitude",
                    cursor,
                    "latitude"
            );

            appendField(
                    text,
                    "Longitude",
                    cursor,
                    "longitude"
            );

            appendLocationDateField(
                    text,
                    cursor,
                    "Created",
                    "created_date"
            );

            text.append("\n");
        }

        if (count == 0) {

            text.append(
                    "No Life Map locations saved.\n\n"
            );
        }

        cursor.close();
    }


    // =========================================
    // KNOWLEDGE VAULT
    // =========================================

    private void appendKnowledgeText(
            StringBuilder text) {

        text.append(
                "KNOWLEDGE VAULT\n"
        );

        text.append(
                "---------------\n"
        );

        Cursor cursor =
                db.query(
                        "knowledge",
                        new String[]{
                                "title",
                                "content",
                                "category",
                                "is_favorite",
                                "is_learned",
                                "created_date",
                                "updated_date"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        "knowledge_id ASC"
                );

        int count = 0;

        while (cursor.moveToNext()) {

            count++;

            text.append(
                    "Note "
            );

            text.append(
                    count
            );

            text.append("\n");

            appendField(
                    text,
                    "Title",
                    cursor,
                    "title"
            );

            appendField(
                    text,
                    "Content",
                    cursor,
                    "content"
            );

            appendField(
                    text,
                    "Category",
                    cursor,
                    "category"
            );

            appendField(
                    text,
                    "Favorite",
                    cursor,
                    "is_favorite"
            );

            appendField(
                    text,
                    "Learned",
                    cursor,
                    "is_learned"
            );

            appendField(
                    text,
                    "Created",
                    cursor,
                    "created_date"
            );

            appendField(
                    text,
                    "Updated",
                    cursor,
                    "updated_date"
            );

            text.append("\n");
        }

        if (count == 0) {

            text.append(
                    "No Knowledge Vault notes saved.\n\n"
            );
        }

        cursor.close();
    }


    // =========================================
    // TEXT FIELD HELPER
    // =========================================

    private void appendField(
            StringBuilder text,
            String label,
            Cursor cursor,
            String column) {

        int index =
                cursor.getColumnIndex(
                        column
                );

        if (index == -1) {
            return;
        }

        String value =
                cursor.isNull(index)
                        ? ""
                        : cursor.getString(index);

        text.append(
                label
        );

        text.append(
                ": "
        );

        text.append(
                value
        );

        text.append(
                "\n"
        );
    }


    // =========================================
    // LOCATION DATE
    // =========================================

    private void appendLocationDateField(
            StringBuilder text,
            Cursor cursor,
            String label,
            String column) {

        int index =
                cursor.getColumnIndex(
                        column
                );

        if (
                index == -1 ||
                        cursor.isNull(index)
        ) {

            text.append(
                    label + ": \n"
            );

            return;
        }

        long value =
                cursor.getLong(index);

        if (value <= 0) {

            text.append(
                    label + ": \n"
            );

            return;
        }

        SimpleDateFormat format =
                new SimpleDateFormat(
                        "dd MMM yyyy, hh:mm a",
                        Locale.getDefault()
                );

        text.append(
                label +
                        ": " +
                        format.format(
                                new Date(value)
                        ) +
                        "\n"
        );
    }


    // =========================================
    // BUILD CSV ZIP
    // =========================================

    private File buildCsvZip()
            throws Exception {

        File zipFile =
                new File(
                        getCacheDir(),
                        "LifeRPG_CSV_Export_" +
                                timestampForFile() +
                                ".zip"
                );

        try (
                FileOutputStream fileOutputStream =
                        new FileOutputStream(
                                zipFile
                        );

                ZipOutputStream zipOutputStream =
                        new ZipOutputStream(
                                fileOutputStream
                        )
        ) {

            addCsvToZip(
                    zipOutputStream,
                    "Player_Profile.csv",
                    new String[]{
                            "user_id",
                            "name",
                            "email",
                            "avatar",
                            "level",
                            "xp",
                            "coins"
                    },
                    "users",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "user_id ASC"
            );

            addCsvToZip(
                    zipOutputStream,
                    "Stats.csv",
                    new String[]{
                            "user_id",
                            "intelligence",
                            "strength",
                            "health",
                            "discipline",
                            "creativity"
                    },
                    "stats",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "user_id ASC"
            );

            addCsvToZip(
                    zipOutputStream,
                    "Streaks.csv",
                    new String[]{
                            "user_id",
                            "current_streak",
                            "best_streak",
                            "last_completed_date"
                    },
                    "streaks",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "user_id ASC"
            );

            addCsvToZip(
                    zipOutputStream,
                    "Goals.csv",
                    new String[]{
                            "goal_id",
                            "user_id",
                            "title",
                            "category",
                            "deadline",
                            "progress",
                            "status",
                            "created_date"
                    },
                    "goals",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "goal_id ASC"
            );

            addCsvToZip(
                    zipOutputStream,
                    "Quests.csv",
                    new String[]{
                            "quest_id",
                            "user_id",
                            "title",
                            "description",
                            "category",
                            "difficulty",
                            "duration",
                            "deadline",
                            "status",
                            "goal_id",
                            "xp",
                            "created_date",
                            "completed_date"
                    },
                    "quests",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "quest_id ASC"
            );

            addCsvToZip(
                    zipOutputStream,
                    "Achievements.csv",
                    new String[]{
                            "achievement_id",
                            "user_id",
                            "achievement_key",
                            "title",
                            "description",
                            "unlocked",
                            "unlocked_date"
                    },
                    "achievements",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "achievement_id ASC"
            );

            addCsvToZip(
                    zipOutputStream,
                    "Calendar_Events.csv",
                    new String[]{
                            "event_id",
                            "user_id",
                            "title",
                            "type",
                            "description",
                            "date",
                            "time",
                            "repeat",
                            "reminder",
                            "created_date"
                    },
                    "calendar_events",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "event_id ASC"
            );

            addReminderCsvToZip(
                    zipOutputStream
            );

            addCsvToZip(
                    zipOutputStream,
                    "Life_Vault_Files.csv",
                    new String[]{
                            "file_id",
                            "user_id",
                            "title",
                            "file_name",
                            "file_type",
                            "category",
                            "is_important",
                            "created_date"
                    },
                    "vault_files",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "file_id ASC"
            );

            addCsvToZip(
                    zipOutputStream,
                    "Life_Map_Locations.csv",
                    new String[]{
                            "location_id",
                            "user_id",
                            "name",
                            "description",
                            "latitude",
                            "longitude",
                            "created_date"
                    },
                    "locations",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "location_id ASC"
            );

            addCsvToZip(
                    zipOutputStream,
                    "Knowledge_Vault.csv",
                    new String[]{
                            "knowledge_id",
                            "user_id",
                            "title",
                            "content",
                            "category",
                            "is_favorite",
                            "is_learned",
                            "created_date",
                            "updated_date"
                    },
                    "knowledge",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    },
                    "knowledge_id ASC"
            );
        }

        return zipFile;
    }


    // =========================================
    // NORMAL CSV TABLE
    // =========================================

    private void addCsvToZip(
            ZipOutputStream zipOutputStream,
            String fileName,
            String[] columns,
            String table,
            String selection,
            String[] selectionArgs,
            String orderBy)
            throws Exception {

        ZipEntry entry =
                new ZipEntry(
                        fileName
                );

        zipOutputStream.putNextEntry(
                entry
        );

        BufferedWriter writer =
                new BufferedWriter(
                        new OutputStreamWriter(
                                zipOutputStream,
                                StandardCharsets.UTF_8
                        )
                );

        writeCsvRow(
                writer,
                columns
        );

        Cursor cursor =
                db.query(
                        table,
                        columns,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        orderBy
                );

        while (cursor.moveToNext()) {

            String[] row =
                    new String[
                            columns.length
                            ];

            for (
                    int i = 0;
                    i < columns.length;
                    i++
            ) {

                int index =
                        cursor.getColumnIndex(
                                columns[i]
                        );

                if (
                        index == -1 ||
                                cursor.isNull(index)
                ) {

                    row[i] = "";

                } else {

                    row[i] =
                            cursor.getString(
                                    index
                            );
                }
            }

            writeCsvRow(
                    writer,
                    row
            );
        }

        cursor.close();

        writer.flush();

        zipOutputStream.closeEntry();
    }


    // =========================================
    // REMINDER CSV
    // =========================================

    private void addReminderCsvToZip(
            ZipOutputStream zipOutputStream)
            throws Exception {

        ZipEntry entry =
                new ZipEntry(
                        "Event_Reminders.csv"
                );

        zipOutputStream.putNextEntry(
                entry
        );

        BufferedWriter writer =
                new BufferedWriter(
                        new OutputStreamWriter(
                                zipOutputStream,
                                StandardCharsets.UTF_8
                        )
                );

        writeCsvRow(
                writer,
                new String[]{
                        "reminder_id",
                        "event_id",
                        "user_id",
                        "event_title",
                        "reminder_time"
                }
        );

        Cursor cursor =
                db.rawQuery(
                        "SELECT er.reminder_id, " +
                                "er.event_id, " +
                                "ce.user_id, " +
                                "ce.title AS event_title, " +
                                "er.reminder_time " +
                                "FROM event_reminders er " +
                                "INNER JOIN calendar_events ce " +
                                "ON er.event_id = ce.event_id " +
                                "WHERE ce.user_id = ? " +
                                "ORDER BY er.reminder_id ASC",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        while (cursor.moveToNext()) {

            writeCsvRow(
                    writer,
                    new String[]{
                            cursor.getString(0),
                            cursor.getString(1),
                            cursor.getString(2),
                            cursor.getString(3),
                            cursor.getString(4)
                    }
            );
        }

        cursor.close();

        writer.flush();

        zipOutputStream.closeEntry();
    }


    // =========================================
    // CSV ROW
    // =========================================

    private void writeCsvRow(
            BufferedWriter writer,
            String[] values)
            throws Exception {

        for (
                int i = 0;
                i < values.length;
                i++
        ) {

            if (i > 0) {
                writer.write(",");
            }

            writer.write(
                    csvEscape(
                            values[i]
                    )
            );
        }

        writer.write("\n");
    }


    // =========================================
    // CSV ESCAPE
    // =========================================

    private String csvEscape(
            String value) {

        if (value == null) {
            return "";
        }

        String escaped =
                value.replace(
                        "\"",
                        "\"\""
                );

        if (
                escaped.contains(",") ||
                        escaped.contains("\"") ||
                        escaped.contains("\n") ||
                        escaped.contains("\r")
        ) {

            return "\"" +
                    escaped +
                    "\"";
        }

        return escaped;
    }


    // =========================================
    // TIMESTAMP
    // =========================================

    private String timestampForFile() {

        return new SimpleDateFormat(
                "yyyyMMdd_HHmmss",
                Locale.getDefault()
        ).format(
                new Date()
        );
    }


    private String timestampForDisplay() {

        return new SimpleDateFormat(
                "dd MMM yyyy, hh:mm a",
                Locale.getDefault()
        ).format(
                new Date()
        );
    }


    // =========================================
    // DELETE TEMP ZIP
    // =========================================

    private void deletePendingZip() {

        if (
                pendingCsvZip != null &&
                        pendingCsvZip.exists()
        ) {

            pendingCsvZip.delete();
        }

        pendingCsvZip = null;
    }


    // =========================================
    // PAGE ANIMATION
    // =========================================

    private void animatePage() {

        View content =
                findViewById(
                        R.id.fileHandlingContent
                );

        AlphaAnimation fade =
                new AlphaAnimation(
                        0.0f,
                        1.0f
                );

        fade.setDuration(700);

        content.startAnimation(
                fade
        );
    }


    // =========================================
    // CLICK ANIMATION
    // =========================================

    private void animateClick(
            View view) {

        ScaleAnimation animation =
                new ScaleAnimation(
                        1.0f,
                        0.96f,
                        1.0f,
                        0.96f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f
                );

        animation.setDuration(100);

        animation.setRepeatMode(
                ScaleAnimation.REVERSE
        );

        animation.setRepeatCount(1);

        view.startAnimation(
                animation
        );
    }


    // =========================================
    // CLOSE DATABASE
    // =========================================

    @Override
    protected void onDestroy() {

        super.onDestroy();

        deletePendingZip();

        if (
                db != null &&
                        db.isOpen()
        ) {

            db.close();
        }

        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}
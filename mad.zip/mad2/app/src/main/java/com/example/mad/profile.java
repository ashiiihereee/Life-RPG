package com.example.mad;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class profile extends AppCompatActivity {

    private TextView txtProfileInitial;
    private TextView txtProfileName;
    private TextView txtProfileLevel;
    private TextView txtProfileXP;
    private TextView btnCustomizeCharacter;
    private TextView txtIntelligence;
    private TextView txtStrength;
    private TextView txtHealth;
    private TextView txtDiscipline;
    private TextView txtCreativity;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_profile);


        // DATABASE

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getReadableDatabase();


        // GET USER ID

        userId = getIntent().getLongExtra(
                "USER_ID",
                -1
        );


        if (userId == -1) {

            Toast.makeText(
                    this,
                    "Player not found.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

            return;
        }


        // CONNECT XML

        txtProfileInitial =
                findViewById(R.id.txtProfileInitial);

        txtProfileName =
                findViewById(R.id.txtProfileName);

        txtProfileLevel =
                findViewById(R.id.txtProfileLevel);

        txtProfileXP =
                findViewById(R.id.txtProfileXP);

        btnCustomizeCharacter =
                findViewById(R.id.btnCustomizeCharacter);

        txtIntelligence =
                findViewById(R.id.txtIntelligence);

        txtStrength =
                findViewById(R.id.txtStrength);

        txtHealth =
                findViewById(R.id.txtHealth);

        txtDiscipline =
                findViewById(R.id.txtDiscipline);

        txtCreativity =
                findViewById(R.id.txtCreativity);

        btnCustomizeCharacter.setOnClickListener(v -> {

            Intent intent = new Intent(
                    profile.this,
                    customization.class
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);

        });

        loadPlayerData();

    }




    private void loadPlayerData() {

        Cursor userCursor = db.query(
                "users",
                new String[]{
                        "name",
                        "level",
                        "xp",
                        "coins"
                },
                "user_id = ?",
                new String[]{
                        String.valueOf(userId)
                },
                null,
                null,
                null
        );


        if (userCursor.moveToFirst()) {

            String name =
                    userCursor.getString(
                            userCursor.getColumnIndexOrThrow("name")
                    );

            int level =
                    userCursor.getInt(
                            userCursor.getColumnIndexOrThrow("level")
                    );

            int xp =
                    userCursor.getInt(
                            userCursor.getColumnIndexOrThrow("xp")
                    );

            int coins =
                    userCursor.getInt(
                            userCursor.getColumnIndexOrThrow("coins")
                    );


            txtProfileName.setText(name);

            txtProfileLevel.setText(
                    "LEVEL " + level
            );

            txtProfileXP.setText(
                    String.valueOf(xp)
            );

            if (!name.isEmpty()) {

                txtProfileInitial.setText(
                        name.substring(0, 1).toUpperCase()
                );

            }

        }


        userCursor.close();


        // LOAD STATS

        Cursor statsCursor = db.query(
                "stats",
                new String[]{
                        "intelligence",
                        "strength",
                        "health",
                        "discipline",
                        "creativity"
                },
                "user_id = ?",
                new String[]{
                        String.valueOf(userId)
                },
                null,
                null,
                null
        );


        if (statsCursor.moveToFirst()) {

            int intelligence =
                    statsCursor.getInt(
                            statsCursor.getColumnIndexOrThrow(
                                    "intelligence"
                            )
                    );

            int strength =
                    statsCursor.getInt(
                            statsCursor.getColumnIndexOrThrow(
                                    "strength"
                            )
                    );

            int health =
                    statsCursor.getInt(
                            statsCursor.getColumnIndexOrThrow(
                                    "health"
                            )
                    );

            int discipline =
                    statsCursor.getInt(
                            statsCursor.getColumnIndexOrThrow(
                                    "discipline"
                            )
                    );

            int creativity =
                    statsCursor.getInt(
                            statsCursor.getColumnIndexOrThrow(
                                    "creativity"
                            )
                    );


            txtIntelligence.setText(
                    "🧠  Intelligence                         "
                            + intelligence
            );

            txtStrength.setText(
                    "⚔  Strength                              "
                            + strength
            );

            txtHealth.setText(
                    "❤️  Health                                "
                            + health
            );

            txtDiscipline.setText(
                    "🔥  Discipline                            "
                            + discipline
            );

            txtCreativity.setText(
                    "🎨  Creativity                             "
                            + creativity
            );

        }


        statsCursor.close();

    }


    @Override
    protected void onResume() {

        super.onResume();

        if (db != null && userId != -1) {

            loadPlayerData();

        }

    }

}
package com.example.mad;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomizationAdapter extends BaseAdapter {

    public static class CustomizationItem {

        int itemId;
        String name;
        String category;
        int price;
        String icon;
        String description;
        String rarity;
        boolean equipped;

        public CustomizationItem(
                int itemId,
                String name,
                String category,
                int price,
                String icon,
                String description,
                String rarity,
                boolean equipped) {

            this.itemId = itemId;
            this.name = name;
            this.category = category;
            this.price = price;
            this.icon = icon;
            this.description = description;
            this.rarity = rarity;
            this.equipped = equipped;
        }
    }

    public interface OnEquipClickListener {
        void onEquipClick(CustomizationItem item);
    }

    private Context context;
    private ArrayList<CustomizationItem> items;
    private OnEquipClickListener listener;

    public CustomizationAdapter(
            Context context,
            ArrayList<CustomizationItem> items,
            OnEquipClickListener listener) {

        this.context = context;
        this.items = items;
        this.listener = listener;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).itemId;
    }

    @Override
    public View getView(
            int position,
            View convertView,
            ViewGroup parent) {

        ViewHolder holder;

        if (convertView == null) {

            convertView = LayoutInflater.from(context)
                    .inflate(
                            R.layout.customization_item,
                            parent,
                            false
                    );

            holder = new ViewHolder();

            holder.imgCustomizationItem =
                    convertView.findViewById(
                            R.id.imgCustomizationItem
                    );

            holder.txtCustomizationName =
                    convertView.findViewById(
                            R.id.txtCustomizationName
                    );

            holder.txtCustomizationInfo =
                    convertView.findViewById(
                            R.id.txtCustomizationInfo
                    );

            holder.txtCustomizationDescription =
                    convertView.findViewById(
                            R.id.txtCustomizationDescription
                    );

            holder.btnEquip =
                    convertView.findViewById(
                            R.id.btnEquip
                    );

            convertView.setTag(holder);

        } else {

            holder = (ViewHolder) convertView.getTag();
        }

        CustomizationItem item = items.get(position);

        holder.txtCustomizationName.setText(item.name);

        holder.txtCustomizationInfo.setText(
                item.category + " • " + item.rarity
        );

        holder.txtCustomizationDescription.setText(
                item.description
        );

        int imageResource = getImageResource(item.name);

        if (imageResource != 0) {
            holder.imgCustomizationItem.setImageResource(
                    imageResource
            );
        }

        if (item.equipped) {

            holder.btnEquip.setText("EQUIPPED ✓");

            holder.btnEquip.setTextColor(Color.WHITE);

            holder.btnEquip.setBackgroundTintList(
                    ColorStateList.valueOf(
                            Color.parseColor("#7B68A6")
                    )
            );

            holder.btnEquip.setEnabled(false);

        } else {

            holder.btnEquip.setText("EQUIP");

            holder.btnEquip.setTextColor(Color.WHITE);

            holder.btnEquip.setBackgroundTintList(
                    ColorStateList.valueOf(
                            Color.parseColor("#625F63")
                    )
            );

            holder.btnEquip.setEnabled(true);
        }

        holder.btnEquip.setOnClickListener(view -> {

            if (listener != null && !item.equipped) {
                listener.onEquipClick(item);
            }

        });

        return convertView;
    }

    private int getImageResource(String itemName) {

        if (itemName.equals("Cool Cap")) {
            return R.drawable.cap;

        } else if (itemName.equals("Sunglasses")) {
            return R.drawable.sunglasses;

        } else if (itemName.equals("Black Hoodie")) {
            return R.drawable.blackhoodie;

        } else if (itemName.equals("Backpack")) {
            return R.drawable.backpack;

        } else if (itemName.equals("Streetwear Set")) {
            return R.drawable.streetwear;

        } else if (itemName.equals("Winter Outfit")) {
            return R.drawable.winter;

        } else if (itemName.equals("Crown")) {
            return R.drawable.crown;

        } else if (itemName.equals("Dragon Companion")) {
            return R.drawable.pet;
        }

        return 0;
    }

    private static class ViewHolder {

        ImageView imgCustomizationItem;
        TextView txtCustomizationName;
        TextView txtCustomizationInfo;
        TextView txtCustomizationDescription;
        Button btnEquip;
    }
}
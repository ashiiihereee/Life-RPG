package com.example.mad;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "LifeRPG.db";
    private static final int DATABASE_VERSION = 12;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // =====================================
        // USERS TABLE
        // =====================================

        String createUsersTable = "CREATE TABLE users (" +
                "user_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "email TEXT NOT NULL UNIQUE, " +
                "password TEXT NOT NULL, " +
                "avatar TEXT, " +
                "level INTEGER DEFAULT 1, " +
                "xp INTEGER DEFAULT 0, " +
                "coins INTEGER DEFAULT 0" +
                ")";

        db.execSQL(createUsersTable);


        // =====================================
        // STATS TABLE
        // =====================================

        String createStatsTable = "CREATE TABLE stats (" +
                "user_id INTEGER PRIMARY KEY, " +
                "intelligence INTEGER DEFAULT 0, " +
                "strength INTEGER DEFAULT 0, " +
                "health INTEGER DEFAULT 0, " +
                "discipline INTEGER DEFAULT 0, " +
                "creativity INTEGER DEFAULT 0" +
                ")";

        db.execSQL(createStatsTable);


        // =====================================
        // STREAKS TABLE
        // =====================================

        String createStreaksTable = "CREATE TABLE streaks (" +
                "user_id INTEGER PRIMARY KEY, " +
                "current_streak INTEGER DEFAULT 0, " +
                "best_streak INTEGER DEFAULT 0, " +
                "last_completed_date TEXT" +
                ")";

        db.execSQL(createStreaksTable);


        // =====================================
        // GOALS TABLE
        // =====================================

        String createGoalsTable = "CREATE TABLE goals (" +
                "goal_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL, " +
                "category TEXT, " +
                "deadline TEXT, " +
                "progress INTEGER DEFAULT 0, " +
                "status TEXT DEFAULT 'Active', " +
                "created_date TEXT" +
                ")";

        db.execSQL(createGoalsTable);


        // =====================================
        // QUESTS TABLE
        // =====================================

        String createQuestsTable = "CREATE TABLE quests (" +
                "quest_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL, " +
                "description TEXT, " +
                "category TEXT, " +
                "difficulty TEXT, " +
                "duration TEXT, " +
                "deadline TEXT, " +
                "status TEXT DEFAULT 'Available', " +
                "goal_id INTEGER, " +
                "xp INTEGER DEFAULT 0, " +
                "created_date TEXT, " +
                "completed_date TEXT" +
                ")";

        db.execSQL(createQuestsTable);


        // =====================================
        // ACHIEVEMENTS TABLE
        // =====================================

        String createAchievementsTable = "CREATE TABLE achievements (" +
                "achievement_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "achievement_key TEXT NOT NULL, " +
                "title TEXT NOT NULL, " +
                "description TEXT, " +
                "unlocked INTEGER DEFAULT 0, " +
                "unlocked_date TEXT" +
                ")";

        db.execSQL(createAchievementsTable);


        // =====================================
        // CALENDAR EVENTS TABLE
        // =====================================

        String createCalendarEventsTable = "CREATE TABLE calendar_events (" +
                "event_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL, " +
                "type TEXT NOT NULL, " +
                "description TEXT, " +
                "date TEXT NOT NULL, " +
                "time TEXT, " +
                "repeat TEXT DEFAULT 'Does not repeat', " +
                "reminder TEXT DEFAULT 'None', " +
                "created_date TEXT" +
                ")";

        db.execSQL(createCalendarEventsTable);


        // =====================================
        // EVENT REMINDERS TABLE
        // =====================================

        String createEventRemindersTable = "CREATE TABLE event_reminders (" +
                "reminder_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "event_id INTEGER NOT NULL, " +
                "reminder_time TEXT NOT NULL" +
                ")";

        db.execSQL(createEventRemindersTable);


        // =====================================
        // LIFE VAULT FILES TABLE
        // =====================================

        String createVaultFilesTable = "CREATE TABLE vault_files (" +
                "file_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL, " +
                "file_name TEXT NOT NULL, " +
                "file_path TEXT NOT NULL, " +
                "file_type TEXT, " +
                "category TEXT, " +
                "is_important INTEGER DEFAULT 0, " +
                "created_date TEXT" +
                ")";

        db.execSQL(createVaultFilesTable);


        // =====================================
        // LIFE MAP LOCATIONS TABLE
        // =====================================

        String createLocationsTable = "CREATE TABLE locations (" +
                "location_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "name TEXT NOT NULL, " +
                "description TEXT, " +
                "latitude REAL NOT NULL, " +
                "longitude REAL NOT NULL, " +
                "created_date INTEGER" +
                ")";

        db.execSQL(createLocationsTable);


        // =====================================
        // KNOWLEDGE VAULT TABLE
        // =====================================

        String createKnowledgeTable = "CREATE TABLE knowledge (" +
                "knowledge_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL, " +
                "content TEXT, " +
                "category TEXT DEFAULT 'STUDY', " +
                "is_favorite INTEGER DEFAULT 0, " +
                "is_learned INTEGER DEFAULT 0, " +
                "created_date TEXT, " +
                "updated_date TEXT" +
                ")";

        db.execSQL(createKnowledgeTable);


        // =====================================
        // SHOP ITEMS TABLE
        // =====================================

        String createShopItemsTable = "CREATE TABLE shop_items (" +
                "item_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "category TEXT NOT NULL, " +
                "price INTEGER NOT NULL, " +
                "icon TEXT, " +
                "description TEXT, " +
                "rarity TEXT DEFAULT 'Common'" +
                ")";

        db.execSQL(createShopItemsTable);


        // =====================================
        // OWNED ITEMS TABLE
        // =====================================

        String createOwnedItemsTable = "CREATE TABLE owned_items (" +
                "owned_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "item_id INTEGER NOT NULL, " +
                "equipped INTEGER DEFAULT 0, " +
                "UNIQUE(user_id, item_id)" +
                ")";

        db.execSQL(createOwnedItemsTable);


        // =====================================
        // DEFAULT SHOP ITEMS
        // =====================================

        insertDefaultShopItems(db);
    }


    private void insertDefaultShopItems(SQLiteDatabase db) {

        db.execSQL(
                "INSERT INTO shop_items " +
                        "(name, category, price, icon, description, rarity) VALUES " +
                        "('Cool Cap', 'Accessories', 50, '🧢', 'A stylish cap for your character.', 'Common')"
        );

        db.execSQL(
                "INSERT INTO shop_items " +
                        "(name, category, price, icon, description, rarity) VALUES " +
                        "('Sunglasses', 'Accessories', 75, '🕶️', 'Look cool while completing your quests.', 'Common')"
        );

        db.execSQL(
                "INSERT INTO shop_items " +
                        "(name, category, price, icon, description, rarity) VALUES " +
                        "('Black Hoodie', 'Outfits', 100, '🧥', 'A clean RPG streetwear hoodie.', 'Common')"
        );

        db.execSQL(
                "INSERT INTO shop_items " +
                        "(name, category, price, icon, description, rarity) VALUES " +
                        "('Backpack', 'Accessories', 150, '🎒', 'A useful-looking RPG backpack.', 'Rare')"
        );

        db.execSQL(
                "INSERT INTO shop_items " +
                        "(name, category, price, icon, description, rarity) VALUES " +
                        "('Streetwear Set', 'Outfits', 150, '👕', 'A complete streetwear character outfit.', 'Rare')"
        );

        db.execSQL(
                "INSERT INTO shop_items " +
                        "(name, category, price, icon, description, rarity) VALUES " +
                        "('Winter Outfit', 'Outfits', 200, '🥼', 'A warm winter outfit for your character.', 'Rare')"
        );

        db.execSQL(
                "INSERT INTO shop_items " +
                        "(name, category, price, icon, description, rarity) VALUES " +
                        "('Crown', 'Accessories', 250, '👑', 'Show off your RPG achievements.', 'Epic')"
        );

        db.execSQL(
                "INSERT INTO shop_items " +
                        "(name, category, price, icon, description, rarity) VALUES " +
                        "('Dragon Companion', 'Pets', 500, '🐉', 'A rare fantasy companion.', 'Epic')"
        );
    }


    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        // =====================================
        // VERSION 1 → VERSION 2
        // =====================================

        if (oldVersion < 2) {

            String createStatsTable =
                    "CREATE TABLE stats (" +
                            "user_id INTEGER PRIMARY KEY, " +
                            "intelligence INTEGER DEFAULT 0, " +
                            "strength INTEGER DEFAULT 0, " +
                            "health INTEGER DEFAULT 0, " +
                            "discipline INTEGER DEFAULT 0, " +
                            "creativity INTEGER DEFAULT 0" +
                            ")";

            db.execSQL(createStatsTable);

            db.execSQL(
                    "INSERT OR IGNORE INTO stats (user_id) " +
                            "SELECT user_id FROM users"
            );
        }


        // =====================================
        // VERSION 2 → VERSION 3
        // =====================================

        if (oldVersion < 3) {

            String createQuestsTable =
                    "CREATE TABLE quests (" +
                            "quest_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "user_id INTEGER NOT NULL, " +
                            "title TEXT NOT NULL, " +
                            "description TEXT, " +
                            "category TEXT, " +
                            "difficulty TEXT, " +
                            "duration TEXT, " +
                            "deadline TEXT, " +
                            "status TEXT DEFAULT 'Available', " +
                            "goal_id INTEGER, " +
                            "xp INTEGER DEFAULT 0, " +
                            "created_date TEXT, " +
                            "completed_date TEXT" +
                            ")";

            db.execSQL(createQuestsTable);
        }


        // =====================================
        // VERSION 3 → VERSION 4
        // =====================================

        if (oldVersion < 4) {

            String createStreaksTable =
                    "CREATE TABLE streaks (" +
                            "user_id INTEGER PRIMARY KEY, " +
                            "current_streak INTEGER DEFAULT 0, " +
                            "best_streak INTEGER DEFAULT 0, " +
                            "last_completed_date TEXT" +
                            ")";

            db.execSQL(createStreaksTable);

            db.execSQL(
                    "INSERT OR IGNORE INTO streaks (user_id) " +
                            "SELECT user_id FROM users"
            );
        }


        // =====================================
        // VERSION 4 → VERSION 5
        // =====================================

        if (oldVersion < 5) {

            String createGoalsTable =
                    "CREATE TABLE goals (" +
                            "goal_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "user_id INTEGER NOT NULL, " +
                            "title TEXT NOT NULL, " +
                            "category TEXT, " +
                            "deadline TEXT, " +
                            "progress INTEGER DEFAULT 0, " +
                            "status TEXT DEFAULT 'Active', " +
                            "created_date TEXT" +
                            ")";

            db.execSQL(createGoalsTable);
        }


        // =====================================
        // VERSION 5 → VERSION 6
        // =====================================

        if (oldVersion < 6) {

            String createAchievementsTable =
                    "CREATE TABLE achievements (" +
                            "achievement_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "user_id INTEGER NOT NULL, " +
                            "achievement_key TEXT NOT NULL, " +
                            "title TEXT NOT NULL, " +
                            "description TEXT, " +
                            "unlocked INTEGER DEFAULT 0, " +
                            "unlocked_date TEXT" +
                            ")";

            db.execSQL(createAchievementsTable);
        }


        // =====================================
        // VERSION 6 → VERSION 7
        // =====================================

        if (oldVersion < 7) {

            String createCalendarEventsTable =
                    "CREATE TABLE calendar_events (" +
                            "event_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "user_id INTEGER NOT NULL, " +
                            "title TEXT NOT NULL, " +
                            "type TEXT NOT NULL, " +
                            "description TEXT, " +
                            "date TEXT NOT NULL, " +
                            "time TEXT, " +
                            "repeat TEXT DEFAULT 'Does not repeat', " +
                            "reminder TEXT DEFAULT 'None', " +
                            "created_date TEXT" +
                            ")";

            db.execSQL(createCalendarEventsTable);
        }


        // =====================================
        // VERSION 7 → VERSION 8
        // =====================================

        if (oldVersion < 8) {

            String createEventRemindersTable =
                    "CREATE TABLE event_reminders (" +
                            "reminder_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "event_id INTEGER NOT NULL, " +
                            "event_id INTEGER NOT NULL, " +
                            "reminder_time TEXT NOT NULL" +
                            ")";

            db.execSQL(createEventRemindersTable);
        }


        // =====================================
        // VERSION 8 → VERSION 9
        // =====================================

        if (oldVersion < 9) {

            String createVaultFilesTable =
                    "CREATE TABLE vault_files (" +
                            "file_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "user_id INTEGER NOT NULL, " +
                            "title TEXT NOT NULL, " +
                            "file_name TEXT NOT NULL, " +
                            "file_path TEXT NOT NULL, " +
                            "file_type TEXT, " +
                            "category TEXT, " +
                            "is_important INTEGER DEFAULT 0, " +
                            "created_date TEXT" +
                            ")";

            db.execSQL(createVaultFilesTable);
        }


        // =====================================
        // VERSION 9 → VERSION 10
        // =====================================

        if (oldVersion < 10) {

            String createLocationsTable =
                    "CREATE TABLE locations (" +
                            "location_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "user_id INTEGER NOT NULL, " +
                            "name TEXT NOT NULL, " +
                            "description TEXT, " +
                            "latitude REAL NOT NULL, " +
                            "longitude REAL NOT NULL, " +
                            "created_date INTEGER" +
                            ")";

            db.execSQL(createLocationsTable);
        }


        // =====================================
        // VERSION 10 → VERSION 11
        // =====================================

        if (oldVersion < 11) {

            String createKnowledgeTable =
                    "CREATE TABLE knowledge (" +
                            "knowledge_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "user_id INTEGER NOT NULL, " +
                            "title TEXT NOT NULL, " +
                            "content TEXT, " +
                            "category TEXT DEFAULT 'STUDY', " +
                            "is_favorite INTEGER DEFAULT 0, " +
                            "is_learned INTEGER DEFAULT 0, " +
                            "created_date TEXT, " +
                            "updated_date TEXT" +
                            ")";

            db.execSQL(createKnowledgeTable);
        }


        // =====================================
        // VERSION 11 → VERSION 12
        // =====================================

        if (oldVersion < 12) {

            String createShopItemsTable =
                    "CREATE TABLE shop_items (" +
                            "item_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "name TEXT NOT NULL, " +
                            "category TEXT NOT NULL, " +
                            "price INTEGER NOT NULL, " +
                            "icon TEXT, " +
                            "description TEXT, " +
                            "rarity TEXT DEFAULT 'Common'" +
                            ")";

            db.execSQL(createShopItemsTable);


            String createOwnedItemsTable =
                    "CREATE TABLE owned_items (" +
                            "owned_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "user_id INTEGER NOT NULL, " +
                            "item_id INTEGER NOT NULL, " +
                            "equipped INTEGER DEFAULT 0, " +
                            "UNIQUE(user_id, item_id)" +
                            ")";

            db.execSQL(createOwnedItemsTable);


            insertDefaultShopItems(db);
        }
    }
}
package com.example.mad;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class goal_tracker extends AppCompatActivity {

    private LinearLayout goalsContainer;

    private TextView txtTotalGoals;
    private TextView txtCompletedGoals;
    private TextView txtGoalCount;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_goal_tracker);

        goalsContainer =
                findViewById(R.id.goalsContainer);

        txtTotalGoals =
                findViewById(R.id.txtTotalGoals);

        txtCompletedGoals =
                findViewById(R.id.txtCompletedGoals);

        txtGoalCount =
                findViewById(R.id.txtGoalCount);

        TextView btnBack =
                findViewById(R.id.btnBack);

        TextView btnNewGoal =
                findViewById(R.id.btnNewGoal);

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();

        loadGoals();

        btnBack.setOnClickListener(
                view -> finish()
        );

        btnNewGoal.setOnClickListener(
                view -> showCreateGoalDialog()
        );
    }

    @Override
    protected void onResume() {

        super.onResume();

        if (db != null) {
            loadGoals();
        }
    }

    private void showCreateGoalDialog() {

        LinearLayout layout =
                new LinearLayout(this);

        layout.setOrientation(
                LinearLayout.VERTICAL
        );

        layout.setPadding(
                40,
                10,
                40,
                5
        );

        EditText title =
                new EditText(this);

        title.setHint(
                "Goal name"
        );

        layout.addView(title);

        EditText category =
                new EditText(this);

        category.setHint(
                "Category e.g. Study, Fitness"
        );

        layout.addView(category);

        EditText deadline =
                new EditText(this);

        deadline.setHint(
                "Deadline"
        );

        layout.addView(deadline);

        new AlertDialog.Builder(this)

                .setTitle("CREATE NEW GOAL")

                .setView(layout)

                .setNegativeButton(
                        "CANCEL",
                        null
                )

                .setPositiveButton(
                        "CREATE",
                        (dialog, which) -> {

                            String goalTitle =
                                    title.getText()
                                            .toString()
                                            .trim();

                            String goalCategory =
                                    category.getText()
                                            .toString()
                                            .trim();

                            String goalDeadline =
                                    deadline.getText()
                                            .toString()
                                            .trim();

                            if (goalTitle.isEmpty()) {

                                Toast.makeText(
                                        this,
                                        "Enter a goal name.",
                                        Toast.LENGTH_SHORT
                                ).show();

                                return;
                            }

                            createGoal(
                                    goalTitle,
                                    goalCategory,
                                    goalDeadline
                            );
                        }
                )

                .show();
    }

    private void createGoal(
            String title,
            String category,
            String deadline
    ) {

        if (userId == -1) {

            Toast.makeText(
                    this,
                    "User not found.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        ContentValues values =
                new ContentValues();

        values.put(
                "user_id",
                userId
        );

        values.put(
                "title",
                title
        );

        values.put(
                "category",
                category
        );

        values.put(
                "deadline",
                deadline
        );

        values.put(
                "progress",
                0
        );

        values.put(
                "status",
                "Active"
        );

        values.put(
                "created_date",
                System.currentTimeMillis()
        );

        long goalId =
                db.insert(
                        "goals",
                        null,
                        values
                );

        if (goalId == -1) {

            Toast.makeText(
                    this,
                    "Failed to create goal.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        loadGoals();

        Toast.makeText(
                this,
                "New goal created.",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void loadGoals() {

        goalsContainer.removeAllViews();

        int totalGoals = 0;
        int completedGoals = 0;

        Cursor cursor =
                db.query(
                        "goals",
                        null,
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        "goal_id DESC"
                );

        while (cursor.moveToNext()) {

            long id =
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    "goal_id"
                            )
                    );

            String title =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "title"
                            )
                    );

            String category =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "category"
                            )
                    );

            String deadline =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "deadline"
                            )
                    );

            int progress =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "progress"
                            )
                    );

            String status =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "status"
                            )
                    );

            addGoalCard(
                    id,
                    title,
                    category,
                    deadline,
                    progress,
                    status
            );

            totalGoals++;

            if (progress >= 100) {
                completedGoals++;
            }
        }

        cursor.close();

        txtTotalGoals.setText(
                String.valueOf(
                        totalGoals
                )
        );

        txtGoalCount.setText(
                totalGoals + " GOALS"
        );

        txtCompletedGoals.setText(
                String.valueOf(
                        completedGoals
                )
        );
    }

    private void addGoalCard(
            long id,
            String title,
            String category,
            String deadline,
            int progress,
            String status
    ) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL
        );

        card.setPadding(
                18,
                17,
                18,
                17
        );

        GradientDrawable background =
                new GradientDrawable();

        background.setColor(
                Color.rgb(
                        43,
                        34,
                        58
                )
        );

        background.setCornerRadius(
                24
        );

        card.setBackground(
                background
        );

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        params.setMargins(
                0,
                0,
                0,
                12
        );

        card.setLayoutParams(
                params
        );

        LinearLayout topRow =
                new LinearLayout(this);

        topRow.setGravity(
                Gravity.CENTER_VERTICAL
        );

        LinearLayout titleBox =
                new LinearLayout(this);

        titleBox.setOrientation(
                LinearLayout.VERTICAL
        );

        LinearLayout.LayoutParams titleParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                );

        TextView titleView =
                new TextView(this);

        titleView.setText(
                title
        );

        titleView.setTextColor(
                Color.WHITE
        );

        titleView.setTextSize(
                16
        );

        titleView.setTypeface(
                null,
                Typeface.BOLD
        );

        TextView categoryView =
                new TextView(this);

        categoryView.setText(
                category
        );

        categoryView.setTextColor(
                Color.rgb(
                        193,
                        164,
                        211
                )
        );

        categoryView.setTextSize(
                10
        );

        titleBox.addView(
                titleView
        );

        titleBox.addView(
                categoryView
        );

        topRow.addView(
                titleBox,
                titleParams
        );

        TextView percentage =
                new TextView(this);

        percentage.setText(
                progress + "%"
        );

        percentage.setTextColor(
                Color.rgb(
                        240,
                        181,
                        221
                )
        );

        percentage.setTextSize(
                18
        );

        percentage.setTypeface(
                null,
                Typeface.BOLD
        );

        topRow.addView(
                percentage
        );

        card.addView(
                topRow
        );

        LinearLayout progressBackground =
                new LinearLayout(this);

        progressBackground.setOrientation(
                LinearLayout.HORIZONTAL
        );

        GradientDrawable progressBg =
                new GradientDrawable();

        progressBg.setColor(
                Color.rgb(
                        60,
                        50,
                        75
                )
        );

        progressBg.setCornerRadius(
                20
        );

        progressBackground.setBackground(
                progressBg
        );

        LinearLayout.LayoutParams progressParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        10
                );

        progressParams.setMargins(
                0,
                15,
                0,
                12
        );

        TextView progressFill =
                new TextView(this);

        GradientDrawable fill =
                new GradientDrawable();

        fill.setColors(
                new int[]{
                        Color.rgb(221, 157, 219),
                        Color.rgb(181, 164, 235)
                }
        );

        fill.setCornerRadius(
                20
        );

        progressFill.setBackground(
                fill
        );

        int width =
                (int)
                        (getResources()
                                .getDisplayMetrics()
                                .widthPixels
                                * 0.82
                                * progress
                                / 100f);

        if (progress == 0) {
            width = 1;
        }

        progressBackground.addView(
                progressFill,
                new LinearLayout.LayoutParams(
                        width,
                        10
                )
        );

        card.addView(
                progressBackground,
                progressParams
        );

        TextView deadlineView =
                new TextView(this);

        if (deadline == null || deadline.isEmpty()) {

            deadlineView.setText(
                    "No deadline set"
            );

        } else {

            deadlineView.setText(
                    "DEADLINE  •  " + deadline
            );
        }

        deadlineView.setTextColor(
                Color.rgb(
                        160,
                        149,
                        171
                )
        );

        deadlineView.setTextSize(
                10
        );

        card.addView(
                deadlineView
        );

        card.setOnClickListener(
                view ->
                        showGoalDetails(
                                id,
                                title,
                                category,
                                deadline,
                                progress,
                                status
                        )
        );

        goalsContainer.addView(
                card
        );
    }

    private void showGoalDetails(
            long id,
            String title,
            String category,
            String deadline,
            int currentProgress,
            String status
    ) {

        EditText progressInput =
                new EditText(this);

        progressInput.setHint(
                "Progress 0 - 100"
        );

        progressInput.setInputType(
                android.text.InputType.TYPE_CLASS_NUMBER
        );

        progressInput.setText(
                String.valueOf(
                        currentProgress
                )
        );

        new AlertDialog.Builder(this)

                .setTitle(title)

                .setMessage(
                        "Category: "
                                + category
                                + "\nDeadline: "
                                + deadline
                                + "\nStatus: "
                                + status
                )

                .setView(progressInput)

                .setNegativeButton(
                        "CLOSE",
                        null
                )

                .setPositiveButton(
                        "UPDATE",
                        (dialog, which) -> {

                            try {

                                int progress =
                                        Integer.parseInt(
                                                progressInput
                                                        .getText()
                                                        .toString()
                                        );

                                if (
                                        progress < 0
                                                ||
                                                progress > 100
                                ) {

                                    Toast.makeText(
                                            this,
                                            "Enter a value between 0 and 100.",
                                            Toast.LENGTH_SHORT
                                    ).show();

                                    return;
                                }

                                ContentValues values =
                                        new ContentValues();

                                values.put(
                                        "progress",
                                        progress
                                );

                                if (progress >= 100) {

                                    values.put(
                                            "status",
                                            "Completed"
                                    );

                                } else {

                                    values.put(
                                            "status",
                                            "Active"
                                    );
                                }

                                db.update(
                                        "goals",
                                        values,
                                        "goal_id = ? AND user_id = ?",
                                        new String[]{
                                                String.valueOf(id),
                                                String.valueOf(userId)
                                        }
                                );

                                loadGoals();

                            } catch (Exception e) {

                                Toast.makeText(
                                        this,
                                        "Enter a valid progress value.",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                )

                .show();
    }
}
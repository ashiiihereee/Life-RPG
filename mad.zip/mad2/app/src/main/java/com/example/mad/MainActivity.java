package com.example.mad;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private EditText edtEmail, edtPassword;
    private Button btnLogin, btnRegister;
    private CheckBox checkRemember;
    private TextView txtForgot;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private static final String PREFS_NAME = "LifeRPGSession";
    private static final String KEY_REMEMBER_ME = "remember_me";
    private static final String KEY_USER_ID = "remembered_user_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);

        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);

        checkRemember = findViewById(R.id.checkRemember);

        txtForgot = findViewById(R.id.txtForgot);

        styleInput(edtEmail);
        styleInput(edtPassword);

        btnLogin.setOnClickListener(v -> loginUser());

        btnRegister.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            register.class
                    );

            startActivity(intent);
        });

        txtForgot.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            forgot_password.class
                    );

            String email =
                    edtEmail.getText()
                            .toString()
                            .trim();

            intent.putExtra(
                    "EMAIL",
                    email
            );

            startActivity(intent);
        });

        requestNotificationPermission();

        animateLogo();
        animateLoginCard();

        checkRememberedSession();
    }

    private void loginUser() {

        String email =
                edtEmail.getText()
                        .toString()
                        .trim();

        String password =
                edtPassword.getText()
                        .toString()
                        .trim();

        if (TextUtils.isEmpty(email)) {

            edtEmail.setError(
                    "Enter your email"
            );

            edtEmail.requestFocus();

            return;
        }

        if (!Patterns.EMAIL_ADDRESS
                .matcher(email)
                .matches()) {

            edtEmail.setError(
                    "Enter a valid email"
            );

            edtEmail.requestFocus();

            return;
        }

        if (TextUtils.isEmpty(password)) {

            edtPassword.setError(
                    "Enter your password"
            );

            edtPassword.requestFocus();

            return;
        }

        Cursor cursor = db.query(
                "users",
                new String[]{
                        "user_id",
                        "name",
                        "password"
                },
                "email = ?",
                new String[]{
                        email
                },
                null,
                null,
                null
        );

        if (cursor.moveToFirst()) {

            long userId =
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    "user_id"
                            )
                    );

            String playerName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "name"
                            )
                    );

            String storedPassword =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "password"
                            )
                    );

            cursor.close();

            if (password.equals(storedPassword)) {

                if (checkRemember.isChecked()) {

                    saveRememberedSession(
                            userId
                    );

                } else {

                    clearRememberedSession();
                }

                Toast.makeText(
                        MainActivity.this,
                        "Login successful!",
                        Toast.LENGTH_SHORT
                ).show();

                openHome(
                        userId,
                        playerName
                );

            } else {

                Toast.makeText(
                        MainActivity.this,
                        "Incorrect password",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } else {

            cursor.close();

            Toast.makeText(
                    MainActivity.this,
                    "No account found with this email",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // ---------------------------------------------------------
    // REMEMBER ME
    // ---------------------------------------------------------

    private void saveRememberedSession(long userId) {

        SharedPreferences preferences =
                getSharedPreferences(
                        PREFS_NAME,
                        MODE_PRIVATE
                );

        preferences.edit()
                .putBoolean(
                        KEY_REMEMBER_ME,
                        true
                )
                .putLong(
                        KEY_USER_ID,
                        userId
                )
                .apply();
    }

    private void clearRememberedSession() {

        SharedPreferences preferences =
                getSharedPreferences(
                        PREFS_NAME,
                        MODE_PRIVATE
                );

        preferences.edit()
                .remove(KEY_REMEMBER_ME)
                .remove(KEY_USER_ID)
                .apply();
    }

    private void checkRememberedSession() {

        SharedPreferences preferences =
                getSharedPreferences(
                        PREFS_NAME,
                        MODE_PRIVATE
                );

        boolean rememberMe =
                preferences.getBoolean(
                        KEY_REMEMBER_ME,
                        false
                );

        long savedUserId =
                preferences.getLong(
                        KEY_USER_ID,
                        -1
                );

        if (!rememberMe || savedUserId == -1) {
            return;
        }

        Cursor cursor = db.query(
                "users",
                new String[]{
                        "name"
                },
                "user_id = ?",
                new String[]{
                        String.valueOf(savedUserId)
                },
                null,
                null,
                null
        );

        if (cursor.moveToFirst()) {

            String playerName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "name"
                            )
                    );

            cursor.close();

            openHome(
                    savedUserId,
                    playerName
            );

        } else {

            cursor.close();

            clearRememberedSession();
        }
    }

    // ---------------------------------------------------------
    // OPEN HOME
    // ---------------------------------------------------------

    private void openHome(
            long userId,
            String playerName
    ) {

        Intent intent =
                new Intent(
                        MainActivity.this,
                        home.class
                );

        intent.putExtra(
                "USER_ID",
                userId
        );

        intent.putExtra(
                "PLAYER_NAME",
                playerName
        );

        startActivity(intent);

        finish();
    }

    // ---------------------------------------------------------
    // INPUT STYLING
    // ---------------------------------------------------------

    private void styleInput(EditText editText) {

        GradientDrawable normalBorder =
                new GradientDrawable();

        normalBorder.setColor(
                Color.TRANSPARENT
        );

        normalBorder.setCornerRadius(
                18
        );

        normalBorder.setStroke(
                2,
                Color.parseColor(
                        "#5B4B7A"
                )
        );

        editText.setBackground(
                normalBorder
        );

        editText.setOnFocusChangeListener(
                (v, hasFocus) -> {

                    GradientDrawable border =
                            new GradientDrawable();

                    border.setColor(
                            Color.TRANSPARENT
                    );

                    border.setCornerRadius(
                            18
                    );

                    if (hasFocus) {

                        border.setStroke(
                                3,
                                Color.parseColor(
                                        "#A78BFA"
                                )
                        );

                    } else {

                        border.setStroke(
                                2,
                                Color.parseColor(
                                        "#5B4B7A"
                                )
                        );
                    }

                    editText.setBackground(
                            border
                    );
                }
        );
    }

    // ---------------------------------------------------------
    // ANIMATIONS
    // ---------------------------------------------------------

    private void animateLogo() {

        View logo =
                findViewById(
                        R.id.txtLogo
                );

        if (logo == null) {
            return;
        }

        ScaleAnimation scaleAnimation =
                new ScaleAnimation(
                        0.8f,
                        1f,
                        0.8f,
                        1f,
                        Animation.RELATIVE_TO_SELF,
                        0.5f,
                        Animation.RELATIVE_TO_SELF,
                        0.5f
                );

        scaleAnimation.setDuration(
                700
        );

        scaleAnimation.setFillAfter(
                true
        );

        logo.startAnimation(
                scaleAnimation
        );
    }

    private void animateLoginCard() {

        View card =
                findViewById(
                        R.id.loginCard
                );

        if (card == null) {
            return;
        }

        AlphaAnimation fade =
                new AlphaAnimation(
                        0f,
                        1f
                );

        fade.setDuration(
                900
        );

        fade.setFillAfter(
                true
        );

        card.startAnimation(
                fade
        );
    }

    // ---------------------------------------------------------
    // NOTIFICATION PERMISSION
    // ---------------------------------------------------------

    private void requestNotificationPermission() {

        if (android.os.Build.VERSION.SDK_INT >=
                android.os.Build.VERSION_CODES.TIRAMISU) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(
                        this,
                        new String[]{
                                Manifest.permission.POST_NOTIFICATIONS
                        },
                        100
                );
            }
        }
    }
}
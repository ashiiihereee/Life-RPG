package com.example.mad;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class calender extends AppCompatActivity {

    private GridLayout calendarGrid;

    private TextView txtMonth;
    private TextView txtSelectedDate;
    private TextView txtDayStatus;

    private Calendar currentMonth;

    private int selectedDay = -1;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;

    private final int[] pastelColors = {

            Color.rgb(244, 190, 218),
            Color.rgb(220, 196, 245),
            Color.rgb(193, 205, 245),
            Color.rgb(247, 211, 225),
            Color.rgb(196, 225, 239),
            Color.rgb(246, 211, 194),
            Color.rgb(216, 208, 238)

    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_calender);


        // =====================================
        // CONNECT XML
        // =====================================

        calendarGrid =
                findViewById(R.id.calendarGrid);

        txtMonth =
                findViewById(R.id.txtMonth);

        txtSelectedDate =
                findViewById(R.id.txtSelectedDate);

        txtDayStatus =
                findViewById(R.id.txtDayStatus);


        TextView btnBack =
                findViewById(R.id.btnBack);

        TextView btnPrevious =
                findViewById(R.id.btnPrevious);

        TextView btnNext =
                findViewById(R.id.btnNext);

        TextView btnAddTask =
                findViewById(R.id.btnAddTask);


        // =====================================
        // GET USER ID
        // =====================================

        userId = -1;

        if (getIntent().hasExtra("USER_ID")) {

            Object userIdObject =
                    getIntent()
                            .getExtras()
                            .get("USER_ID");

            if (userIdObject instanceof Long) {

                userId =
                        (Long) userIdObject;

            } else if (userIdObject instanceof Integer) {

                userId =
                        ((Integer) userIdObject).longValue();

            }

        }


        if (userId == -1) {

            Toast.makeText(
                    this,
                    "User session not found.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

            return;
        }


        // =====================================
        // DATABASE
        // =====================================

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();


        // =====================================
        // CURRENT MONTH
        // =====================================

        currentMonth =
                Calendar.getInstance();


        buildCalendar();


        // =====================================
        // BACK
        // =====================================

        btnBack.setOnClickListener(
                view -> finish()
        );


        // =====================================
        // PREVIOUS MONTH
        // =====================================

        btnPrevious.setOnClickListener(
                view -> {

                    currentMonth.add(
                            Calendar.MONTH,
                            -1
                    );

                    selectedDay = -1;

                    resetSelection();

                    buildCalendar();

                }
        );


        // =====================================
        // NEXT MONTH
        // =====================================

        btnNext.setOnClickListener(
                view -> {

                    currentMonth.add(
                            Calendar.MONTH,
                            1
                    );

                    selectedDay = -1;

                    resetSelection();

                    buildCalendar();

                }
        );


        // =====================================
        // ADD EVENT
        // =====================================

        btnAddTask.setOnClickListener(
                view -> {

                    if (selectedDay == -1) {

                        Toast.makeText(
                                this,
                                "Select a date first.",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }

                    showAddEventDialog();

                }
        );

    }


    // =====================================================
    // BUILD CALENDAR
    // =====================================================

    private void buildCalendar() {

        calendarGrid.removeAllViews();


        SimpleDateFormat monthFormat =
                new SimpleDateFormat(
                        "MMMM yyyy",
                        Locale.getDefault()
                );


        txtMonth.setText(
                monthFormat
                        .format(
                                currentMonth.getTime()
                        )
                        .toUpperCase()
        );


        Calendar firstDay =
                (Calendar) currentMonth.clone();

        firstDay.set(
                Calendar.DAY_OF_MONTH,
                1
        );


        int startingPosition =
                firstDay.get(
                        Calendar.DAY_OF_WEEK
                ) - 1;


        int daysInMonth =
                currentMonth.getActualMaximum(
                        Calendar.DAY_OF_MONTH
                );


        // =====================================
        // EMPTY CELLS
        // =====================================

        for (
                int i = 0;
                i < startingPosition;
                i++
        ) {

            addEmptyCell();

        }


        // =====================================
        // DATES
        // =====================================

        for (
                int day = 1;
                day <= daysInMonth;
                day++
        ) {

            addDateCell(day);

        }


        // =====================================
        // COMPLETE FINAL ROW
        // =====================================

        int total =
                startingPosition
                        + daysInMonth;


        while (total % 7 != 0) {

            addEmptyCell();

            total++;

        }

    }


    // =====================================================
    // DATE CELL
    // =====================================================

    private void addDateCell(
            int day
    ) {

        TextView date =
                new TextView(this);


        date.setText(
                String.valueOf(day)
        );


        date.setGravity(
                Gravity.CENTER
        );


        date.setTextSize(13);


        date.setTypeface(
                null,
                android.graphics.Typeface.BOLD
        );


        GridLayout.LayoutParams params =
                new GridLayout.LayoutParams();


        params.width = 0;
        params.height = 0;


        params.columnSpec =
                GridLayout.spec(
                        GridLayout.UNDEFINED,
                        1f
                );


        params.rowSpec =
                GridLayout.spec(
                        GridLayout.UNDEFINED,
                        1f
                );


        params.setMargins(
                4,
                4,
                4,
                4
        );


        date.setLayoutParams(params);


        // =====================================
        // CHECK EVENTS + PENDING QUESTS
        // =====================================

        int eventCount =
                getEventCount(day);

        int questCount =
                getQuestCount(day);

        int totalItems =
                eventCount + questCount;


        // =====================================
        // EVENT / QUEST DATE
        // =====================================

        if (totalItems > 0) {

            int savedColor =
                    pastelColors[
                            (day + totalItems)
                                    % pastelColors.length
                            ];


            date.setBackground(
                    roundedBackground(
                            savedColor
                    )
            );


            date.setTextColor(
                    Color.rgb(
                            60,
                            35,
                            60
                    )
            );

        }


        // =====================================
        // NORMAL DATE
        // =====================================

        else {

            date.setBackground(
                    roundedBackground(
                            Color.rgb(
                                    48,
                                    39,
                                    62
                            )
                    )
            );


            date.setTextColor(
                    Color.WHITE
            );

        }


        // =====================================
        // TODAY
        // =====================================

        if (
                isToday(day)
                        &&
                        totalItems == 0
        ) {

            date.setBackground(
                    todayBackground()
            );

        }


        // =====================================
        // CLICK DATE
        // =====================================

        date.setOnClickListener(
                view -> {

                    selectedDay = day;

                    updateSelectedDate(day);

                }
        );


        calendarGrid.addView(date);

    }


    // =====================================================
    // EMPTY CELL
    // =====================================================

    private void addEmptyCell() {

        TextView empty =
                new TextView(this);


        GridLayout.LayoutParams params =
                new GridLayout.LayoutParams();


        params.width = 0;
        params.height = 0;


        params.columnSpec =
                GridLayout.spec(
                        GridLayout.UNDEFINED,
                        1f
                );


        params.rowSpec =
                GridLayout.spec(
                        GridLayout.UNDEFINED,
                        1f
                );


        params.setMargins(
                4,
                4,
                4,
                4
        );


        empty.setLayoutParams(params);


        calendarGrid.addView(empty);

    }


    // =====================================================
    // SELECTED DATE
    // =====================================================

    private void updateSelectedDate(
            int day
    ) {

        txtSelectedDate.setText(
                formattedDate(day)
        );


        int eventCount =
                getEventCount(day);

        int questCount =
                getQuestCount(day);

        int totalItems =
                eventCount + questCount;


        if (totalItems == 0) {

            txtDayStatus.setText(
                    "No events or quests planned for this day."
            );

            return;

        }


        if (totalItems == 1) {

            txtDayStatus.setText(
                    "1 item planned • Tap below to view."
            );

        } else {

            txtDayStatus.setText(
                    totalItems +
                            " items planned • Tap below to view."
            );

        }


        showEventList(day);

    }


    // =====================================================
    // ADD EVENT DIALOG
    // =====================================================

    private void showAddEventDialog() {

        LinearLayout layout =
                new LinearLayout(this);


        layout.setOrientation(
                LinearLayout.VERTICAL
        );


        layout.setPadding(
                45,
                10,
                45,
                5
        );


        // =====================================
        // TITLE
        // =====================================

        EditText titleInput =
                new EditText(this);

        titleInput.setHint(
                "Event title"
        );

        titleInput.setTextColor(
                Color.BLACK
        );

        titleInput.setHintTextColor(
                Color.GRAY
        );

        layout.addView(
                titleInput
        );


        // =====================================
        // TYPE
        // =====================================

        Spinner typeSpinner =
                new Spinner(this);


        String[] eventTypes = {

                "Exam",
                "Assignment",
                "Birthday",
                "Meeting",
                "Appointment",
                "College Event",
                "Other"

        };


        ArrayAdapter<String> typeAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        eventTypes
                );


        typeAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );


        typeSpinner.setAdapter(
                typeAdapter
        );


        layout.addView(
                typeSpinner
        );


        // =====================================
        // DESCRIPTION
        // =====================================

        EditText descriptionInput =
                new EditText(this);

        descriptionInput.setHint(
                "Description"
        );

        descriptionInput.setTextColor(
                Color.BLACK
        );

        descriptionInput.setHintTextColor(
                Color.GRAY
        );

        descriptionInput.setMinLines(
                2
        );

        layout.addView(
                descriptionInput
        );


        // =====================================
        // TIME
        // =====================================

        TimePicker timePicker =
                new TimePicker(this);


        timePicker.setIs24HourView(
                false
        );


        layout.addView(
                timePicker
        );


        // =====================================
        // REPEAT
        // =====================================

        Spinner repeatSpinner =
                new Spinner(this);


        String[] repeatOptions = {

                "Does not repeat",
                "Daily",
                "Weekly",
                "Monthly"

        };


        ArrayAdapter<String> repeatAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        repeatOptions
                );


        repeatAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );


        repeatSpinner.setAdapter(
                repeatAdapter
        );


        layout.addView(
                repeatSpinner
        );


        // =====================================
        // REMINDERS TITLE
        // =====================================

        TextView reminderTitle =
                new TextView(this);

        reminderTitle.setText(
                "REMINDERS"
        );

        reminderTitle.setTextSize(
                14
        );

        reminderTitle.setTypeface(
                null,
                android.graphics.Typeface.BOLD
        );

        reminderTitle.setTextColor(
                Color.DKGRAY
        );

        reminderTitle.setPadding(
                0,
                20,
                0,
                8
        );

        layout.addView(
                reminderTitle
        );


        // =====================================
        // REMINDER CONTAINER
        // =====================================

        LinearLayout reminderContainer =
                new LinearLayout(this);

        reminderContainer.setOrientation(
                LinearLayout.VERTICAL
        );

        layout.addView(
                reminderContainer
        );


        // =====================================
        // ADD REMINDER BUTTON
        // =====================================

        Button addReminderButton =
                new Button(this);

        addReminderButton.setText(
                "+ ADD REMINDER"
        );

        layout.addView(
                addReminderButton
        );


        // =====================================
        // REMINDER LIST
        // =====================================

        ArrayList<String> selectedReminders =
                new ArrayList<>();


        addReminderButton.setOnClickListener(
                view -> {

                    showReminderPicker(
                            selectedReminders,
                            reminderContainer
                    );

                }
        );


        // =====================================
        // DIALOG
        // =====================================

        new AlertDialog.Builder(this)

                .setTitle(
                        "Create Event"
                )

                .setMessage(
                        formattedDate(
                                selectedDay
                        )
                )

                .setView(
                        layout
                )

                .setNegativeButton(
                        "CANCEL",
                        null
                )

                .setPositiveButton(
                        "SAVE",
                        (dialog, which) -> {

                            String title =
                                    titleInput
                                            .getText()
                                            .toString()
                                            .trim();


                            String description =
                                    descriptionInput
                                            .getText()
                                            .toString()
                                            .trim();


                            if (
                                    title.isEmpty()
                            ) {

                                Toast.makeText(
                                        this,
                                        "Enter an event title.",
                                        Toast.LENGTH_SHORT
                                ).show();

                                return;

                            }


                            int hour =
                                    timePicker
                                            .getHour();


                            int minute =
                                    timePicker
                                            .getMinute();


                            String time =
                                    String.format(
                                            Locale.getDefault(),
                                            "%02d:%02d",
                                            hour,
                                            minute
                                    );


                            String type =
                                    typeSpinner
                                            .getSelectedItem()
                                            .toString();


                            String repeat =
                                    repeatSpinner
                                            .getSelectedItem()
                                            .toString();


                            saveEvent(
                                    title,
                                    type,
                                    description,
                                    time,
                                    repeat,
                                    selectedReminders
                            );

                        }
                )

                .show();

    }


    // =====================================================
    // REMINDER PICKER
    // =====================================================

    private void showReminderPicker(
            ArrayList<String> selectedReminders,
            LinearLayout reminderContainer
    ) {

        String[] reminderOptions = {

                "At event time",
                "5 minutes before",
                "10 minutes before",
                "15 minutes before",
                "30 minutes before",
                "1 hour before",
                "2 hours before",
                "3 hours before",
                "6 hours before",
                "12 hours before",
                "1 day before",
                "2 days before",
                "1 week before"

        };


        boolean[] checked =
                new boolean[
                        reminderOptions.length
                        ];


        for (
                int i = 0;
                i < reminderOptions.length;
                i++
        ) {

            checked[i] =
                    selectedReminders.contains(
                            reminderOptions[i]
                    );

        }


        new AlertDialog.Builder(this)

                .setTitle(
                        "Add Reminder"
                )

                .setMultiChoiceItems(
                        reminderOptions,
                        checked,
                        (dialog, which, isChecked) -> {

                            if (isChecked) {

                                if (
                                        !selectedReminders.contains(
                                                reminderOptions[which]
                                        )
                                ) {

                                    selectedReminders.add(
                                            reminderOptions[which]
                                    );

                                }

                            } else {

                                selectedReminders.remove(
                                        reminderOptions[which]
                                );

                            }

                        }
                )

                .setPositiveButton(
                        "DONE",
                        (dialog, which) -> {

                            refreshReminderList(
                                    selectedReminders,
                                    reminderContainer
                            );

                        }
                )

                .setNegativeButton(
                        "CANCEL",
                        null
                )

                .show();

    }


    // =====================================================
    // REFRESH REMINDER LIST
    // =====================================================

    private void refreshReminderList(
            ArrayList<String> selectedReminders,
            LinearLayout reminderContainer
    ) {

        reminderContainer.removeAllViews();


        for (
                String reminder :
                selectedReminders
        ) {

            LinearLayout row =
                    new LinearLayout(this);

            row.setOrientation(
                    LinearLayout.HORIZONTAL
            );

            row.setGravity(
                    Gravity.CENTER_VERTICAL
            );


            TextView reminderText =
                    new TextView(this);

            reminderText.setText(
                    "🔔  " + reminder
            );

            reminderText.setTextSize(
                    14
            );

            reminderText.setTextColor(
                    Color.DKGRAY
            );

            reminderText.setPadding(
                    0,
                    8,
                    0,
                    8
            );


            LinearLayout.LayoutParams textParams =
                    new LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            1
                    );


            row.addView(
                    reminderText,
                    textParams
            );


            TextView removeButton =
                    new TextView(this);

            removeButton.setText(
                    "✕"
            );

            removeButton.setTextSize(
                    18
            );

            removeButton.setTextColor(
                    Color.RED
            );

            removeButton.setGravity(
                    Gravity.CENTER
            );

            removeButton.setPadding(
                    15,
                    5,
                    5,
                    5
            );


            removeButton.setOnClickListener(
                    view -> {

                        selectedReminders.remove(
                                reminder
                        );

                        refreshReminderList(
                                selectedReminders,
                                reminderContainer
                        );

                    }
            );


            row.addView(
                    removeButton
            );


            reminderContainer.addView(
                    row
            );

        }

    }


    // =====================================================
    // SAVE EVENT
    // =====================================================

    private void saveEvent(
            String title,
            String type,
            String description,
            String time,
            String repeat,
            ArrayList<String> reminders
    ) {

        String date =
                createDatabaseDate(
                        selectedDay
                );


        String createdDate =
                new SimpleDateFormat(
                        "yyyy-MM-dd HH:mm:ss",
                        Locale.getDefault()
                ).format(
                        Calendar.getInstance().getTime()
                );


        ContentValues values =
                new ContentValues();


        values.put(
                "user_id",
                userId
        );

        values.put(
                "title",
                title
        );

        values.put(
                "type",
                type
        );

        values.put(
                "description",
                description
        );

        values.put(
                "date",
                date
        );

        values.put(
                "time",
                time
        );

        values.put(
                "repeat",
                repeat
        );

        values.put(
                "reminder",
                reminders.isEmpty()
                        ? "None"
                        : reminders.size()
                          + " reminder(s)"
        );

        values.put(
                "created_date",
                createdDate
        );


        long eventId =
                db.insert(
                        "calendar_events",
                        null,
                        values
                );


        if (eventId == -1) {

            Toast.makeText(
                    this,
                    "Could not save event.",
                    Toast.LENGTH_SHORT
            ).show();

            return;

        }


        // =====================================
        // SAVE ALL REMINDERS
        // =====================================

        for (
                String reminder :
                reminders
        ) {

            ContentValues reminderValues =
                    new ContentValues();


            reminderValues.put(
                    "event_id",
                    eventId
            );


            reminderValues.put(
                    "reminder_time",
                    reminder
            );


            db.insert(
                    "event_reminders",
                    null,
                    reminderValues
            );

        }


        // =====================================
        // SCHEDULE NOTIFICATIONS
        // =====================================

        scheduleEventNotifications(
                eventId,
                title,
                date,
                time,
                reminders
        );


        buildCalendar();

        updateSelectedDate(
                selectedDay
        );


        Toast.makeText(
                this,
                "Event added to your journey.",
                Toast.LENGTH_SHORT
        ).show();

    }


    // =====================================================
    // SCHEDULE EVENT NOTIFICATIONS
    // =====================================================

    private void scheduleEventNotifications(
            long eventId,
            String title,
            String date,
            String time,
            ArrayList<String> reminders
    ) {

        AlarmManager alarmManager =
                (AlarmManager)
                        getSystemService(
                                ALARM_SERVICE
                        );


        if (alarmManager == null) {

            return;

        }


        for (
                String reminder :
                reminders
        ) {

            Calendar eventCalendar =
                    getEventCalendar(
                            date,
                            time
                    );


            if (eventCalendar == null) {

                continue;

            }


            long reminderOffset =
                    getReminderOffset(
                            reminder
                    );


            long triggerTime =
                    eventCalendar.getTimeInMillis()
                            - reminderOffset;


            if (
                    triggerTime <=
                            System.currentTimeMillis()
            ) {

                continue;

            }


            int notificationId =
                    getNotificationId(
                            eventId,
                            reminder
                    );


            Intent intent =
                    new Intent(
                            this,
                            NotificationReceiver.class
                    );


            intent.putExtra(
                    "title",
                    "🔔 " + title
            );


            intent.putExtra(
                    "message",
                    getReminderMessage(
                            reminder
                    )
            );


            PendingIntent pendingIntent =
                    PendingIntent.getBroadcast(
                            this,
                            notificationId,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT
                                    |
                                    PendingIntent.FLAG_IMMUTABLE
                    );


            if (
                    android.os.Build.VERSION.SDK_INT >=
                            android.os.Build.VERSION_CODES.S
            ) {

                if (
                        alarmManager.canScheduleExactAlarms()
                ) {

                    alarmManager.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerTime,
                            pendingIntent
                    );

                } else {

                    alarmManager.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerTime,
                            pendingIntent
                    );

                }

            } else {

                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                );

            }

        }

    }


    // =====================================================
    // GET EVENT CALENDAR
    // =====================================================

    private Calendar getEventCalendar(
            String date,
            String time
    ) {

        try {

            SimpleDateFormat format =
                    new SimpleDateFormat(
                            "yyyy-MM-dd HH:mm",
                            Locale.getDefault()
                    );


            Calendar calendar =
                    Calendar.getInstance();


            calendar.setTime(
                    format.parse(
                            date + " " + time
                    )
            );


            return calendar;

        } catch (Exception e) {

            return null;

        }

    }


    // =====================================================
    // GET REMINDER OFFSET
    // =====================================================

    private long getReminderOffset(
            String reminder
    ) {

        if (
                reminder.equals(
                        "At event time"
                )
        ) {

            return 0;

        }


        if (
                reminder.equals(
                        "5 minutes before"
                )
        ) {

            return 5 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "10 minutes before"
                )
        ) {

            return 10 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "15 minutes before"
                )
        ) {

            return 15 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "30 minutes before"
                )
        ) {

            return 30 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "1 hour before"
                )
        ) {

            return 60 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "2 hours before"
                )
        ) {

            return 2 * 60 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "3 hours before"
                )
        ) {

            return 3 * 60 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "6 hours before"
                )
        ) {

            return 6 * 60 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "12 hours before"
                )
        ) {

            return 12 * 60 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "1 day before"
                )
        ) {

            return 24 * 60 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "2 days before"
                )
        ) {

            return 2 * 24 * 60 * 60 * 1000L;

        }


        if (
                reminder.equals(
                        "1 week before"
                )
        ) {

            return 7 * 24 * 60 * 60 * 1000L;

        }


        return 0;

    }


    // =====================================================
// REMINDER MESSAGE
// =====================================================

    private String getReminderMessage(
            String reminder
    ) {

        if (
                reminder.equals(
                        "At event time"
                )
        ) {

            return "📅 Your event is starting now!";

        }


        if (
                reminder.equals(
                        "5 minutes before"
                )
        ) {

            return "🔔 Your event is coming up in 5 minutes!";

        }


        if (
                reminder.equals(
                        "10 minutes before"
                )
        ) {

            return "🔔 Your event is coming up in 10 minutes!";

        }


        if (
                reminder.equals(
                        "15 minutes before"
                )
        ) {

            return "🔔 Your event is coming up in 15 minutes!";

        }


        if (
                reminder.equals(
                        "30 minutes before"
                )
        ) {

            return "🔔 Your event is coming up in 30 minutes!";

        }


        if (
                reminder.equals(
                        "1 hour before"
                )
        ) {

            return "🔔 Your event is coming up in 1 hour!";

        }


        if (
                reminder.equals(
                        "2 hours before"
                )
        ) {

            return "🔔 Your event is coming up in 2 hours!";

        }


        if (
                reminder.equals(
                        "3 hours before"
                )
        ) {

            return "🔔 Your event is coming up in 3 hours!";

        }


        if (
                reminder.equals(
                        "6 hours before"
                )
        ) {

            return "🔔 Your event is coming up in 6 hours!";

        }


        if (
                reminder.equals(
                        "12 hours before"
                )
        ) {

            return "🔔 Your event is coming up in 12 hours!";

        }


        if (
                reminder.equals(
                        "1 day before"
                )
        ) {

            return "🔔 Your event is coming up tomorrow!";

        }


        if (
                reminder.equals(
                        "2 days before"
                )
        ) {

            return "🔔 Your event is coming up in 2 days!";

        }


        if (
                reminder.equals(
                        "1 week before"
                )
        ) {

            return "🔔 Your event is coming up in 1 week!";

        }


        return "🔔 Your event is coming up soon!";

    }


    // =====================================================
    // NOTIFICATION ID
    // =====================================================

    private int getNotificationId(
            long eventId,
            String reminder
    ) {

        return Math.abs(
                (
                        String.valueOf(eventId)
                                + reminder
                ).hashCode()
        );

    }


    // =====================================================
    // CANCEL EVENT NOTIFICATIONS
    // =====================================================

    private void cancelEventNotifications(
            long eventId
    ) {

        AlarmManager alarmManager =
                (AlarmManager)
                        getSystemService(
                                ALARM_SERVICE
                        );


        if (alarmManager == null) {

            return;

        }


        ArrayList<String> reminders =
                getEventReminders(
                        eventId
                );


        for (
                String reminder :
                reminders
        ) {

            int notificationId =
                    getNotificationId(
                            eventId,
                            reminder
                    );


            Intent intent =
                    new Intent(
                            this,
                            NotificationReceiver.class
                    );


            PendingIntent pendingIntent =
                    PendingIntent.getBroadcast(
                            this,
                            notificationId,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT
                                    |
                                    PendingIntent.FLAG_IMMUTABLE
                    );


            alarmManager.cancel(
                    pendingIntent
            );


            pendingIntent.cancel();

        }

    }


    // =====================================================
    // SHOW EVENT + QUEST LIST
    // =====================================================

    private void showEventList(
            int day
    ) {

        String date =
                createDatabaseDate(day);


        LinearLayout itemLayout =
                new LinearLayout(this);


        itemLayout.setOrientation(
                LinearLayout.VERTICAL
        );


        itemLayout.setPadding(
                35,
                5,
                35,
                5
        );


        // =================================================
        // EVENTS
        // =================================================

        Cursor eventCursor =
                db.query(
                        "calendar_events",
                        new String[]{
                                "event_id",
                                "title",
                                "type",
                                "description",
                                "time",
                                "repeat",
                                "reminder"
                        },
                        "user_id = ? AND date = ?",
                        new String[]{
                                String.valueOf(userId),
                                date
                        },
                        null,
                        null,
                        "time ASC"
                );


        if (eventCursor.moveToFirst()) {

            TextView eventHeading =
                    new TextView(this);

            eventHeading.setText(
                    "📅 EVENTS"
            );

            eventHeading.setTextColor(
                    Color.DKGRAY
            );

            eventHeading.setTextSize(
                    14
            );

            eventHeading.setTypeface(
                    null,
                    android.graphics.Typeface.BOLD
            );

            eventHeading.setPadding(
                    0,
                    10,
                    0,
                    8
            );

            itemLayout.addView(
                    eventHeading
            );


            do {

                long eventId =
                        eventCursor.getLong(
                                eventCursor.getColumnIndexOrThrow(
                                        "event_id"
                                )
                        );


                String title =
                        eventCursor.getString(
                                eventCursor.getColumnIndexOrThrow(
                                        "title"
                                )
                        );


                String type =
                        eventCursor.getString(
                                eventCursor.getColumnIndexOrThrow(
                                        "type"
                                )
                        );


                String time =
                        eventCursor.getString(
                                eventCursor.getColumnIndexOrThrow(
                                        "time"
                                )
                        );


                TextView eventView =
                        new TextView(this);


                eventView.setText(
                        "●  " +
                                title +
                                "\n" +
                                type +
                                " • " +
                                time
                );


                eventView.setTextColor(
                        Color.BLACK
                );


                eventView.setTextSize(
                        15
                );


                eventView.setPadding(
                        12,
                        14,
                        12,
                        14
                );


                eventView.setOnClickListener(
                        view -> {

                            showEventDetails(
                                    eventId
                            );

                        }
                );


                itemLayout.addView(
                        eventView
                );


            } while (eventCursor.moveToNext());

        }


        eventCursor.close();


        // =================================================
        // PENDING QUESTS ONLY
        // =================================================

        Cursor questCursor =
                db.query(
                        "quests",
                        new String[]{
                                "quest_id",
                                "title",
                                "category",
                                "difficulty",
                                "status",
                                "xp"
                        },
                        "user_id = ? AND deadline = ? AND status != ?",
                        new String[]{
                                String.valueOf(userId),
                                formatQuestDeadline(
                                        date
                                ),
                                "Completed"
                        },
                        null,
                        null,
                        "status ASC, title ASC"
                );


        if (questCursor.moveToFirst()) {

            TextView questHeading =
                    new TextView(this);

            questHeading.setText(
                    "⚔ QUESTS"
            );

            questHeading.setTextColor(
                    Color.DKGRAY
            );

            questHeading.setTextSize(
                    14
            );

            questHeading.setTypeface(
                    null,
                    android.graphics.Typeface.BOLD
            );

            questHeading.setPadding(
                    0,
                    18,
                    0,
                    8
            );

            itemLayout.addView(
                    questHeading
            );


            do {

                long questId =
                        questCursor.getLong(
                                questCursor.getColumnIndexOrThrow(
                                        "quest_id"
                                )
                        );


                String title =
                        questCursor.getString(
                                questCursor.getColumnIndexOrThrow(
                                        "title"
                                )
                        );


                String category =
                        questCursor.getString(
                                questCursor.getColumnIndexOrThrow(
                                        "category"
                                )
                        );


                String difficulty =
                        questCursor.getString(
                                questCursor.getColumnIndexOrThrow(
                                        "difficulty"
                                )
                        );


                String status =
                        questCursor.getString(
                                questCursor.getColumnIndexOrThrow(
                                        "status"
                                )
                        );


                int xp =
                        questCursor.getInt(
                                questCursor.getColumnIndexOrThrow(
                                        "xp"
                                )
                        );


                TextView questView =
                        new TextView(this);


                questView.setText(
                        "⚔  " +
                                title +
                                "\n" +
                                category +
                                " • " +
                                difficulty +
                                " • +" +
                                xp +
                                " XP" +
                                "\n" +
                                "Status: " +
                                status
                );


                questView.setTextColor(
                        Color.BLACK
                );


                questView.setTextSize(
                        15
                );


                questView.setPadding(
                        12,
                        14,
                        12,
                        14
                );


                questView.setOnClickListener(
                        view -> {

                            Intent intent =
                                    new Intent(
                                            calender.this,
                                            quest_view.class
                                    );


                            intent.putExtra(
                                    "USER_ID",
                                    userId
                            );


                            intent.putExtra(
                                    "QUEST_ID",
                                    questId
                            );


                            startActivity(
                                    intent
                            );

                        }
                );


                itemLayout.addView(
                        questView
                );


            } while (questCursor.moveToNext());

        }


        questCursor.close();


        // =================================================
        // DIALOG
        // =================================================

        new AlertDialog.Builder(this)

                .setTitle(
                        formattedDate(day)
                )

                .setView(
                        itemLayout
                )

                .setNegativeButton(
                        "CLOSE",
                        null
                )

                .setPositiveButton(
                        "+ ADD EVENT",
                        (dialog, which) ->
                                showAddEventDialog()
                )

                .show();

    }


    // =====================================================
    // FORMAT QUEST DEADLINE
    // =====================================================

    private String formatQuestDeadline(
            String databaseDate
    ) {

        try {

            SimpleDateFormat databaseFormat =
                    new SimpleDateFormat(
                            "yyyy-MM-dd",
                            Locale.getDefault()
                    );


            SimpleDateFormat questFormat =
                    new SimpleDateFormat(
                            "dd / MM / yyyy",
                            Locale.getDefault()
                    );


            Calendar date =
                    Calendar.getInstance();


            date.setTime(
                    databaseFormat.parse(
                            databaseDate
                    )
            );


            return questFormat.format(
                    date.getTime()
            );

        } catch (Exception e) {

            return "";

        }

    }


    // =====================================================
    // SHOW EVENT DETAILS
    // =====================================================

    private void showEventDetails(
            long eventId
    ) {

        Cursor cursor =
                db.query(
                        "calendar_events",
                        new String[]{
                                "title",
                                "type",
                                "description",
                                "date",
                                "time",
                                "repeat",
                                "reminder"
                        },
                        "event_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(eventId),
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (!cursor.moveToFirst()) {

            cursor.close();

            return;

        }


        String title =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "title"
                        )
                );


        String type =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "type"
                        )
                );


        String description =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "description"
                        )
                );


        String time =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "time"
                        )
                );


        String repeat =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "repeat"
                        )
                );


        String oldReminder =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "reminder"
                        )
                );


        cursor.close();


        ArrayList<String> reminders =
                getEventReminders(
                        eventId
                );


        String reminderText;


        if (!reminders.isEmpty()) {

            StringBuilder builder =
                    new StringBuilder();


            for (
                    String reminder :
                    reminders
            ) {

                if (builder.length() > 0) {

                    builder.append("\n");

                }

                builder.append(
                        "🔔 "
                );

                builder.append(
                        reminder
                );

            }


            reminderText =
                    builder.toString();

        } else {

            reminderText =
                    oldReminder == null ||
                            oldReminder.isEmpty()
                            ? "None"
                            : oldReminder;

        }


        String message =
                "TYPE\n"
                        + type
                        + "\n\n"
                        + "TIME\n"
                        + time
                        + "\n\n"
                        + "DESCRIPTION\n"
                        + (
                        description == null ||
                                description.isEmpty()
                                ? "No description added."
                                : description
                )
                        + "\n\n"
                        + "REPEAT\n"
                        + repeat
                        + "\n\n"
                        + "REMINDERS\n"
                        + reminderText;


        new AlertDialog.Builder(this)

                .setTitle(
                        title
                )

                .setMessage(
                        message
                )

                .setNegativeButton(
                        "DELETE",
                        (dialog, which) -> {

                            deleteEvent(
                                    eventId
                            );

                        }
                )

                .setNeutralButton(
                        "EDIT",
                        (dialog, which) -> {

                            showEditEventDialog(
                                    eventId
                            );

                        }
                )

                .setPositiveButton(
                        "CLOSE",
                        null
                )

                .show();

    }


    // =====================================================
    // EDIT EVENT DIALOG
    // =====================================================

    private void showEditEventDialog(
            long eventId
    ) {

        Cursor cursor =
                db.query(
                        "calendar_events",
                        new String[]{
                                "title",
                                "type",
                                "description",
                                "time",
                                "repeat"
                        },
                        "event_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(eventId),
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (!cursor.moveToFirst()) {

            cursor.close();

            Toast.makeText(
                    this,
                    "Event not found.",
                    Toast.LENGTH_SHORT
            ).show();

            return;

        }


        String oldTitle =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "title"
                        )
                );


        String oldType =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "type"
                        )
                );


        String oldDescription =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "description"
                        )
                );


        String oldTime =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "time"
                        )
                );


        String oldRepeat =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "repeat"
                        )
                );


        cursor.close();


        ArrayList<String> selectedReminders =
                getEventReminders(
                        eventId
                );


        LinearLayout layout =
                new LinearLayout(this);


        layout.setOrientation(
                LinearLayout.VERTICAL
        );


        layout.setPadding(
                45,
                10,
                45,
                5
        );


        // =====================================
        // TITLE
        // =====================================

        EditText titleInput =
                new EditText(this);

        titleInput.setHint(
                "Event title"
        );

        titleInput.setText(
                oldTitle
        );

        titleInput.setTextColor(
                Color.BLACK
        );

        titleInput.setHintTextColor(
                Color.GRAY
        );

        layout.addView(
                titleInput
        );


        // =====================================
        // TYPE
        // =====================================

        Spinner typeSpinner =
                new Spinner(this);


        String[] eventTypes = {

                "Exam",
                "Assignment",
                "Birthday",
                "Meeting",
                "Appointment",
                "College Event",
                "Other"

        };


        ArrayAdapter<String> typeAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        eventTypes
                );


        typeAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );


        typeSpinner.setAdapter(
                typeAdapter
        );


        for (
                int i = 0;
                i < eventTypes.length;
                i++
        ) {

            if (
                    eventTypes[i].equals(
                            oldType
                    )
            ) {

                typeSpinner.setSelection(
                        i
                );

                break;

            }

        }


        layout.addView(
                typeSpinner
        );


        // =====================================
        // DESCRIPTION
        // =====================================

        EditText descriptionInput =
                new EditText(this);

        descriptionInput.setHint(
                "Description"
        );

        descriptionInput.setText(
                oldDescription == null
                        ? ""
                        : oldDescription
        );

        descriptionInput.setTextColor(
                Color.BLACK
        );

        descriptionInput.setHintTextColor(
                Color.GRAY
        );

        descriptionInput.setMinLines(
                2
        );

        layout.addView(
                descriptionInput
        );


        // =====================================
        // TIME
        // =====================================

        TimePicker timePicker =
                new TimePicker(this);

        timePicker.setIs24HourView(
                false
        );


        if (
                oldTime != null &&
                        oldTime.contains(":")
        ) {

            try {

                String[] timeParts =
                        oldTime.split(":");

                int oldHour =
                        Integer.parseInt(
                                timeParts[0]
                        );

                int oldMinute =
                        Integer.parseInt(
                                timeParts[1]
                        );

                timePicker.setHour(
                        oldHour
                );

                timePicker.setMinute(
                        oldMinute
                );

            } catch (Exception ignored) {

            }

        }


        layout.addView(
                timePicker
        );


        // =====================================
        // REPEAT
        // =====================================

        Spinner repeatSpinner =
                new Spinner(this);


        String[] repeatOptions = {

                "Does not repeat",
                "Daily",
                "Weekly",
                "Monthly"

        };


        ArrayAdapter<String> repeatAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        repeatOptions
                );


        repeatAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );


        repeatSpinner.setAdapter(
                repeatAdapter
        );


        for (
                int i = 0;
                i < repeatOptions.length;
                i++
        ) {

            if (
                    repeatOptions[i].equals(
                            oldRepeat
                    )
            ) {

                repeatSpinner.setSelection(
                        i
                );

                break;

            }

        }


        layout.addView(
                repeatSpinner
        );


        // =====================================
        // REMINDERS TITLE
        // =====================================

        TextView reminderTitle =
                new TextView(this);

        reminderTitle.setText(
                "REMINDERS"
        );

        reminderTitle.setTextSize(
                14
        );

        reminderTitle.setTypeface(
                null,
                android.graphics.Typeface.BOLD
        );

        reminderTitle.setTextColor(
                Color.DKGRAY
        );

        reminderTitle.setPadding(
                0,
                20,
                0,
                8
        );

        layout.addView(
                reminderTitle
        );


        // =====================================
        // REMINDER CONTAINER
        // =====================================

        LinearLayout reminderContainer =
                new LinearLayout(this);

        reminderContainer.setOrientation(
                LinearLayout.VERTICAL
        );

        layout.addView(
                reminderContainer
        );


        refreshReminderList(
                selectedReminders,
                reminderContainer
        );


        // =====================================
        // ADD REMINDER BUTTON
        // =====================================

        Button addReminderButton =
                new Button(this);

        addReminderButton.setText(
                "+ ADD REMINDER"
        );

        layout.addView(
                addReminderButton
        );


        addReminderButton.setOnClickListener(
                view -> {

                    showReminderPicker(
                            selectedReminders,
                            reminderContainer
                    );

                }
        );


        // =====================================
        // DIALOG
        // =====================================

        new AlertDialog.Builder(this)

                .setTitle(
                        "Edit Event"
                )

                .setMessage(
                        "Update your event details"
                )

                .setView(
                        layout
                )

                .setNegativeButton(
                        "CANCEL",
                        null
                )

                .setPositiveButton(
                        "SAVE CHANGES",
                        (dialog, which) -> {

                            String title =
                                    titleInput
                                            .getText()
                                            .toString()
                                            .trim();


                            String description =
                                    descriptionInput
                                            .getText()
                                            .toString()
                                            .trim();


                            if (
                                    title.isEmpty()
                            ) {

                                Toast.makeText(
                                        this,
                                        "Enter an event title.",
                                        Toast.LENGTH_SHORT
                                ).show();

                                return;

                            }


                            int hour =
                                    timePicker
                                            .getHour();


                            int minute =
                                    timePicker
                                            .getMinute();


                            String time =
                                    String.format(
                                            Locale.getDefault(),
                                            "%02d:%02d",
                                            hour,
                                            minute
                                    );


                            String type =
                                    typeSpinner
                                            .getSelectedItem()
                                            .toString();


                            String repeat =
                                    repeatSpinner
                                            .getSelectedItem()
                                            .toString();


                            updateEvent(
                                    eventId,
                                    title,
                                    type,
                                    description,
                                    time,
                                    repeat,
                                    selectedReminders
                            );

                        }
                )

                .show();

    }


    // =====================================================
    // UPDATE EVENT
    // =====================================================

    private void updateEvent(
            long eventId,
            String title,
            String type,
            String description,
            String time,
            String repeat,
            ArrayList<String> reminders
    ) {

        // =====================================
        // CANCEL OLD NOTIFICATIONS FIRST
        // =====================================

        cancelEventNotifications(
                eventId
        );


        ContentValues values =
                new ContentValues();


        values.put(
                "title",
                title
        );

        values.put(
                "type",
                type
        );

        values.put(
                "description",
                description
        );

        values.put(
                "time",
                time
        );

        values.put(
                "repeat",
                repeat
        );

        values.put(
                "reminder",
                reminders.isEmpty()
                        ? "None"
                        : reminders.size()
                          + " reminder(s)"
        );


        int updated =
                db.update(
                        "calendar_events",
                        values,
                        "event_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(eventId),
                                String.valueOf(userId)
                        }
                );


        if (updated == 0) {

            Toast.makeText(
                    this,
                    "Could not update event.",
                    Toast.LENGTH_SHORT
            ).show();

            return;

        }


        // =====================================
        // REMOVE OLD REMINDERS
        // =====================================

        db.delete(
                "event_reminders",
                "event_id = ?",
                new String[]{
                        String.valueOf(eventId)
                }
        );


        // =====================================
        // SAVE UPDATED REMINDERS
        // =====================================

        for (
                String reminder :
                reminders
        ) {

            ContentValues reminderValues =
                    new ContentValues();


            reminderValues.put(
                    "event_id",
                    eventId
            );


            reminderValues.put(
                    "reminder_time",
                    reminder
            );


            db.insert(
                    "event_reminders",
                    null,
                    reminderValues
            );

        }


        // =====================================
        // GET EVENT DATE
        // =====================================

        String eventDate = null;


        Cursor dateCursor =
                db.query(
                        "calendar_events",
                        new String[]{
                                "date"
                        },
                        "event_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(eventId),
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (dateCursor.moveToFirst()) {

            eventDate =
                    dateCursor.getString(
                            dateCursor.getColumnIndexOrThrow(
                                    "date"
                            )
                    );

        }


        dateCursor.close();


        // =====================================
        // SCHEDULE UPDATED NOTIFICATIONS
        // =====================================

        if (eventDate != null) {

            scheduleEventNotifications(
                    eventId,
                    title,
                    eventDate,
                    time,
                    reminders
            );

        }


        Toast.makeText(
                this,
                "Event updated successfully.",
                Toast.LENGTH_SHORT
        ).show();


        buildCalendar();


        if (selectedDay != -1) {

            updateSelectedDate(
                    selectedDay
            );

        }

    }


    // =====================================================
    // GET EVENT REMINDERS
    // =====================================================

    private ArrayList<String> getEventReminders(
            long eventId
    ) {

        ArrayList<String> reminders =
                new ArrayList<>();


        Cursor cursor =
                db.query(
                        "event_reminders",
                        new String[]{
                                "reminder_time"
                        },
                        "event_id = ?",
                        new String[]{
                                String.valueOf(eventId)
                        },
                        null,
                        null,
                        "reminder_id ASC"
                );


        while (cursor.moveToNext()) {

            String reminder =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "reminder_time"
                            )
                    );


            reminders.add(
                    reminder
            );

        }


        cursor.close();


        return reminders;

    }


    // =====================================================
    // DELETE EVENT
    // =====================================================

    private void deleteEvent(
            long eventId
    ) {

        // =====================================
        // CANCEL NOTIFICATIONS
        // =====================================

        cancelEventNotifications(
                eventId
        );


        db.delete(
                "event_reminders",
                "event_id = ?",
                new String[]{
                        String.valueOf(eventId)
                }
        );


        int deleted =
                db.delete(
                        "calendar_events",
                        "event_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(eventId),
                                String.valueOf(userId)
                        }
                );


        if (deleted > 0) {

            Toast.makeText(
                    this,
                    "Event deleted.",
                    Toast.LENGTH_SHORT
            ).show();

        }


        buildCalendar();


        if (selectedDay != -1) {

            updateSelectedDate(
                    selectedDay
            );

        }

    }


    // =====================================================
    // GET EVENT COUNT
    // =====================================================

    private int getEventCount(
            int day
    ) {

        String date =
                createDatabaseDate(day);


        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) FROM calendar_events " +
                                "WHERE user_id = ? AND date = ?",
                        new String[]{
                                String.valueOf(userId),
                                date
                        }
                );


        int count = 0;


        if (cursor.moveToFirst()) {

            count =
                    cursor.getInt(0);

        }


        cursor.close();


        return count;

    }


    // =====================================================
    // GET PENDING QUEST COUNT
    // =====================================================

    private int getQuestCount(
            int day
    ) {

        String databaseDate =
                createDatabaseDate(day);


        String questDate =
                formatQuestDeadline(
                        databaseDate
                );


        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) FROM quests " +
                                "WHERE user_id = ? " +
                                "AND deadline = ? " +
                                "AND status != ?",
                        new String[]{
                                String.valueOf(userId),
                                questDate,
                                "Completed"
                        }
                );


        int count = 0;


        if (cursor.moveToFirst()) {

            count =
                    cursor.getInt(0);

        }


        cursor.close();


        return count;

    }


    // =====================================================
    // RESET
    // =====================================================

    private void resetSelection() {

        selectedDay = -1;


        txtSelectedDate.setText(
                "No date selected"
        );


        txtDayStatus.setText(
                "Choose a date to plan an event."
        );

    }


    // =====================================================
    // DATABASE DATE
    // =====================================================

    private String createDatabaseDate(
            int day
    ) {

        Calendar date =
                (Calendar)
                        currentMonth.clone();


        date.set(
                Calendar.DAY_OF_MONTH,
                day
        );


        return new SimpleDateFormat(
                "yyyy-MM-dd",
                Locale.getDefault()
        ).format(
                date.getTime()
        );

    }


    // =====================================================
    // FORMATTED DATE
    // =====================================================

    private String formattedDate(
            int day
    ) {

        Calendar date =
                (Calendar)
                        currentMonth.clone();


        date.set(
                Calendar.DAY_OF_MONTH,
                day
        );


        SimpleDateFormat format =
                new SimpleDateFormat(
                        "EEEE, dd MMMM yyyy",
                        Locale.getDefault()
                );


        return format.format(
                date.getTime()
        );

    }


    // =====================================================
    // TODAY
    // =====================================================

    private boolean isToday(
            int day
    ) {

        Calendar today =
                Calendar.getInstance();


        return today.get(
                Calendar.YEAR
        )
                ==
                currentMonth.get(
                        Calendar.YEAR
                )

                &&

                today.get(
                        Calendar.MONTH
                )
                        ==
                        currentMonth.get(
                                Calendar.MONTH
                        )

                &&

                today.get(
                        Calendar.DAY_OF_MONTH
                )
                        ==
                        day;

    }


    // =====================================================
    // NORMAL DATE BACKGROUND
    // =====================================================

    private GradientDrawable roundedBackground(
            int color
    ) {

        GradientDrawable drawable =
                new GradientDrawable();


        drawable.setColor(
                color
        );


        drawable.setCornerRadius(
                18
        );


        return drawable;

    }


    // =====================================================
    // TODAY BACKGROUND
    // =====================================================

    private GradientDrawable todayBackground() {

        GradientDrawable drawable =
                new GradientDrawable();


        drawable.setColor(
                Color.rgb(
                        48,
                        39,
                        62
                )
        );


        drawable.setCornerRadius(
                18
        );


        drawable.setStroke(
                2,
                Color.rgb(
                        236,
                        177,
                        224
                )
        );


        return drawable;

    }


    @Override
    protected void onDestroy() {

        if (db != null && db.isOpen()) {

            db.close();

        }

        if (dbHelper != null) {

            dbHelper.close();

        }

        super.onDestroy();

    }

}
package com.example.mad;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class data_export extends AppCompatActivity {

    private static final int FILE_PICKER_REQUEST = 100;

    private Button btnAddFile;

    private TextView txtSelectedFile;
    private TextView txtFileCount;
    private TextView txtCategoryTitle;
    private TextView txtCategoryEmpty;

    private LinearLayout selectedFileContainer;
    private LinearLayout categoryFilesContainer;
    private LinearLayout categoryFileList;

    private LinearLayout cardCollegeFiles;
    private LinearLayout cardImportantDocuments;
    private LinearLayout cardMemories;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;

    private String selectedCategory = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_data_export
        );

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();

        btnAddFile =
                findViewById(
                        R.id.btnAddFile
                );

        txtSelectedFile =
                findViewById(
                        R.id.txtSelectedFile
                );

        txtFileCount =
                findViewById(
                        R.id.txtFileCount
                );

        txtCategoryTitle =
                findViewById(
                        R.id.txtCategoryTitle
                );

        txtCategoryEmpty =
                findViewById(
                        R.id.txtCategoryEmpty
                );

        selectedFileContainer =
                findViewById(
                        R.id.selectedFileContainer
                );

        categoryFilesContainer =
                findViewById(
                        R.id.categoryFilesContainer
                );

        categoryFileList =
                findViewById(
                        R.id.categoryFileList
                );

        cardCollegeFiles =
                findViewById(
                        R.id.cardCollegeFiles
                );

        cardImportantDocuments =
                findViewById(
                        R.id.cardImportantDocuments
                );

        cardMemories =
                findViewById(
                        R.id.cardMemories
                );

        updateFileCount();


        // =====================================
        // CATEGORY CARDS
        // =====================================

        cardCollegeFiles.setOnClickListener(
                v -> {

                    selectedCategory =
                            "College";

                    showCategoryFiles(
                            selectedCategory
                    );

                }
        );


        cardImportantDocuments.setOnClickListener(
                v -> {

                    selectedCategory =
                            "Important Documents";

                    showCategoryFiles(
                            selectedCategory
                    );

                }
        );


        cardMemories.setOnClickListener(
                v -> {

                    selectedCategory =
                            "Memories";

                    showCategoryFiles(
                            selectedCategory
                    );

                }
        );


        // =====================================
        // ADD FILE
        // =====================================

        btnAddFile.setOnClickListener(
                v -> showCategoryDialog()
        );
    }


    // =====================================
    // CATEGORY SELECTION
    // =====================================

    private void showCategoryDialog() {

        String[] categories = {
                "College Files",
                "Important Documents",
                "Pictures and Memories"
        };

        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);

        builder.setTitle(
                "Choose where to save"
        );

        builder.setItems(
                categories,
                (dialog, which) -> {

                    if (which == 0) {

                        selectedCategory =
                                "College";

                    } else if (which == 1) {

                        selectedCategory =
                                "Important Documents";

                    } else {

                        selectedCategory =
                                "Memories";
                    }

                    openFilePicker();
                }
        );

        builder.show();
    }


    // =====================================
    // FILE PICKER
    // =====================================

    private void openFilePicker() {

        if (selectedCategory == null) {

            showCategoryDialog();

            return;
        }

        Intent intent =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        intent.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        intent.setType(
                "*/*"
        );

        startActivityForResult(
                intent,
                FILE_PICKER_REQUEST
        );
    }


    // =====================================
    // FILE RESULT
    // =====================================

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (
                requestCode ==
                        FILE_PICKER_REQUEST
                        &&
                        resultCode ==
                                RESULT_OK
                        &&
                        data != null
        ) {

            Uri selectedFileUri =
                    data.getData();

            if (selectedFileUri != null) {

                saveSelectedFile(
                        selectedFileUri
                );
            }
        }
    }


    // =====================================
    // SAVE FILE
    // =====================================

    private void saveSelectedFile(
            Uri uri) {

        if (userId == -1) {

            Toast.makeText(
                    this,
                    "User information not found",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (selectedCategory == null) {

            Toast.makeText(
                    this,
                    "Please choose a category",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String originalFileName =
                getFileName(uri);

        if (
                originalFileName == null
                        ||
                        originalFileName
                                .trim()
                                .isEmpty()
        ) {

            originalFileName =
                    "Saved File";
        }

        try {

            // =====================================
            // CREATE VAULT DIRECTORY
            // =====================================

            File vaultDirectory =
                    new File(
                            getFilesDir(),
                            "life_vault"
                    );

            if (
                    !vaultDirectory.exists()
            ) {

                vaultDirectory.mkdirs();
            }


            // =====================================
            // CREATE UNIQUE FILE NAME
            // =====================================

            String timeStamp =
                    new SimpleDateFormat(
                            "yyyyMMdd_HHmmss",
                            Locale.getDefault()
                    ).format(
                            new Date()
                    );

            String savedFileName =
                    timeStamp
                            + "_"
                            + originalFileName;

            File destinationFile =
                    new File(
                            vaultDirectory,
                            savedFileName
                    );


            // =====================================
            // READ ORIGINAL FILE
            // =====================================

            InputStream inputStream =
                    getContentResolver()
                            .openInputStream(uri);

            if (
                    inputStream == null
            ) {

                Toast.makeText(
                        this,
                        "Unable to read selected file",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            FileOutputStream outputStream =
                    new FileOutputStream(
                            destinationFile
                    );

            byte[] buffer =
                    new byte[4096];

            int bytesRead;

            while (
                    (
                            bytesRead =
                                    inputStream.read(
                                            buffer
                                    )
                    )
                            != -1
            ) {

                outputStream.write(
                        buffer,
                        0,
                        bytesRead
                );
            }

            outputStream.flush();

            outputStream.close();

            inputStream.close();


            // =====================================
            // FILE TYPE
            // =====================================

            String fileType =
                    getContentResolver()
                            .getType(uri);

            if (
                    fileType == null
                            ||
                            fileType
                                    .trim()
                                    .isEmpty()
            ) {

                fileType =
                        "unknown";
            }


            // =====================================
            // CREATED DATE
            // =====================================

            String createdDate =
                    new SimpleDateFormat(
                            "yyyy-MM-dd HH:mm:ss",
                            Locale.getDefault()
                    ).format(
                            new Date()
                    );


            // =====================================
            // SAVE METADATA IN SQLITE
            // =====================================

            ContentValues values =
                    new ContentValues();

            values.put(
                    "user_id",
                    userId
            );

            values.put(
                    "title",
                    originalFileName
            );

            values.put(
                    "file_name",
                    originalFileName
            );

            values.put(
                    "file_path",
                    destinationFile
                            .getAbsolutePath()
            );

            values.put(
                    "file_type",
                    fileType
            );

            values.put(
                    "category",
                    selectedCategory
            );

            values.put(
                    "is_important",
                    0
            );

            values.put(
                    "created_date",
                    createdDate
            );

            long insertedId =
                    db.insert(
                            "vault_files",
                            null,
                            values
                    );

            if (
                    insertedId == -1
            ) {

                destinationFile.delete();

                Toast.makeText(
                        this,
                        "File could not be saved",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }


            // =====================================
            // UPDATE UI
            // =====================================

            txtSelectedFile.setText(
                    originalFileName
                            + "\n"
                            + selectedCategory
            );

            selectedFileContainer
                    .setVisibility(
                            View.VISIBLE
                    );

            updateFileCount();

            showCategoryFiles(
                    selectedCategory
            );

            Toast.makeText(
                    this,
                    "File saved to "
                            + getDisplayCategory(
                            selectedCategory
                    ),
                    Toast.LENGTH_SHORT
            ).show();


        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Error saving file",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================
    // SHOW FILES OF SELECTED CATEGORY
    // =====================================

    private void showCategoryFiles(
            String category) {

        if (userId == -1) {
            return;
        }

        categoryFilesContainer
                .setVisibility(
                        View.VISIBLE
                );

        txtCategoryTitle.setText(
                getDisplayCategory(
                        category
                ).toUpperCase()
        );

        categoryFileList.removeAllViews();


        Cursor cursor =
                db.rawQuery(
                        "SELECT file_id, file_name, file_type, file_path, created_date " +
                                "FROM vault_files " +
                                "WHERE user_id = ? AND category = ? " +
                                "ORDER BY file_id DESC",
                        new String[]{
                                String.valueOf(userId),
                                category
                        }
                );


        int count = 0;


        while (cursor.moveToNext()) {

            count++;


            long fileId =
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    "file_id"
                            )
                    );


            String fileName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "file_name"
                            )
                    );


            String fileType =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "file_type"
                            )
                    );


            String filePath =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "file_path"
                            )
                    );


            String createdDate =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "created_date"
                            )
                    );


            // =====================================
            // FILE CARD
            // =====================================

            LinearLayout fileCard =
                    new LinearLayout(
                            this
                    );

            fileCard.setOrientation(
                    LinearLayout.VERTICAL
            );

            fileCard.setPadding(
                    14,
                    14,
                    14,
                    14
            );

            fileCard.setBackgroundColor(
                    android.graphics.Color
                            .parseColor(
                                    "#1D1534"
                            )
            );

            fileCard.setClickable(
                    true
            );

            fileCard.setFocusable(
                    true
            );


            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            params.setMargins(
                    0,
                    0,
                    0,
                    10
            );

            fileCard.setLayoutParams(
                    params
            );


            // =====================================
            // FILE NAME
            // =====================================

            TextView nameText =
                    new TextView(
                            this
                    );

            nameText.setText(
                    "📄  "
                            + fileName
            );

            nameText.setTextColor(
                    android.graphics.Color.WHITE
            );

            nameText.setTextSize(
                    14
            );

            nameText.setTypeface(
                    null,
                    android.graphics.Typeface.BOLD
            );


            // =====================================
            // FILE DETAILS
            // =====================================

            TextView detailsText =
                    new TextView(
                            this
                    );

            detailsText.setText(
                    fileType
                            + "\n"
                            + createdDate
                            + "\n\n"
                            + "Tap to open"
            );

            detailsText.setTextColor(
                    android.graphics.Color
                            .parseColor(
                                    "#AFA3C2"
                            )
            );

            detailsText.setTextSize(
                    11
            );

            detailsText.setPadding(
                    0,
                    6,
                    0,
                    0
            );


            // =====================================
            // DELETE BUTTON
            // =====================================

            Button deleteButton =
                    new Button(
                            this
                    );

            deleteButton.setText(
                    "🗑  DELETE FILE"
            );

            deleteButton.setTextColor(
                    android.graphics.Color.WHITE
            );

            deleteButton.setTextSize(
                    12
            );

            deleteButton.setAllCaps(
                    false
            );

            deleteButton.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(
                            android.graphics.Color
                                    .parseColor(
                                            "#4A263F"
                                    )
                    )
            );


            LinearLayout.LayoutParams deleteParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            deleteParams.setMargins(
                    0,
                    12,
                    0,
                    0
            );

            deleteButton.setLayoutParams(
                    deleteParams
            );


            fileCard.addView(
                    nameText
            );

            fileCard.addView(
                    detailsText
            );

            fileCard.addView(
                    deleteButton
            );


            // =====================================
            // OPEN FILE
            // =====================================

            fileCard.setOnClickListener(
                    v -> openSavedFile(
                            filePath,
                            fileType,
                            fileName
                    )
            );


            // =====================================
            // DELETE FILE
            // =====================================

            deleteButton.setOnClickListener(
                    v -> confirmDeleteFile(
                            fileId,
                            filePath,
                            fileName,
                            category
                    )
            );


            categoryFileList.addView(
                    fileCard
            );
        }


        cursor.close();


        if (count == 0) {

            txtCategoryEmpty.setVisibility(
                    View.VISIBLE
            );

            txtCategoryEmpty.setText(
                    "No files saved here yet."
            );

        } else {

            txtCategoryEmpty.setVisibility(
                    View.GONE
            );
        }
    }


    // =====================================
    // CONFIRM DELETE
    // =====================================

    private void confirmDeleteFile(
            long fileId,
            String filePath,
            String fileName,
            String category) {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(
                        this
                );

        builder.setTitle(
                "Delete File?"
        );

        builder.setMessage(
                "Are you sure you want to permanently delete\n\n"
                        + fileName
                        + "?"
        );

        builder.setNegativeButton(
                "CANCEL",
                null
        );

        builder.setPositiveButton(
                "DELETE",
                (dialog, which) -> {

                    deleteFile(
                            fileId,
                            filePath,
                            fileName,
                            category
                    );

                }
        );

        builder.show();
    }


    // =====================================
    // DELETE FILE
    // =====================================

    private void deleteFile(
            long fileId,
            String filePath,
            String fileName,
            String category) {

        try {

            // =====================================
            // DELETE PHYSICAL FILE
            // =====================================

            if (
                    filePath != null
                            &&
                            !filePath
                                    .trim()
                                    .isEmpty()
            ) {

                File file =
                        new File(
                                filePath
                        );

                if (
                        file.exists()
                ) {

                    file.delete();
                }
            }


            // =====================================
            // DELETE SQLITE RECORD
            // =====================================

            int deletedRows =
                    db.delete(
                            "vault_files",
                            "file_id = ? AND user_id = ?",
                            new String[]{
                                    String.valueOf(
                                            fileId
                                    ),
                                    String.valueOf(
                                            userId
                                    )
                            }
                    );


            if (
                    deletedRows > 0
            ) {

                updateFileCount();

                showCategoryFiles(
                        category
                );

                Toast.makeText(
                        this,
                        "File deleted",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "File could not be deleted",
                        Toast.LENGTH_SHORT
                ).show();
            }


        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Error deleting file",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================
    // OPEN SAVED FILE
    // =====================================

    private void openSavedFile(
            String filePath,
            String fileType,
            String fileName) {

        if (
                filePath == null
                        ||
                        filePath.trim().isEmpty()
        ) {

            Toast.makeText(
                    this,
                    "File path not found",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        File file =
                new File(
                        filePath
                );


        if (
                !file.exists()
        ) {

            Toast.makeText(
                    this,
                    "Saved file could not be found",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        // =====================================
        // IMAGE
        // =====================================

        if (
                fileType != null
                        &&
                        fileType.startsWith(
                                "image/"
                        )
        ) {

            showImagePreview(
                    file,
                    fileName
            );

            return;
        }


        // =====================================
        // TEXT / CSV
        // =====================================

        if (
                isTextFile(
                        fileType,
                        fileName
                )
        ) {

            showTextPreview(
                    file,
                    fileName
            );

            return;
        }


        // =====================================
        // PDF / DOCUMENT / OTHER FILES
        // =====================================

        try {

            Uri fileUri =
                    FileProvider.getUriForFile(
                            this,
                            getPackageName()
                                    + ".fileprovider",
                            file
                    );


            Intent intent =
                    new Intent(
                            Intent.ACTION_VIEW
                    );


            String mimeType =
                    fileType;


            if (
                    mimeType == null
                            ||
                            mimeType.equals(
                                    "unknown"
                            )
                            ||
                            mimeType.trim().isEmpty()
            ) {

                mimeType =
                        getMimeType(
                                fileName
                        );
            }


            intent.setDataAndType(
                    fileUri,
                    mimeType
            );


            intent.addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            );


            intent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
            );


            try {

                startActivity(
                        intent
                );

            } catch (
                    android.content.ActivityNotFoundException e
            ) {

                Toast.makeText(
                        this,
                        "No app found to open this file",
                        Toast.LENGTH_SHORT
                ).show();
            }


        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Unable to open file",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // =====================================
    // IMAGE PREVIEW
    // =====================================

    private void showImagePreview(
            File file,
            String fileName) {

        Bitmap bitmap =
                BitmapFactory.decodeFile(
                        file.getAbsolutePath()
                );


        if (bitmap == null) {

            Toast.makeText(
                    this,
                    "Unable to display image",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        ImageView imageView =
                new ImageView(
                        this
                );


        imageView.setImageBitmap(
                bitmap
        );


        imageView.setAdjustViewBounds(
                true
        );


        imageView.setScaleType(
                ImageView.ScaleType.FIT_CENTER
        );


        int padding = 20;


        imageView.setPadding(
                padding,
                padding,
                padding,
                padding
        );


        AlertDialog dialog =
                new AlertDialog.Builder(
                        this
                )
                        .setTitle(
                                fileName
                        )
                        .setView(
                                imageView
                        )
                        .setPositiveButton(
                                "CLOSE",
                                null
                        )
                        .create();


        dialog.show();
    }


    // =====================================
    // TEXT PREVIEW
    // =====================================

    private void showTextPreview(
            File file,
            String fileName) {

        StringBuilder content =
                new StringBuilder();


        try {

            BufferedReader reader =
                    new BufferedReader(
                            new FileReader(
                                    file
                            )
                    );


            String line;


            while (
                    (
                            line =
                                    reader.readLine()
                    )
                            != null
            ) {

                content.append(
                        line
                );

                content.append(
                        "\n"
                );
            }


            reader.close();


        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Unable to read file",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        TextView textView =
                new TextView(
                        this
                );


        textView.setText(
                content.toString()
        );


        textView.setTextColor(
                android.graphics.Color.WHITE
        );


        textView.setTextSize(
                14
        );


        textView.setPadding(
                20,
                20,
                20,
                20
        );


        ScrollView scrollView =
                new ScrollView(
                        this
                );


        scrollView.addView(
                textView
        );


        AlertDialog dialog =
                new AlertDialog.Builder(
                        this
                )
                        .setTitle(
                                fileName
                        )
                        .setView(
                                scrollView
                        )
                        .setPositiveButton(
                                "CLOSE",
                                null
                        )
                        .create();


        dialog.show();
    }


    // =====================================
    // CHECK TEXT FILE
    // =====================================

    private boolean isTextFile(
            String fileType,
            String fileName) {

        if (
                fileType != null
                        &&
                        (
                                fileType.startsWith(
                                        "text/"
                                )
                                        ||
                                        fileType.equals(
                                                "application/csv"
                                        )
                        )
        ) {

            return true;
        }


        if (
                fileName == null
        ) {

            return false;
        }


        String lowerName =
                fileName.toLowerCase(
                        Locale.getDefault()
                );


        return lowerName.endsWith(
                ".txt"
        )
                ||
                lowerName.endsWith(
                        ".csv"
                );
    }


    // =====================================
    // GET MIME TYPE
    // =====================================

    private String getMimeType(
            String fileName) {

        String extension =
                android.webkit.MimeTypeMap
                        .getFileExtensionFromUrl(
                                Uri.encode(
                                        fileName
                                )
                        );


        String mimeType =
                android.webkit.MimeTypeMap
                        .getSingleton()
                        .getMimeTypeFromExtension(
                                extension
                        );


        if (
                mimeType == null
                        ||
                        mimeType.trim().isEmpty()
        ) {

            return "*/*";
        }


        return mimeType;
    }


    // =====================================
    // DISPLAY CATEGORY NAME
    // =====================================

    private String getDisplayCategory(
            String category) {

        if (
                "College".equals(
                        category
                )
        ) {

            return "College Files";

        } else if (
                "Important Documents"
                        .equals(
                                category
                        )
        ) {

            return "Important Documents";

        } else if (
                "Memories".equals(
                        category
                )
        ) {

            return "Pictures and Memories";
        }


        return "Other";
    }


    // =====================================
    // UPDATE TOTAL FILE COUNT
    // =====================================

    private void updateFileCount() {

        if (userId == -1) {

            txtFileCount.setText(
                    "0 SAVED FILES"
            );

            return;
        }


        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) " +
                                "FROM vault_files " +
                                "WHERE user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );


        int count = 0;


        if (
                cursor.moveToFirst()
        ) {

            count =
                    cursor.getInt(0);
        }


        cursor.close();


        txtFileCount.setText(
                count
                        + " SAVED FILE"
                        + (
                        count == 1
                                ? ""
                                : "S"
                )
        );
    }


    // =====================================
    // GET ORIGINAL FILE NAME
    // =====================================

    private String getFileName(
            Uri uri) {

        String result = null;


        if (
                "content".equals(
                        uri.getScheme()
                )
        ) {

            Cursor cursor =
                    getContentResolver()
                            .query(
                                    uri,
                                    null,
                                    null,
                                    null,
                                    null
                            );


            try {

                if (
                        cursor != null
                                &&
                                cursor.moveToFirst()
                ) {

                    int nameIndex =
                            cursor.getColumnIndex(
                                    OpenableColumns
                                            .DISPLAY_NAME
                            );


                    if (
                            nameIndex >= 0
                    ) {

                        result =
                                cursor.getString(
                                        nameIndex
                                );
                    }
                }


            } finally {

                if (
                        cursor != null
                ) {

                    cursor.close();
                }
            }
        }


        if (result == null) {

            result =
                    uri.getLastPathSegment();
        }


        return result;
    }
}
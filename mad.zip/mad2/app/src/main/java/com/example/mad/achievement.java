package com.example.mad;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class achievement extends AppCompatActivity {

    private LinearLayout achievementContainer;
    private LinearLayout categoryContainer;
    private TextView txtAchievementCount;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;

    private String selectedCategory = "ALL";

    private final String[] achievementKeys = {
            "first_quest",
            "quest_novice",
            "on_fire",
            "dedicated",
            "veteran",
            "legend",

            "streak_3",
            "streak_7",
            "streak_14",
            "streak_30",
            "streak_60",
            "streak_100",

            "xp_hunter",
            "xp_1000",
            "xp_2500",
            "xp_5000",
            "xp_10000",
            "xp_25000",

            "coins_100",
            "coins_500",
            "coins_1000",
            "coins_2500",
            "coins_5000",

            "daily_5",
            "daily_25",
            "daily_50",
            "daily_100",
            "weekly_1",
            "weekly_5",
            "weekly_10",
            "weekly_25",

            "hard_first",
            "hard_5",
            "epic_first",
            "epic_5",

            "category_3",
            "category_5",
            "category_all"
    };

    private final String[] achievementTitles = {
            "FIRST QUEST",
            "QUEST NOVICE",
            "ON FIRE",
            "DEDICATED",
            "VETERAN",
            "LEGEND",

            "GETTING STARTED",
            "CONSISTENT",
            "UNSTOPPABLE",
            "DEDICATED STREAK",
            "LEGENDARY STREAK",
            "IMMORTAL",

            "XP HUNTER",
            "RISING HERO",
            "EXPERIENCED",
            "ELITE",
            "XP LEGEND",
            "XP MASTER",

            "FIRST FORTUNE",
            "TREASURE HUNTER",
            "WEALTHY",
            "RICH HERO",
            "COIN LEGEND",

            "DAILY STARTER",
            "DAILY GRINDER",
            "DAILY MASTER",
            "DAILY LEGEND",
            "WEEKLY WARRIOR",
            "WEEKLY CHAMPION",
            "WEEKLY MASTER",
            "WEEKLY LEGEND",

            "FIRST HARD QUEST",
            "HARD GRINDER",
            "FIRST EPIC QUEST",
            "EPIC HERO",

            "EXPLORER",
            "ADVENTURER",
            "COMPLETIONIST"
    };

    private final String[] achievementDescriptions = {
            "Complete your first quest.",
            "Complete 5 quests.",
            "Reach a 3-day streak.",
            "Reach a 7-day streak.",
            "Complete 25 quests.",
            "Complete 50 quests.",

            "Reach a 3-day streak.",
            "Reach a 7-day streak.",
            "Reach a 14-day streak.",
            "Reach a 30-day streak.",
            "Reach a 60-day streak.",
            "Reach a 100-day streak.",

            "Earn 500 total XP.",
            "Earn 1,000 total XP.",
            "Earn 2,500 total XP.",
            "Earn 5,000 total XP.",
            "Earn 10,000 total XP.",
            "Earn 25,000 total XP.",

            "Have 100 coins.",
            "Have 500 coins.",
            "Have 1,000 coins.",
            "Have 2,500 coins.",
            "Have 5,000 coins.",

            "Complete 5 Daily Challenges.",
            "Complete 25 Daily Challenges.",
            "Complete 50 Daily Challenges.",
            "Complete 100 Daily Challenges.",
            "Complete 1 Weekly Challenge.",
            "Complete 5 Weekly Challenges.",
            "Complete 10 Weekly Challenges.",
            "Complete 25 Weekly Challenges.",

            "Complete your first Hard quest.",
            "Complete 5 Hard quests.",
            "Complete your first Epic quest.",
            "Complete 5 Epic quests.",

            "Complete quests from 3 different categories.",
            "Complete quests from 5 different categories.",
            "Complete quests from every available category."
    };

    private final String[] achievementCategories = {
            "QUESTS",
            "QUESTS",
            "QUESTS",
            "QUESTS",
            "QUESTS",
            "QUESTS",

            "STREAK",
            "STREAK",
            "STREAK",
            "STREAK",
            "STREAK",
            "STREAK",

            "XP",
            "XP",
            "XP",
            "XP",
            "XP",
            "XP",

            "COINS",
            "COINS",
            "COINS",
            "COINS",
            "COINS",

            "CHALLENGES",
            "CHALLENGES",
            "CHALLENGES",
            "CHALLENGES",
            "CHALLENGES",
            "CHALLENGES",
            "CHALLENGES",
            "CHALLENGES",

            "DIFFICULTY",
            "DIFFICULTY",
            "DIFFICULTY",
            "DIFFICULTY",

            "VARIETY",
            "VARIETY",
            "VARIETY"
    };

    private final int[] achievementTargets = {
            1,
            5,
            3,
            7,
            25,
            50,

            3,
            7,
            14,
            30,
            60,
            100,

            500,
            1000,
            2500,
            5000,
            10000,
            25000,

            100,
            500,
            1000,
            2500,
            5000,

            5,
            25,
            50,
            100,
            1,
            5,
            10,
            25,

            1,
            5,
            1,
            5,

            3,
            5,
            0
    };

    private final String[] categories = {
            "ALL",
            "QUESTS",
            "STREAK",
            "XP",
            "COINS",
            "CHALLENGES",
            "DIFFICULTY",
            "VARIETY"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_achievement);

        achievementContainer =
                findViewById(
                        R.id.achievementContainer
                );

        categoryContainer =
                findViewById(
                        R.id.categoryContainer
                );

        txtAchievementCount =
                findViewById(
                        R.id.txtAchievementCount
                );

        TextView btnBack =
                findViewById(
                        R.id.btnBack
                );

        btnBack.setOnClickListener(
                view -> finish()
        );

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();

        createChallengeClaimsTable();

        createDefaultAchievements();

        createCategoryButtons();

        updateAchievements();

        loadAchievements();
    }

    private void createChallengeClaimsTable() {

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS challenge_claims (" +
                        "claim_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "challenge_type TEXT NOT NULL, " +
                        "challenge_key TEXT NOT NULL, " +
                        "period_key TEXT NOT NULL, " +
                        "claimed_date TEXT NOT NULL, " +
                        "UNIQUE(user_id, challenge_type, challenge_key, period_key)" +
                        ")"
        );
    }

    private void createDefaultAchievements() {

        if (userId == -1) {
            return;
        }

        for (int i = 0;
             i < achievementKeys.length;
             i++) {

            Cursor cursor =
                    db.query(
                            "achievements",
                            new String[]{
                                    "achievement_id"
                            },
                            "user_id = ? AND achievement_key = ?",
                            new String[]{
                                    String.valueOf(userId),
                                    achievementKeys[i]
                            },
                            null,
                            null,
                            null
                    );

            boolean exists =
                    cursor.moveToFirst();

            cursor.close();

            if (!exists) {

                ContentValues values =
                        new ContentValues();

                values.put(
                        "user_id",
                        userId
                );

                values.put(
                        "achievement_key",
                        achievementKeys[i]
                );

                values.put(
                        "title",
                        achievementTitles[i]
                );

                values.put(
                        "description",
                        achievementDescriptions[i]
                );

                values.put(
                        "unlocked",
                        0
                );

                db.insert(
                        "achievements",
                        null,
                        values
                );
            }
        }
    }

    private void updateAchievements() {

        if (userId == -1) {
            return;
        }

        int completedQuests =
                getCompletedQuestCount();

        int currentStreak =
                getCurrentStreak();

        int bestStreak =
                getBestStreak();

        int xp =
                getUserXP();

        int coins =
                getUserCoins();

        int dailyChallenges =
                getChallengeCount(
                        "DAILY"
                );

        int weeklyChallenges =
                getChallengeCount(
                        "WEEKLY"
                );

        int hardQuests =
                getDifficultyQuestCount(
                        "Hard"
                );

        int epicQuests =
                getDifficultyQuestCount(
                        "Epic"
                );

        int categoryCount =
                getCategoryCount();

        for (int i = 0;
             i < achievementKeys.length;
             i++) {

            int progress =
                    getAchievementProgress(
                            i,
                            completedQuests,
                            currentStreak,
                            bestStreak,
                            xp,
                            coins,
                            dailyChallenges,
                            weeklyChallenges,
                            hardQuests,
                            epicQuests,
                            categoryCount
                    );

            int target =
                    achievementTargets[i];

            boolean unlocked;

            if (achievementKeys[i].equals(
                    "category_all"
            )) {

                unlocked =
                        categoryCount > 0 &&
                                categoryCount ==
                                        getAvailableCategoryCount();

            } else {

                unlocked =
                        progress >= target;
            }

            if (unlocked) {

                unlockAchievement(
                        achievementKeys[i]
                );
            }
        }
    }

    private int getAchievementProgress(
            int index,
            int completedQuests,
            int currentStreak,
            int bestStreak,
            int xp,
            int coins,
            int dailyChallenges,
            int weeklyChallenges,
            int hardQuests,
            int epicQuests,
            int categoryCount) {

        String key =
                achievementKeys[index];

        if (key.equals("first_quest")) {
            return completedQuests;
        }

        if (key.equals("quest_novice")) {
            return completedQuests;
        }

        if (key.equals("on_fire")) {
            return currentStreak;
        }

        if (key.equals("dedicated")) {
            return currentStreak;
        }

        if (key.equals("veteran")) {
            return completedQuests;
        }

        if (key.equals("legend")) {
            return completedQuests;
        }

        if (key.equals("streak_3")) {
            return Math.max(
                    currentStreak,
                    bestStreak
            );
        }

        if (key.equals("streak_7")) {
            return Math.max(
                    currentStreak,
                    bestStreak
            );
        }

        if (key.equals("streak_14")) {
            return Math.max(
                    currentStreak,
                    bestStreak
            );
        }

        if (key.equals("streak_30")) {
            return Math.max(
                    currentStreak,
                    bestStreak
            );
        }

        if (key.equals("streak_60")) {
            return Math.max(
                    currentStreak,
                    bestStreak
            );
        }

        if (key.equals("streak_100")) {
            return Math.max(
                    currentStreak,
                    bestStreak
            );
        }

        if (key.startsWith("xp_") ||
                key.equals("xp_hunter")) {

            return xp;
        }

        if (key.startsWith("coins_")) {
            return coins;
        }

        if (key.startsWith("daily_")) {
            return dailyChallenges;
        }

        if (key.startsWith("weekly_")) {
            return weeklyChallenges;
        }

        if (key.equals("hard_first") ||
                key.equals("hard_5")) {

            return hardQuests;
        }

        if (key.equals("epic_first") ||
                key.equals("epic_5")) {

            return epicQuests;
        }

        if (key.equals("category_3") ||
                key.equals("category_5")) {

            return categoryCount;
        }

        if (key.equals("category_all")) {
            return categoryCount;
        }

        return 0;
    }

    private void unlockAchievement(
            String key) {

        Cursor cursor =
                db.query(
                        "achievements",
                        new String[]{
                                "unlocked"
                        },
                        "user_id = ? AND achievement_key = ?",
                        new String[]{
                                String.valueOf(userId),
                                key
                        },
                        null,
                        null,
                        null
                );

        boolean alreadyUnlocked =
                false;

        if (cursor.moveToFirst()) {

            alreadyUnlocked =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "unlocked"
                            )
                    ) == 1;
        }

        cursor.close();

        if (!alreadyUnlocked) {

            ContentValues values =
                    new ContentValues();

            values.put(
                    "unlocked",
                    1
            );

            values.put(
                    "unlocked_date",
                    System.currentTimeMillis()
            );

            db.update(
                    "achievements",
                    values,
                    "user_id = ? AND achievement_key = ?",
                    new String[]{
                            String.valueOf(userId),
                            key
                    }
            );
        }
    }

    private int getCompletedQuestCount() {

        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) FROM quests " +
                                "WHERE user_id = ? " +
                                "AND status = 'Completed'",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        int count = 0;

        if (cursor.moveToFirst()) {
            count =
                    cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    private int getCurrentStreak() {

        Cursor cursor =
                db.query(
                        "streaks",
                        new String[]{
                                "current_streak"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        int streak = 0;

        if (cursor.moveToFirst()) {

            streak =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "current_streak"
                            )
                    );
        }

        cursor.close();

        return streak;
    }

    private int getBestStreak() {

        Cursor cursor =
                db.query(
                        "streaks",
                        new String[]{
                                "best_streak"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        int streak = 0;

        if (cursor.moveToFirst()) {

            streak =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "best_streak"
                            )
                    );
        }

        cursor.close();

        return streak;
    }

    private int getUserXP() {

        Cursor cursor =
                db.query(
                        "users",
                        new String[]{
                                "xp"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        int xp = 0;

        if (cursor.moveToFirst()) {

            xp =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "xp"
                            )
                    );
        }

        cursor.close();

        return xp;
    }

    private int getUserCoins() {

        Cursor cursor =
                db.query(
                        "users",
                        new String[]{
                                "coins"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        int coins = 0;

        if (cursor.moveToFirst()) {

            coins =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "coins"
                            )
                    );
        }

        cursor.close();

        return coins;
    }

    private int getChallengeCount(
            String type) {

        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) FROM challenge_claims " +
                                "WHERE user_id = ? " +
                                "AND challenge_type = ?",
                        new String[]{
                                String.valueOf(userId),
                                type
                        }
                );

        int count = 0;

        if (cursor.moveToFirst()) {
            count =
                    cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    private int getDifficultyQuestCount(
            String difficulty) {

        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(*) FROM quests " +
                                "WHERE user_id = ? " +
                                "AND status = 'Completed' " +
                                "AND difficulty = ?",
                        new String[]{
                                String.valueOf(userId),
                                difficulty
                        }
                );

        int count = 0;

        if (cursor.moveToFirst()) {
            count =
                    cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    private int getCategoryCount() {

        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(DISTINCT category) FROM quests " +
                                "WHERE user_id = ? " +
                                "AND status = 'Completed' " +
                                "AND category IS NOT NULL " +
                                "AND category != ''",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        int count = 0;

        if (cursor.moveToFirst()) {
            count =
                    cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    private int getAvailableCategoryCount() {

        Cursor cursor =
                db.rawQuery(
                        "SELECT COUNT(DISTINCT category) FROM quests " +
                                "WHERE user_id = ? " +
                                "AND category IS NOT NULL " +
                                "AND category != ''",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        int count = 0;

        if (cursor.moveToFirst()) {
            count =
                    cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    private void createCategoryButtons() {

        categoryContainer.removeAllViews();

        for (String category : categories) {

            TextView button =
                    new TextView(this);

            button.setText(category);

            button.setGravity(
                    Gravity.CENTER
            );

            button.setTextSize(9);

            button.setTypeface(
                    null,
                    Typeface.BOLD
            );

            button.setPadding(
                    18,
                    12,
                    18,
                    12
            );

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            params.setMargins(
                    0,
                    0,
                    8,
                    0
            );

            button.setLayoutParams(params);

            updateCategoryButtonStyle(
                    button,
                    category.equals(selectedCategory)
            );

            button.setOnClickListener(
                    view -> {

                        selectedCategory =
                                category;

                        createCategoryButtons();

                        loadAchievements();
                    }
            );

            categoryContainer.addView(
                    button
            );
        }
    }

    private void updateCategoryButtonStyle(
            TextView button,
            boolean selected) {

        if (selected) {

            button.setTextColor(
                    Color.WHITE
            );

            button.setBackgroundColor(
                    Color.rgb(
                            199,
                            123,
                            217
                    )
            );

        } else {

            button.setTextColor(
                    Color.rgb(
                            175,
                            162,
                            187
                    )
            );

            button.setBackgroundColor(
                    Color.rgb(
                            32,
                            25,
                            43
                    )
            );
        }
    }

    private void loadAchievements() {

        achievementContainer.removeAllViews();

        int unlockedCount = 0;

        Cursor countCursor =
                db.rawQuery(
                        "SELECT COUNT(*) FROM achievements " +
                                "WHERE user_id = ? " +
                                "AND unlocked = 1",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        if (countCursor.moveToFirst()) {

            unlockedCount =
                    countCursor.getInt(0);
        }

        countCursor.close();

        txtAchievementCount.setText(
                unlockedCount +
                        " / " +
                        achievementKeys.length
        );

        for (int i = 0;
             i < achievementKeys.length;
             i++) {

            if (!selectedCategory.equals("ALL") &&
                    !achievementCategories[i].equals(
                            selectedCategory
                    )) {

                continue;
            }

            boolean unlocked =
                    isAchievementUnlocked(
                            achievementKeys[i]
                    );

            int progress =
                    getDisplayedProgress(
                            i
                    );

            LinearLayout card =
                    createAchievementCard(
                            achievementTitles[i],
                            achievementDescriptions[i],
                            achievementCategories[i],
                            progress,
                            achievementTargets[i],
                            unlocked
                    );

            achievementContainer.addView(
                    card
            );
        }
    }

    private boolean isAchievementUnlocked(
            String key) {

        Cursor cursor =
                db.query(
                        "achievements",
                        new String[]{
                                "unlocked"
                        },
                        "user_id = ? AND achievement_key = ?",
                        new String[]{
                                String.valueOf(userId),
                                key
                        },
                        null,
                        null,
                        null
                );

        boolean unlocked = false;

        if (cursor.moveToFirst()) {

            unlocked =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "unlocked"
                            )
                    ) == 1;
        }

        cursor.close();

        return unlocked;
    }

    private int getDisplayedProgress(
            int index) {

        int completedQuests =
                getCompletedQuestCount();

        int currentStreak =
                getCurrentStreak();

        int bestStreak =
                getBestStreak();

        int xp =
                getUserXP();

        int coins =
                getUserCoins();

        int dailyChallenges =
                getChallengeCount(
                        "DAILY"
                );

        int weeklyChallenges =
                getChallengeCount(
                        "WEEKLY"
                );

        int hardQuests =
                getDifficultyQuestCount(
                        "Hard"
                );

        int epicQuests =
                getDifficultyQuestCount(
                        "Epic"
                );

        int categoryCount =
                getCategoryCount();

        int progress =
                getAchievementProgress(
                        index,
                        completedQuests,
                        currentStreak,
                        bestStreak,
                        xp,
                        coins,
                        dailyChallenges,
                        weeklyChallenges,
                        hardQuests,
                        epicQuests,
                        categoryCount
                );

        if (achievementKeys[index].equals(
                "category_all"
        )) {

            return categoryCount;
        }

        return Math.min(
                progress,
                achievementTargets[index]
        );
    }

    private LinearLayout createAchievementCard(
            String title,
            String description,
            String category,
            int progress,
            int target,
            boolean unlocked) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL
        );

        card.setPadding(
                16,
                16,
                16,
                16
        );

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        cardParams.setMargins(
                0,
                0,
                0,
                10
        );

        card.setLayoutParams(
                cardParams
        );

        if (unlocked) {

            card.setBackgroundColor(
                    Color.rgb(
                            45,
                            31,
                            55
                    )
            );

        } else {

            card.setBackgroundColor(
                    Color.rgb(
                            24,
                            20,
                            35
                    )
            );
        }

        LinearLayout topRow =
                new LinearLayout(this);

        topRow.setOrientation(
                LinearLayout.HORIZONTAL
        );

        topRow.setGravity(
                Gravity.CENTER_VERTICAL
        );

        TextView icon =
                new TextView(this);

        icon.setLayoutParams(
                new LinearLayout.LayoutParams(
                        48,
                        48
                )
        );

        icon.setGravity(
                Gravity.CENTER
        );

        icon.setText(
                unlocked
                        ? "🏆"
                        : "🔒"
        );

        icon.setTextSize(22);

        LinearLayout textContainer =
                new LinearLayout(this);

        textContainer.setOrientation(
                LinearLayout.VERTICAL
        );

        LinearLayout.LayoutParams textParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                );

        textParams.setMargins(
                14,
                0,
                8,
                0
        );

        textContainer.setLayoutParams(
                textParams
        );

        TextView titleText =
                new TextView(this);

        titleText.setText(
                title
        );

        titleText.setTextColor(
                unlocked
                        ? Color.WHITE
                        : Color.rgb(
                        125,
                        115,
                        135
                )
        );

        titleText.setTextSize(12);

        titleText.setTypeface(
                null,
                Typeface.BOLD
        );

        TextView descriptionText =
                new TextView(this);

        descriptionText.setText(
                description
        );

        descriptionText.setTextColor(
                unlocked
                        ? Color.rgb(
                        175,
                        162,
                        187
                )
                        : Color.rgb(
                        105,
                        96,
                        115
                )
        );

        descriptionText.setTextSize(10);

        descriptionText.setPadding(
                0,
                5,
                0,
                0
        );

        textContainer.addView(
                titleText
        );

        textContainer.addView(
                descriptionText
        );

        TextView status =
                new TextView(this);

        status.setText(
                unlocked
                        ? "UNLOCKED"
                        : "LOCKED"
        );

        status.setTextColor(
                unlocked
                        ? Color.rgb(
                        229,
                        169,
                        228
                )
                        : Color.rgb(
                        105,
                        96,
                        115
                )
        );

        status.setTextSize(8);

        status.setTypeface(
                null,
                Typeface.BOLD
        );

        topRow.addView(
                icon
        );

        topRow.addView(
                textContainer
        );

        topRow.addView(
                status
        );

        card.addView(
                topRow
        );

        if (!unlocked) {

            TextView progressText =
                    new TextView(this);

            if (achievementKeysForTitle(
                    title
            ).equals("category_all")) {

                progressText.setText(
                        progress +
                                " categories completed"
                );

            } else {

                progressText.setText(
                        progress +
                                " / " +
                                target
                );
            }

            progressText.setTextColor(
                    Color.rgb(
                            175,
                            162,
                            187
                    )
            );

            progressText.setTextSize(9);

            progressText.setPadding(
                    62,
                    10,
                    0,
                    4
            );

            card.addView(
                    progressText
            );

            if (!achievementKeysForTitle(
                    title
            ).equals("category_all")) {

                ProgressBar progressBar =
                        new ProgressBar(
                                this,
                                null,
                                android.R.attr.progressBarStyleHorizontal
                        );

                progressBar.setMax(
                        Math.max(
                                target,
                                1
                        )
                );

                progressBar.setProgress(
                        progress
                );

                LinearLayout.LayoutParams progressParams =
                        new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                6
                        );

                progressParams.setMargins(
                        62,
                        0,
                        0,
                        0
                );

                progressBar.setLayoutParams(
                        progressParams
                );

                card.addView(
                        progressBar
                );
            }
        }

        return card;
    }

    private String achievementKeysForTitle(
            String title) {

        for (int i = 0;
             i < achievementTitles.length;
             i++) {

            if (achievementTitles[i].equals(
                    title
            )) {

                return achievementKeys[i];
            }
        }

        return "";
    }

    @Override
    protected void onResume() {

        super.onResume();

        if (db != null &&
                userId != -1) {

            updateAchievements();

            loadAchievements();
        }
    }
}
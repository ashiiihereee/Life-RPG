package com.example.mad;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class quest extends AppCompatActivity {

    private LinearLayout questContent;

    private long userId;
    private String playerName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_quest);


        // =========================================
        // CONNECT XML
        // =========================================

        questContent =
                findViewById(
                        R.id.questContent
                );

        TextView btnAddQuest =
                findViewById(
                        R.id.btnAddQuest
                );

        TextView btnCreateQuest =
                findViewById(
                        R.id.btnCreateQuest
                );

        TextView btnBack =
                findViewById(
                        R.id.btnBack
                );


        // =========================================
        // GET USER DATA
        // =========================================

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        playerName =
                getIntent().getStringExtra(
                        "PLAYER_NAME"
                );


        // =========================================
        // BACK BUTTON
        // =========================================

        btnBack.setOnClickListener(view -> {

            animateClick(view);

            finish();
        });


        // =========================================
        // PLUS BUTTON
        // =========================================

        btnAddQuest.setOnClickListener(view -> {

            animateClick(view);

            openQuestDetails();
        });


        // =========================================
        // CREATE QUEST BUTTON
        // =========================================

        btnCreateQuest.setOnClickListener(view -> {

            animateClick(view);

            openQuestDetails();
        });


        // =========================================
        // PAGE ANIMATION
        // =========================================

        AlphaAnimation fade =
                new AlphaAnimation(
                        0f,
                        1f
                );

        fade.setDuration(700);

        questContent.startAnimation(
                fade
        );
    }


    // =========================================
    // OPEN QUEST DETAILS
    // =========================================

    private void openQuestDetails() {

        Intent intent =
                new Intent(
                        quest.this,
                        quest_details.class
                );

        intent.putExtra(
                "USER_ID",
                userId
        );

        intent.putExtra(
                "PLAYER_NAME",
                playerName
        );

        startActivity(intent);
    }


    // =========================================
    // CLICK ANIMATION
    // =========================================

    private void animateClick(View view) {

        ScaleAnimation animation =
                new ScaleAnimation(
                        1f,
                        0.90f,
                        1f,
                        0.90f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f
                );

        animation.setDuration(
                120
        );

        animation.setRepeatMode(
                ScaleAnimation.REVERSE
        );

        animation.setRepeatCount(
                1
        );

        view.startAnimation(
                animation
        );
    }
}
package com.example.mad;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class shop extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;

    private TextView txtShopCoins;

    private ListView shopListView;

    private String currentCategory = "All";

    private ArrayList<ShopAdapter.ShopItem> shopItems;

    private ShopAdapter shopAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_shop
        );


        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();


        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );


        if (userId == -1) {

            Toast.makeText(
                    this,
                    "Player not found.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

            return;
        }


        txtShopCoins =
                findViewById(
                        R.id.txtShopCoins
                );


        shopListView =
                findViewById(
                        R.id.shopListView
                );


        TextView btnBack =
                findViewById(
                        R.id.btnBack
                );


        btnBack.setOnClickListener(
                v -> finish()
        );


        Button btnAll =
                findViewById(
                        R.id.btnAll
                );

        Button btnOutfits =
                findViewById(
                        R.id.btnOutfits
                );

        Button btnAccessories =
                findViewById(
                        R.id.btnAccessories
                );

        Button btnPets =
                findViewById(
                        R.id.btnPets
                );


        btnAll.setOnClickListener(
                v -> {

                    currentCategory =
                            "All";

                    loadShopItems();
                }
        );


        btnOutfits.setOnClickListener(
                v -> {

                    currentCategory =
                            "Outfits";

                    loadShopItems();
                }
        );


        btnAccessories.setOnClickListener(
                v -> {

                    currentCategory =
                            "Accessories";

                    loadShopItems();
                }
        );


        btnPets.setOnClickListener(
                v -> {

                    currentCategory =
                            "Pets";

                    loadShopItems();
                }
        );


        shopItems =
                new ArrayList<>();


        shopAdapter =
                new ShopAdapter(
                        this,
                        shopItems,
                        item -> {

                            if (item.owned) {

                                Toast.makeText(
                                        shop.this,
                                        "You already own this item.",
                                        Toast.LENGTH_SHORT
                                ).show();

                                return;
                            }

                            buyItem(
                                    item.itemId,
                                    item.name,
                                    item.price
                            );
                        }
                );


        shopListView.setAdapter(
                shopAdapter
        );


        loadCoins();

        loadShopItems();
    }


    @Override
    protected void onResume() {

        super.onResume();

        if (
                db != null &&
                        userId != -1
        ) {

            loadCoins();

            loadShopItems();
        }
    }


    private void loadCoins() {

        Cursor cursor =
                db.query(
                        "users",
                        new String[]{
                                "coins"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (cursor.moveToFirst()) {

            int coins =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "coins"
                            )
                    );

            txtShopCoins.setText(
                    "🪙 " +
                            coins
            );
        }


        cursor.close();
    }


    private void loadShopItems() {

        shopItems.clear();


        Cursor cursor;


        if (
                currentCategory.equals(
                        "All"
                )
        ) {

            cursor =
                    db.query(
                            "shop_items",
                            null,
                            null,
                            null,
                            null,
                            null,
                            "item_id ASC"
                    );

        } else {

            cursor =
                    db.query(
                            "shop_items",
                            null,
                            "category = ?",
                            new String[]{
                                    currentCategory
                            },
                            null,
                            null,
                            "item_id ASC"
                    );
        }


        while (
                cursor.moveToNext()
        ) {

            int itemId =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "item_id"
                            )
                    );


            String name =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "name"
                            )
                    );


            String category =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "category"
                            )
                    );


            int price =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "price"
                            )
                    );


            String icon =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "icon"
                            )
                    );


            String description =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "description"
                            )
                    );


            String rarity =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "rarity"
                            )
                    );


            boolean owned =
                    isItemOwned(
                            itemId
                    );


            shopItems.add(
                    new ShopAdapter.ShopItem(
                            itemId,
                            name,
                            category,
                            price,
                            icon,
                            description,
                            rarity,
                            owned
                    )
            );
        }


        cursor.close();


        shopAdapter.notifyDataSetChanged();
    }


    private boolean isItemOwned(
            int itemId) {

        Cursor cursor =
                db.query(
                        "owned_items",
                        new String[]{
                                "owned_id"
                        },
                        "user_id = ? AND item_id = ?",
                        new String[]{
                                String.valueOf(userId),
                                String.valueOf(itemId)
                        },
                        null,
                        null,
                        null
                );


        boolean owned =
                cursor.moveToFirst();


        cursor.close();


        return owned;
    }


    private void buyItem(
            int itemId,
            String itemName,
            int price) {


        Cursor cursor =
                db.query(
                        "users",
                        new String[]{
                                "coins"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (!cursor.moveToFirst()) {

            cursor.close();

            return;
        }


        int coins =
                cursor.getInt(
                        cursor.getColumnIndexOrThrow(
                                "coins"
                        )
                );


        cursor.close();


        if (coins < price) {

            Toast.makeText(
                    this,
                    "Not enough coins.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        db.beginTransaction();


        try {

            ContentValues coinValues =
                    new ContentValues();


            coinValues.put(
                    "coins",
                    coins - price
            );


            int updated =
                    db.update(
                            "users",
                            coinValues,
                            "user_id = ?",
                            new String[]{
                                    String.valueOf(userId)
                            }
                    );


            if (updated == 0) {

                throw new Exception();
            }


            ContentValues ownedValues =
                    new ContentValues();


            ownedValues.put(
                    "user_id",
                    userId
            );


            ownedValues.put(
                    "item_id",
                    itemId
            );


            ownedValues.put(
                    "equipped",
                    0
            );


            db.insertOrThrow(
                    "owned_items",
                    null,
                    ownedValues
            );


            db.setTransactionSuccessful();


            Toast.makeText(
                    this,
                    "🎉 " +
                            itemName +
                            " purchased!",
                    Toast.LENGTH_SHORT
            ).show();


        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Purchase failed.",
                    Toast.LENGTH_SHORT
            ).show();


        } finally {

            db.endTransaction();
        }


        loadCoins();

        loadShopItems();
    }
}
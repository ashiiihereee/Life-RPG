package com.example.mad;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class roadmap extends AppCompatActivity {

    private LinearLayout roadmapContainer;

    private TextView txtRoadmapProgress;
    private TextView txtRoadmapPercent;

    private ProgressBar roadmapProgressBar;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;
    private String playerName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_roadmap);


        roadmapContainer =
                findViewById(
                        R.id.roadmapContainer
                );

        txtRoadmapProgress =
                findViewById(
                        R.id.txtRoadmapProgress
                );

        txtRoadmapPercent =
                findViewById(
                        R.id.txtRoadmapPercent
                );

        roadmapProgressBar =
                findViewById(
                        R.id.roadmapProgressBar
                );


        TextView btnBack =
                findViewById(
                        R.id.btnBack
                );

        TextView btnAddQuest =
                findViewById(
                        R.id.btnAddQuest
                );


        // =====================================
        // BACK BUTTON
        // =====================================

        btnBack.setOnClickListener(
                view -> finish()
        );


        // =====================================
        // ADD QUEST BUTTON
        // =====================================

        btnAddQuest.setOnClickListener(view -> {

            Intent intent =
                    new Intent(
                            roadmap.this,
                            quest.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });


        // =====================================
        // GET USER ID
        // =====================================

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );


        // =====================================
        // GET PLAYER NAME
        // =====================================

        playerName =
                getIntent().getStringExtra(
                        "PLAYER_NAME"
                );


        // =====================================
        // DATABASE
        // =====================================

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();


        // =====================================
        // LOAD ROADMAP
        // =====================================

        loadRoadmap();
    }


    // =========================================
    // LOAD ROADMAP
    // =========================================

    private void loadRoadmap() {

        roadmapContainer.removeAllViews();


        if (userId == -1) {

            showEmptyRoadmap(
                    "Unable to load your quest journey."
            );

            return;
        }


        Cursor cursor =
                db.query(
                        "quests",

                        new String[]{
                                "quest_id",
                                "title",
                                "description",
                                "status",
                                "xp"
                        },

                        "user_id = ?",

                        new String[]{
                                String.valueOf(userId)
                        },

                        null,
                        null,

                        "quest_id ASC"
                );


        int totalQuests = 0;
        int completedQuests = 0;


        while (cursor.moveToNext()) {

            long questId =
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    "quest_id"
                            )
                    );


            String title =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "title"
                            )
                    );


            String description =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "description"
                            )
                    );


            String status =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "status"
                            )
                    );


            int xp =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "xp"
                            )
                    );


            totalQuests++;


            boolean completed =
                    "Completed".equalsIgnoreCase(
                            status
                    );


            boolean unlocked =
                    "Unlocked".equalsIgnoreCase(
                            status
                    );


            if (completed) {
                completedQuests++;
            }


            addQuestNode(
                    questId,
                    title,
                    description,
                    status,
                    xp,
                    completed,
                    unlocked,
                    totalQuests
            );
        }


        cursor.close();


        updateProgress(
                completedQuests,
                totalQuests
        );


        if (totalQuests == 0) {

            showEmptyRoadmap(
                    "Your adventure hasn't started yet.\n\nCreate your first quest!"
            );
        }
    }


    // =========================================
    // ADD QUEST NODE
    // =========================================

    private void addQuestNode(
            long questId,
            String title,
            String description,
            String status,
            int xp,
            boolean completed,
            boolean unlocked,
            int position) {


        boolean current =
                !completed &&
                        !unlocked &&
                        position ==
                                getFirstIncompletePosition();


        // =====================================
        // MAIN NODE AREA
        // =====================================

        LinearLayout nodeArea =
                new LinearLayout(this);

        nodeArea.setOrientation(
                LinearLayout.VERTICAL
        );

        nodeArea.setGravity(
                Gravity.CENTER
        );


        LinearLayout.LayoutParams nodeAreaParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        nodeAreaParams.setMargins(
                0,
                0,
                0,
                4
        );

        nodeArea.setLayoutParams(
                nodeAreaParams
        );


        // =====================================
        // CONNECTOR ABOVE NODE
        // =====================================

        if (position > 1) {

            TextView connector =
                    new TextView(this);

            connector.setText(
                    "⋮"
            );

            connector.setTextColor(
                    current
                            ? Color.rgb(
                            229,
                            169,
                            228
                    )
                            : Color.rgb(
                            91,
                            75,
                            102
                    )
            );

            connector.setTextSize(
                    30
            );

            connector.setGravity(
                    Gravity.CENTER
            );

            LinearLayout.LayoutParams connectorParams =
                    new LinearLayout.LayoutParams(
                            60,
                            45
                    );

            connector.setLayoutParams(
                    connectorParams
            );

            nodeArea.addView(
                    connector
            );
        }


        // =====================================
        // ROW
        // =====================================

        LinearLayout row =
                new LinearLayout(this);

        row.setOrientation(
                LinearLayout.HORIZONTAL
        );

        row.setGravity(
                Gravity.CENTER_VERTICAL
        );


        LinearLayout.LayoutParams rowParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        row.setLayoutParams(
                rowParams
        );


        // =====================================
        // CARD POSITION
        // =====================================

        boolean placeLeft =
                position % 2 == 0;


        if (placeLeft) {

            row.addView(
                    createQuestCard(
                            questId,
                            title,
                            description,
                            xp,
                            completed,
                            current,
                            unlocked
                    ),
                    createCardParams(
                            0.72f
                    )
            );


            row.addView(
                    createNode(
                            completed,
                            current,
                            unlocked
                    ),
                    createNodeParams()
            );


            TextView empty =
                    new TextView(this);

            row.addView(
                    empty,
                    createCardParams(
                            0.28f
                    )
            );

        } else {

            TextView empty =
                    new TextView(this);

            row.addView(
                    empty,
                    createCardParams(
                            0.28f
                    )
            );


            row.addView(
                    createNode(
                            completed,
                            current,
                            unlocked
                    ),
                    createNodeParams()
            );


            row.addView(
                    createQuestCard(
                            questId,
                            title,
                            description,
                            xp,
                            completed,
                            current,
                            unlocked
                    ),
                    createCardParams(
                            0.72f
                    )
            );
        }


        nodeArea.addView(
                row
        );


        // =====================================
        // QUEST NUMBER
        // =====================================

        TextView stageText =
                new TextView(this);

        stageText.setText(
                "STAGE " +
                        String.format(
                                "%02d",
                                position
                        )
        );

        stageText.setTextColor(
                current
                        ? Color.rgb(
                        229,
                        169,
                        228
                )
                        : completed
                          ? Color.rgb(
                        150,
                        180,
                        145
                )
                          : unlocked
                            ? Color.rgb(
                        229,
                        169,
                        228
                )
                            : Color.rgb(
                        105,
                        96,
                        115
                )
        );

        stageText.setTextSize(
                7
        );

        stageText.setTypeface(
                null,
                Typeface.BOLD
        );

        stageText.setGravity(
                Gravity.CENTER
        );

        stageText.setLetterSpacing(
                0.2f
        );


        nodeArea.addView(
                stageText
        );


        roadmapContainer.addView(
                nodeArea
        );
    }


    // =========================================
    // CREATE QUEST CARD
    // =========================================

    private View createQuestCard(
            long questId,
            String title,
            String description,
            int xp,
            boolean completed,
            boolean current,
            boolean unlocked) {


        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL
        );

        card.setPadding(
                17,
                15,
                17,
                15
        );


        GradientDrawable background =
                new GradientDrawable();

        background.setCornerRadius(
                28
        );


        if (completed) {

            background.setColor(
                    Color.rgb(
                            31,
                            47,
                            34
                    )
            );

            background.setStroke(
                    2,
                    Color.rgb(
                            91,
                            125,
                            87
                    )
            );

        } else if (current) {

            background.setColor(
                    Color.rgb(
                            53,
                            31,
                            60
                    )
            );

            background.setStroke(
                    2,
                    Color.rgb(
                            229,
                            169,
                            228
                    )
            );

        } else if (unlocked) {

            background.setColor(
                    Color.rgb(
                            53,
                            31,
                            60
                    )
            );

            background.setStroke(
                    2,
                    Color.rgb(
                            174,
                            115,
                            180
                    )
            );

        } else {

            background.setColor(
                    Color.rgb(
                            22,
                            19,
                            31
                    )
            );

            background.setStroke(
                    1,
                    Color.rgb(
                            56,
                            49,
                            65
                    )
            );
        }


        card.setBackground(
                background
        );


        // =====================================
        // TOP ROW
        // =====================================

        LinearLayout topRow =
                new LinearLayout(this);

        topRow.setOrientation(
                LinearLayout.HORIZONTAL
        );

        topRow.setGravity(
                Gravity.CENTER_VERTICAL
        );


        // =====================================
        // STATUS
        // =====================================

        TextView status =
                new TextView(this);


        if (completed) {

            status.setText(
                    "✓ COMPLETE"
            );

        } else if (current) {

            status.setText(
                    "★ CURRENT"
            );

        } else if (unlocked) {

            status.setText(
                    "✓ UNLOCKED"
            );

        } else {

            status.setText(
                    "🔒 LOCKED"
            );
        }


        status.setTextColor(
                completed
                        ? Color.rgb(
                        183,
                        216,
                        178
                )
                        : current
                          ? Color.rgb(
                        229,
                        169,
                        228
                )
                          : unlocked
                            ? Color.rgb(
                        229,
                        169,
                        228
                )
                            : Color.rgb(
                        105,
                        96,
                        115
                )
        );

        status.setTextSize(
                7
        );

        status.setTypeface(
                null,
                Typeface.BOLD
        );


        topRow.addView(
                status,
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                )
        );


        // =====================================
        // XP
        // =====================================

        TextView xpText =
                new TextView(this);

        xpText.setText(
                "+" +
                        xp +
                        " XP"
        );

        xpText.setTextColor(
                current ||
                        completed ||
                        unlocked
                        ? Color.rgb(
                        229,
                        169,
                        228
                )
                        : Color.rgb(
                        92,
                        84,
                        102
                )
        );

        xpText.setTextSize(
                8
        );

        xpText.setTypeface(
                null,
                Typeface.BOLD
        );


        topRow.addView(
                xpText
        );


        card.addView(
                topRow
        );


        // =====================================
        // TITLE
        // =====================================

        TextView titleText =
                new TextView(this);

        titleText.setText(
                title
        );

        titleText.setTextColor(
                completed ||
                        current ||
                        unlocked
                        ? Color.WHITE
                        : Color.rgb(
                        115,
                        107,
                        125
                )
        );

        titleText.setTextSize(
                13
        );

        titleText.setTypeface(
                null,
                Typeface.BOLD
        );

        titleText.setPadding(
                0,
                8,
                0,
                0
        );


        card.addView(
                titleText
        );


        // =====================================
        // DESCRIPTION
        // =====================================

        if (description != null &&
                !description.trim().isEmpty()) {

            TextView descriptionText =
                    new TextView(this);

            descriptionText.setText(
                    description
            );

            descriptionText.setTextColor(
                    completed ||
                            current ||
                            unlocked
                            ? Color.rgb(
                            165,
                            154,
                            177
                    )
                            : Color.rgb(
                            82,
                            76,
                            91
                    )
            );

            descriptionText.setTextSize(
                    8
            );

            descriptionText.setMaxLines(
                    2
            );

            descriptionText.setPadding(
                    0,
                    5,
                    0,
                    0
            );


            card.addView(
                    descriptionText
            );
        }


        // =====================================
        // CURRENT LABEL
        // =====================================

        if (current) {

            TextView currentText =
                    new TextView(this);

            currentText.setText(
                    "YOUR NEXT CHALLENGE →"
            );

            currentText.setTextColor(
                    Color.rgb(
                            229,
                            169,
                            228
                    )
            );

            currentText.setTextSize(
                    7
            );

            currentText.setTypeface(
                    null,
                    Typeface.BOLD
            );

            currentText.setPadding(
                    0,
                    10,
                    0,
                    0
            );


            card.addView(
                    currentText
            );
        }


        // =====================================
        // CLICK
        // =====================================

        if (completed || current || unlocked) {

            card.setOnClickListener(
                    view -> {

                        Intent intent =
                                new Intent(
                                        roadmap.this,
                                        quest_view.class
                                );

                        intent.putExtra(
                                "USER_ID",
                                userId
                        );

                        intent.putExtra(
                                "PLAYER_NAME",
                                playerName
                        );

                        intent.putExtra(
                                "QUEST_ID",
                                questId
                        );

                        startActivity(
                                intent
                        );
                    }
            );

        } else {

            card.setAlpha(
                    0.72f
            );

            card.setOnClickListener(
                    view -> showUnlockDialog(
                            questId
                    )
            );
        }


        return card;
    }


    // =========================================
    // UNLOCK DIALOG
    // =========================================

    private void showUnlockDialog(
            long questId) {

        final int unlockCost = 30;


        Cursor cursor =
                db.query(
                        "users",

                        new String[]{
                                "coins"
                        },

                        "user_id = ?",

                        new String[]{
                                String.valueOf(userId)
                        },

                        null,
                        null,
                        null
                );


        int coins = 0;


        if (cursor.moveToFirst()) {

            coins =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "coins"
                            )
                    );
        }


        cursor.close();


        if (coins < unlockCost) {

            new AlertDialog.Builder(this)
                    .setTitle("Not Enough Coins")
                    .setMessage(
                            "You need 30 coins to unlock this quest.\n\n" +
                                    "Your coins: " +
                                    coins
                    )
                    .setPositiveButton(
                            "OK",
                            null
                    )
                    .show();

            return;
        }


        new AlertDialog.Builder(this)
                .setTitle("Unlock Quest?")
                .setMessage(
                        "Unlock this quest for 30 coins?\n\n" +
                                "Your coins: " +
                                coins +
                                "\n" +
                                "After unlocking: " +
                                (coins - unlockCost)
                )
                .setNegativeButton(
                        "CANCEL",
                        null
                )
                .setPositiveButton(
                        "UNLOCK",
                        (dialog, which) -> {

                            unlockQuest(
                                    questId,
                                    unlockCost
                            );
                        }
                )
                .show();
    }


    // =========================================
    // UNLOCK QUEST
    // =========================================

    private void unlockQuest(
            long questId,
            int unlockCost) {


        Cursor cursor =
                db.query(
                        "users",

                        new String[]{
                                "coins"
                        },

                        "user_id = ?",

                        new String[]{
                                String.valueOf(userId)
                        },

                        null,
                        null,
                        null
                );


        int coins = 0;


        if (cursor.moveToFirst()) {

            coins =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "coins"
                            )
                    );
        }


        cursor.close();


        if (coins < unlockCost) {

            new AlertDialog.Builder(this)
                    .setTitle("Not Enough Coins")
                    .setMessage(
                            "You need 30 coins to unlock this quest."
                    )
                    .setPositiveButton(
                            "OK",
                            null
                    )
                    .show();

            return;
        }


        int coinsUpdated =
                db.update(
                        "users",
                        createCoinsValues(
                                coins - unlockCost
                        ),
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );


        if (coinsUpdated > 0) {

            int questUpdated =
                    db.update(
                            "quests",
                            createUnlockedValues(),
                            "quest_id = ? AND user_id = ?",
                            new String[]{
                                    String.valueOf(questId),
                                    String.valueOf(userId)
                            }
                    );


            if (questUpdated > 0) {

                android.widget.Toast.makeText(
                        this,
                        "🔓 Quest unlocked!\n🪙 -30 Coins",
                        android.widget.Toast.LENGTH_SHORT
                ).show();

                loadRoadmap();

            } else {

                db.update(
                        "users",
                        createCoinsValues(
                                coins
                        ),
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

                android.widget.Toast.makeText(
                        this,
                        "Unable to unlock quest.",
                        android.widget.Toast.LENGTH_SHORT
                ).show();
            }
        }
    }


    // =========================================
    // COINS VALUES
    // =========================================

    private android.content.ContentValues createCoinsValues(
            int coins) {

        android.content.ContentValues values =
                new android.content.ContentValues();

        values.put(
                "coins",
                coins
        );

        return values;
    }


    // =========================================
    // UNLOCKED VALUES
    // =========================================

    private android.content.ContentValues createUnlockedValues() {

        android.content.ContentValues values =
                new android.content.ContentValues();

        values.put(
                "status",
                "Unlocked"
        );

        return values;
    }


    // =========================================
    // CREATE QUEST NODE
    // =========================================

    private View createNode(
            boolean completed,
            boolean current,
            boolean unlocked) {


        TextView node =
                new TextView(this);


        if (completed) {

            node.setText(
                    "✓"
            );

            node.setTextColor(
                    Color.rgb(
                            225,
                            245,
                            220
                    )
            );

            node.setTextSize(
                    24
            );

        } else if (current) {

            node.setText(
                    "★"
            );

            node.setTextColor(
                    Color.WHITE
            );

            node.setTextSize(
                    24
            );

        } else if (unlocked) {

            node.setText(
                    "✓"
            );

            node.setTextColor(
                    Color.WHITE
            );

            node.setTextSize(
                    22
            );

        } else {

            node.setText(
                    "🔒"
            );

            node.setTextColor(
                    Color.rgb(
                            100,
                            92,
                            110
                    )
            );

            node.setTextSize(
                    18
            );
        }


        node.setGravity(
                Gravity.CENTER
        );


        GradientDrawable circle =
                new GradientDrawable();

        circle.setShape(
                GradientDrawable.OVAL
        );


        if (completed) {

            circle.setColor(
                    Color.rgb(
                            57,
                            86,
                            54
                    )
            );

            circle.setStroke(
                    3,
                    Color.rgb(
                            120,
                            160,
                            112
                    )
            );

        } else if (current) {

            circle.setColor(
                    Color.rgb(
                            130,
                            75,
                            135
                    )
            );

            circle.setStroke(
                    4,
                    Color.rgb(
                            229,
                            169,
                            228
                    )
            );

        } else if (unlocked) {

            circle.setColor(
                    Color.rgb(
                            91,
                            58,
                            97
                    )
            );

            circle.setStroke(
                    3,
                    Color.rgb(
                            174,
                            115,
                            180
                    )
            );

        } else {

            circle.setColor(
                    Color.rgb(
                            31,
                            27,
                            39
                    )
            );

            circle.setStroke(
                    2,
                    Color.rgb(
                            72,
                            64,
                            80
                    )
            );
        }


        node.setBackground(
                circle
        );


        if (current) {

            node.setElevation(
                    12
            );

        } else {

            node.setElevation(
                    4
            );
        }


        return node;
    }


    // =========================================
    // CARD PARAMETERS
    // =========================================

    private LinearLayout.LayoutParams createCardParams(
            float weight) {

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        weight
                );

        params.setMargins(
                4,
                0,
                4,
                0
        );

        return params;
    }


    // =========================================
    // NODE PARAMETERS
    // =========================================

    private LinearLayout.LayoutParams createNodeParams() {

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        70,
                        70
                );

        params.setMargins(
                3,
                0,
                3,
                0
        );

        return params;
    }


    // =========================================
    // FIND CURRENT QUEST
    // =========================================

    private int getFirstIncompletePosition() {

        Cursor cursor =
                db.query(
                        "quests",

                        new String[]{
                                "status"
                        },

                        "user_id = ?",

                        new String[]{
                                String.valueOf(userId)
                        },

                        null,
                        null,

                        "quest_id ASC"
                );


        int position = 1;


        while (cursor.moveToNext()) {

            String status =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "status"
                            )
                    );


            if (!"Completed".equalsIgnoreCase(
                    status
            ) &&
                    !"Unlocked".equalsIgnoreCase(
                            status
                    )) {

                cursor.close();

                return position;
            }


            position++;
        }


        cursor.close();


        return -1;
    }


    // =========================================
    // UPDATE PROGRESS
    // =========================================

    private void updateProgress(
            int completed,
            int total) {


        if (total == 0) {

            txtRoadmapProgress.setText(
                    "0 / 0 QUESTS COMPLETED"
            );

            txtRoadmapPercent.setText(
                    "0%"
            );

            roadmapProgressBar.setProgress(
                    0
            );

            return;
        }


        int percentage =
                (completed * 100) / total;


        txtRoadmapProgress.setText(
                completed +
                        " / " +
                        total +
                        " QUESTS COMPLETED"
        );


        txtRoadmapPercent.setText(
                percentage +
                        "%"
        );


        roadmapProgressBar.setProgress(
                percentage
        );
    }


    // =========================================
    // EMPTY STATE
    // =========================================

    private void showEmptyRoadmap(
            String message) {

        TextView emptyText =
                new TextView(this);

        emptyText.setText(
                message
        );

        emptyText.setTextColor(
                Color.rgb(
                        175,
                        162,
                        187
                )
        );

        emptyText.setTextSize(
                12
        );

        emptyText.setGravity(
                Gravity.CENTER
        );

        emptyText.setPadding(
                20,
                50,
                20,
                50
        );


        roadmapContainer.addView(
                emptyText
        );
    }


    // =========================================
    // REFRESH
    // =========================================

    @Override
    protected void onResume() {

        super.onResume();


        if (db != null &&
                userId != -1) {

            loadRoadmap();
        }
    }
}
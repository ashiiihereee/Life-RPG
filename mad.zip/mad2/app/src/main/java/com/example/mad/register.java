package com.example.mad;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class register extends AppCompatActivity {

    private EditText edtName;
    private EditText edtEmail;
    private EditText edtPassword;
    private EditText edtConfirmPassword;

    private CheckBox checkTerms;

    private Button btnCreateAccount;

    private TextView txtLogin;
    private TextView txtRegisterLogo;

    private ProgressBar progressRegister;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();


        edtName = findViewById(R.id.edtName);

        edtEmail = findViewById(R.id.edtRegisterEmail);

        edtPassword = findViewById(R.id.edtRegisterPassword);

        edtConfirmPassword = findViewById(R.id.edtConfirmPassword);

        checkTerms = findViewById(R.id.checkTerms);

        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        txtLogin = findViewById(R.id.txtLogin);

        txtRegisterLogo = findViewById(R.id.txtRegisterLogo);

        progressRegister = findViewById(R.id.progressRegister);


        styleInput(edtName);
        styleInput(edtEmail);
        styleInput(edtPassword);
        styleInput(edtConfirmPassword);


        animateLogo();


        btnCreateAccount.setOnClickListener(view -> {

            animateButton(btnCreateAccount);

            createAccount();

        });


        txtLogin.setOnClickListener(view -> {

            Intent intent =
                    new Intent(
                            register.this,
                            MainActivity.class
                    );

            startActivity(intent);

            finish();

        });

    }


    private void styleInput(EditText editText) {

        GradientDrawable background =
                new GradientDrawable();

        background.setColor(
                Color.rgb(13, 10, 23)
        );

        background.setCornerRadius(18f);

        background.setStroke(
                2,
                Color.rgb(75, 60, 88)
        );

        editText.setBackground(background);


        editText.setOnFocusChangeListener(
                (view, hasFocus) -> {

                    GradientDrawable focused =
                            new GradientDrawable();

                    focused.setColor(
                            Color.rgb(13, 10, 23)
                    );

                    focused.setCornerRadius(18f);


                    if (hasFocus) {

                        focused.setStroke(
                                2,
                                Color.rgb(235, 80, 255)
                        );

                    } else {

                        focused.setStroke(
                                2,
                                Color.rgb(75, 60, 88)
                        );

                    }


                    editText.setBackground(
                            focused
                    );

                }
        );

    }


    private void createAccount() {

        String name =
                edtName.getText()
                        .toString()
                        .trim();

        String email =
                edtEmail.getText()
                        .toString()
                        .trim();

        String password =
                edtPassword.getText()
                        .toString()
                        .trim();

        String confirmPassword =
                edtConfirmPassword.getText()
                        .toString()
                        .trim();


        if (TextUtils.isEmpty(name)) {

            edtName.setError(
                    "Enter your player name"
            );

            edtName.requestFocus();

            return;
        }


        if (TextUtils.isEmpty(email)) {

            edtEmail.setError(
                    "Enter your email"
            );

            edtEmail.requestFocus();

            return;
        }


        if (!Patterns.EMAIL_ADDRESS
                .matcher(email)
                .matches()) {

            edtEmail.setError(
                    "Enter a valid email"
            );

            edtEmail.requestFocus();

            return;
        }


        if (password.length() < 6) {

            edtPassword.setError(
                    "Use at least 6 characters"
            );

            edtPassword.requestFocus();

            return;
        }


        if (!password.equals(confirmPassword)) {

            edtConfirmPassword.setError(
                    "Passwords do not match"
            );

            edtConfirmPassword.requestFocus();

            return;
        }


        if (!checkTerms.isChecked()) {

            Toast.makeText(
                    this,
                    "Please accept the terms first.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        Cursor cursor = db.query(
                "users",
                new String[]{"user_id"},
                "email = ?",
                new String[]{email},
                null,
                null,
                null
        );


        if (cursor.moveToFirst()) {

            cursor.close();

            edtEmail.setError(
                    "Email already registered"
            );

            edtEmail.requestFocus();

            return;
        }


        cursor.close();


        progressRegister.setVisibility(
                View.VISIBLE
        );

        btnCreateAccount.setEnabled(false);


        ContentValues values =
                new ContentValues();

        values.put(
                "name",
                name
        );

        values.put(
                "email",
                email
        );

        values.put(
                "password",
                password
        );

        values.put(
                "avatar",
                ""
        );

        values.put(
                "level",
                1
        );

        values.put(
                "xp",
                0
        );

        values.put(
                "coins",
                0
        );


        long userId =
                db.insert(
                        "users",
                        null,
                        values
                );


        if (userId == -1) {

            progressRegister.setVisibility(
                    View.GONE
            );

            btnCreateAccount.setEnabled(true);

            Toast.makeText(
                    register.this,
                    "Account creation failed.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        // =====================================
        // CREATE PLAYER STATS
        // =====================================

        ContentValues statsValues =
                new ContentValues();

        statsValues.put(
                "user_id",
                userId
        );

        statsValues.put(
                "intelligence",
                0
        );

        statsValues.put(
                "strength",
                0
        );

        statsValues.put(
                "health",
                0
        );

        statsValues.put(
                "discipline",
                0
        );

        statsValues.put(
                "creativity",
                0
        );


        long statsId =
                db.insert(
                        "stats",
                        null,
                        statsValues
                );


        if (statsId == -1) {

            db.delete(
                    "users",
                    "user_id = ?",
                    new String[]{
                            String.valueOf(userId)
                    }
            );

            progressRegister.setVisibility(
                    View.GONE
            );

            btnCreateAccount.setEnabled(true);

            Toast.makeText(
                    register.this,
                    "Account setup failed.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        progressRegister.setVisibility(
                View.GONE
        );

        btnCreateAccount.setEnabled(true);


        Toast.makeText(
                register.this,
                "Character created!",
                Toast.LENGTH_SHORT
        ).show();


        Intent intent =
                new Intent(
                        register.this,
                        home.class
                );


        intent.putExtra(
                "PLAYER_NAME",
                name
        );

        intent.putExtra(
                "USER_ID",
                userId
        );


        startActivity(intent);

        finish();

    }


    private void animateLogo() {

        AlphaAnimation animation =
                new AlphaAnimation(
                        0.0f,
                        1.0f
                );

        animation.setDuration(900);

        txtRegisterLogo.startAnimation(
                animation
        );

    }


    private void animateButton(View view) {

        ScaleAnimation animation =
                new ScaleAnimation(
                        1.0f,
                        0.95f,
                        1.0f,
                        0.95f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f
                );

        animation.setDuration(120);

        animation.setRepeatMode(
                ScaleAnimation.REVERSE
        );

        animation.setRepeatCount(1);

        view.startAnimation(animation);

    }

}
package com.example.mad;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.animation.ScaleAnimation;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class quest_details extends AppCompatActivity {

    private EditText edtQuestName;
    private EditText edtDescription;
    private EditText edtDeadline;

    private Spinner spinnerCategory;
    private Spinner spinnerDifficulty;
    private Spinner spinnerDuration;
    private Spinner spinnerGoal;

    private TextView txtCalculatedXP;
    private TextView txtXPExplanation;

    private TextView btnSaveQuest;
    private TextView btnBack;

    private long userId;
    private long questId;
    private String playerName;

    private boolean editMode = false;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_quest_details);

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        questId =
                getIntent().getLongExtra(
                        "QUEST_ID",
                        -1
                );

        playerName =
                getIntent().getStringExtra(
                        "PLAYER_NAME"
                );

        editMode =
                getIntent().getBooleanExtra(
                        "EDIT_MODE",
                        false
                );

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();

        edtQuestName =
                findViewById(
                        R.id.edtQuestName
                );

        edtDescription =
                findViewById(
                        R.id.edtDescription
                );

        edtDeadline =
                findViewById(
                        R.id.edtDeadline
                );

        spinnerCategory =
                findViewById(
                        R.id.spinnerCategory
                );

        spinnerDifficulty =
                findViewById(
                        R.id.spinnerDifficulty
                );

        spinnerDuration =
                findViewById(
                        R.id.spinnerDuration
                );

        spinnerGoal =
                findViewById(
                        R.id.spinnerGoal
                );

        txtCalculatedXP =
                findViewById(
                        R.id.txtCalculatedXP
                );

        txtXPExplanation =
                findViewById(
                        R.id.txtXPExplanation
                );

        btnSaveQuest =
                findViewById(
                        R.id.btnSaveQuest
                );

        btnBack =
                findViewById(
                        R.id.btnBack
                );

        setupSpinners();

        if (editMode) {

            loadQuestForEditing();

            btnSaveQuest.setText(
                    "SAVE CHANGES  →"
            );

        } else {

            updateXP();
        }

        btnBack.setOnClickListener(view -> {

            animateButton(view);

            finish();

        });

        edtDeadline.setOnClickListener(view -> {

            openDatePicker();

        });

        spinnerDifficulty.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        updateXP();

                    }

                    @Override
                    public void onNothingSelected(
                            android.widget.AdapterView<?> parent) {

                    }
                }
        );

        spinnerDuration.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        updateXP();

                    }

                    @Override
                    public void onNothingSelected(
                            android.widget.AdapterView<?> parent) {

                    }
                }
        );

        btnSaveQuest.setOnClickListener(view -> {

            animateButton(view);

            saveQuest();

        });
    }

    // ==========================================
    // SPINNERS
    // ==========================================

    private void setupSpinners() {

        String[] categories = {
                "Study",
                "Fitness",
                "Personal",
                "Work",
                "Health",
                "Creativity"
        };

        String[] difficulties = {
                "Easy",
                "Medium",
                "Hard",
                "Epic"
        };

        String[] durations = {
                "15 minutes",
                "30 minutes",
                "1 hour",
                "2 hours",
                "3+ hours"
        };

        String[] goals = {
                "No related goal",
                "Academic Growth",
                "Health & Fitness",
                "Personal Growth",
                "Career",
                "Other"
        };

        ArrayAdapter<String> categoryAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        categories
                );

        ArrayAdapter<String> difficultyAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        difficulties
                );

        ArrayAdapter<String> durationAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        durations
                );

        ArrayAdapter<String> goalAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        goals
                );

        spinnerCategory.setAdapter(
                categoryAdapter
        );

        spinnerDifficulty.setAdapter(
                difficultyAdapter
        );

        spinnerDuration.setAdapter(
                durationAdapter
        );

        spinnerGoal.setAdapter(
                goalAdapter
        );
    }

    // ==========================================
    // LOAD QUEST FOR EDITING
    // ==========================================

    private void loadQuestForEditing() {

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "title",
                                "description",
                                "category",
                                "difficulty",
                                "duration",
                                "deadline",
                                "status"
                        },
                        "quest_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(
                                        questId
                                ),
                                String.valueOf(
                                        userId
                                )
                        },
                        null,
                        null,
                        null
                );

        if (!cursor.moveToFirst()) {

            cursor.close();

            Toast.makeText(
                    this,
                    "Quest not found.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

            return;
        }

        String title =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "title"
                        )
                );

        String description =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "description"
                        )
                );

        String category =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "category"
                        )
                );

        String difficulty =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "difficulty"
                        )
                );

        String duration =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "duration"
                        )
                );

        String deadline =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "deadline"
                        )
                );

        String status =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "status"
                        )
                );

        cursor.close();

        if ("Completed".equalsIgnoreCase(status)) {

            Toast.makeText(
                    this,
                    "Completed quests cannot be edited.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

            return;
        }

        edtQuestName.setText(
                title
        );

        edtDescription.setText(
                description
        );

        edtDeadline.setText(
                deadline
        );

        setSpinnerValue(
                spinnerCategory,
                category
        );

        setSpinnerValue(
                spinnerDifficulty,
                difficulty
        );

        setSpinnerValue(
                spinnerDuration,
                duration
        );

        updateXP();
    }

    // ==========================================
    // SET SPINNER VALUE
    // ==========================================

    private void setSpinnerValue(
            Spinner spinner,
            String value) {

        if (value == null) {
            return;
        }

        ArrayAdapter<?> adapter =
                (ArrayAdapter<?>) spinner.getAdapter();

        for (
                int i = 0;
                i < adapter.getCount();
                i++
        ) {

            if (
                    value.equals(
                            adapter.getItem(i).toString()
                    )
            ) {

                spinner.setSelection(
                        i
                );

                return;
            }
        }
    }

    // ==========================================
    // AUTOMATIC XP
    // ==========================================

    private void updateXP() {

        int difficultyXP = 0;
        int durationXP = 0;

        String difficulty =
                spinnerDifficulty.getSelectedItem() == null
                        ? "Easy"
                        : spinnerDifficulty
                          .getSelectedItem()
                          .toString();

        String duration =
                spinnerDuration.getSelectedItem() == null
                        ? "15 minutes"
                        : spinnerDuration
                          .getSelectedItem()
                          .toString();

        if (difficulty.equals("Easy")) {

            difficultyXP = 20;

        } else if (difficulty.equals("Medium")) {

            difficultyXP = 40;

        } else if (difficulty.equals("Hard")) {

            difficultyXP = 70;

        } else if (difficulty.equals("Epic")) {

            difficultyXP = 100;
        }

        if (duration.equals("15 minutes")) {

            durationXP = 10;

        } else if (duration.equals("30 minutes")) {

            durationXP = 20;

        } else if (duration.equals("1 hour")) {

            durationXP = 30;

        } else if (duration.equals("2 hours")) {

            durationXP = 50;

        } else if (duration.equals("3+ hours")) {

            durationXP = 70;
        }

        int totalXP =
                difficultyXP +
                        durationXP;

        txtCalculatedXP.setText(
                totalXP + " XP"
        );

        txtXPExplanation.setText(
                difficulty +
                        " difficulty • " +
                        duration
        );
    }

    // ==========================================
    // DATE PICKER
    // ==========================================

    private void openDatePicker() {

        Calendar calendar =
                Calendar.getInstance();

        int year =
                calendar.get(
                        Calendar.YEAR
                );

        int month =
                calendar.get(
                        Calendar.MONTH
                );

        int day =
                calendar.get(
                        Calendar.DAY_OF_MONTH
                );

        DatePickerDialog datePicker =
                new DatePickerDialog(
                        this,
                        (view, selectedYear,
                         selectedMonth,
                         selectedDay) -> {

                            String date =
                                    String.format(
                                            "%02d / %02d / %04d",
                                            selectedDay,
                                            selectedMonth + 1,
                                            selectedYear
                                    );

                            edtDeadline.setText(
                                    date
                            );

                        },
                        year,
                        month,
                        day
                );

        Calendar today =
                Calendar.getInstance();

        today.set(
                Calendar.HOUR_OF_DAY,
                0
        );

        today.set(
                Calendar.MINUTE,
                0
        );

        today.set(
                Calendar.SECOND,
                0
        );

        today.set(
                Calendar.MILLISECOND,
                0
        );

        datePicker
                .getDatePicker()
                .setMinDate(
                        today.getTimeInMillis()
                );

        datePicker.show();
    }

    // ==========================================
    // SAVE QUEST
    // ==========================================

    private void saveQuest() {

        String questName =
                edtQuestName
                        .getText()
                        .toString()
                        .trim();

        String description =
                edtDescription
                        .getText()
                        .toString()
                        .trim();

        String deadline =
                edtDeadline
                        .getText()
                        .toString()
                        .trim();

        if (questName.isEmpty()) {

            edtQuestName.setError(
                    "Enter a quest name"
            );

            edtQuestName.requestFocus();

            return;
        }

        if (description.isEmpty()) {

            edtDescription.setError(
                    "Add a short description"
            );

            edtDescription.requestFocus();

            return;
        }

        if (deadline.isEmpty()) {

            edtDeadline.setError(
                    "Select a deadline"
            );

            edtDeadline.requestFocus();

            return;
        }

        String category =
                spinnerCategory
                        .getSelectedItem()
                        .toString();

        String difficulty =
                spinnerDifficulty
                        .getSelectedItem()
                        .toString();

        String duration =
                spinnerDuration
                        .getSelectedItem()
                        .toString();

        String xpText =
                txtCalculatedXP
                        .getText()
                        .toString();

        int xp =
                Integer.parseInt(
                        xpText
                                .replace(
                                        " XP",
                                        ""
                                )
                                .trim()
                );

        // ==========================================
        // EDIT EXISTING QUEST
        // ==========================================

        if (editMode) {

            ContentValues values =
                    new ContentValues();

            values.put(
                    "title",
                    questName
            );

            values.put(
                    "description",
                    description
            );

            values.put(
                    "category",
                    category
            );

            values.put(
                    "difficulty",
                    difficulty
            );

            values.put(
                    "duration",
                    duration
            );

            values.put(
                    "deadline",
                    deadline
            );

            values.put(
                    "xp",
                    xp
            );

            int rowsUpdated =
                    db.update(
                            "quests",
                            values,
                            "quest_id = ? AND user_id = ? " +
                                    "AND status != 'Completed'",
                            new String[]{
                                    String.valueOf(
                                            questId
                                    ),
                                    String.valueOf(
                                            userId
                                    )
                            }
                    );

            if (rowsUpdated > 0) {

                scheduleQuestNotifications(
                        questId,
                        questName,
                        deadline,
                        xp
                );

                scheduleQuestDeadlineCheck(
                        questId,
                        questName,
                        deadline,
                        xp
                );

                Toast.makeText(
                        this,
                        "Quest updated with " +
                                xp +
                                " XP",
                        Toast.LENGTH_SHORT
                ).show();

                finish();

            } else {

                Toast.makeText(
                        this,
                        "Could not update quest.",
                        Toast.LENGTH_SHORT
                ).show();
            }

            return;
        }

        // ==========================================
        // CREATE NEW QUEST
        // ==========================================

        String goal =
                spinnerGoal
                        .getSelectedItem()
                        .toString();

        ContentValues values =
                new ContentValues();

        values.put(
                "user_id",
                userId
        );

        values.put(
                "title",
                questName
        );

        values.put(
                "description",
                description
        );

        values.put(
                "category",
                category
        );

        values.put(
                "difficulty",
                difficulty
        );

        values.put(
                "duration",
                duration
        );

        values.put(
                "deadline",
                deadline
        );

        values.put(
                "status",
                "Available"
        );

        values.put(
                "goal_id",
                (Long) null
        );

        values.put(
                "xp",
                xp
        );

        String createdDate =
                new SimpleDateFormat(
                        "dd / MM / yyyy",
                        Locale.getDefault()
                ).format(
                        Calendar.getInstance().getTime()
                );

        values.put(
                "created_date",
                createdDate
        );

        values.putNull(
                "completed_date"
        );

        long newQuestId =
                db.insert(
                        "quests",
                        null,
                        values
                );

        if (newQuestId == -1) {

            Toast.makeText(
                    this,
                    "Failed to create quest.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        scheduleQuestNotifications(
                newQuestId,
                questName,
                deadline,
                xp
        );

        scheduleQuestDeadlineCheck(
                newQuestId,
                questName,
                deadline,
                xp
        );

        Toast.makeText(
                this,
                "Quest created with " +
                        xp +
                        " XP",
                Toast.LENGTH_SHORT
        ).show();

        finish();
    }

    // ==========================================
    // QUEST NOTIFICATIONS
    // ==========================================

    private void scheduleQuestNotifications(
            long questId,
            String title,
            String deadline,
            int xp) {

        cancelQuestNotifications(
                questId
        );

        Calendar deadlineCalendar =
                parseDeadline(
                        deadline
                );

        if (deadlineCalendar == null) {
            return;
        }

        Calendar now =
                Calendar.getInstance();

        Calendar today =
                Calendar.getInstance();

        clearTime(
                today
        );

        clearTime(
                deadlineCalendar
        );

        if (
                deadlineCalendar.before(
                        today
                )
        ) {
            return;
        }

        // ==========================================
        // MORNING REMINDER
        // ==========================================

        Calendar morning =
                Calendar.getInstance();

        morning.set(
                Calendar.HOUR_OF_DAY,
                9
        );

        morning.set(
                Calendar.MINUTE,
                0
        );

        morning.set(
                Calendar.SECOND,
                0
        );

        morning.set(
                Calendar.MILLISECOND,
                0
        );

        if (
                !morning.after(
                        now
                )
        ) {

            morning.add(
                    Calendar.DAY_OF_MONTH,
                    1
            );
        }

        // ==========================================
        // EVENING REMINDER
        // ==========================================

        Calendar evening =
                Calendar.getInstance();

        evening.set(
                Calendar.HOUR_OF_DAY,
                18
        );

        evening.set(
                Calendar.MINUTE,
                0
        );

        evening.set(
                Calendar.SECOND,
                0
        );

        evening.set(
                Calendar.MILLISECOND,
                0
        );

        if (
                !evening.after(
                        now
                )
        ) {

            evening.add(
                    Calendar.DAY_OF_MONTH,
                    1
            );
        }

        // ==========================================
        // SCHEDULE MORNING
        // ==========================================

        Calendar morningDate =
                Calendar.getInstance();

        morningDate.setTimeInMillis(
                morning.getTimeInMillis()
        );

        clearTime(
                morningDate
        );

        if (
                !morningDate.after(
                        deadlineCalendar
                )
        ) {

            setQuestAlarm(
                    questId,
                    title,
                    deadline,
                    xp,
                    "MORNING",
                    morning.getTimeInMillis()
            );
        }

        // ==========================================
        // SCHEDULE EVENING
        // ==========================================

        Calendar eveningDate =
                Calendar.getInstance();

        eveningDate.setTimeInMillis(
                evening.getTimeInMillis()
        );

        clearTime(
                eveningDate
        );

        if (
                !eveningDate.after(
                        deadlineCalendar
                )
        ) {

            setQuestAlarm(
                    questId,
                    title,
                    deadline,
                    xp,
                    "EVENING",
                    evening.getTimeInMillis()
            );
        }
    }

    // ==========================================
    // SET QUEST ALARM
    // ==========================================

    private void setQuestAlarm(
            long questId,
            String title,
            String deadline,
            int xp,
            String reminderType,
            long triggerTime) {

        AlarmManager alarmManager =
                (AlarmManager)
                        getSystemService(
                                ALARM_SERVICE
                        );

        if (alarmManager == null) {
            return;
        }

        Intent intent =
                new Intent(
                        this,
                        NotificationReceiver.class
                );

        intent.putExtra(
                "notification_type",
                "QUEST"
        );

        intent.putExtra(
                "USER_ID",
                userId
        );

        intent.putExtra(
                "QUEST_ID",
                questId
        );

        intent.putExtra(
                "title",
                title
        );

        intent.putExtra(
                "deadline",
                deadline
        );

        intent.putExtra(
                "xp",
                xp
        );

        intent.putExtra(
                "REMINDER_TYPE",
                reminderType
        );

        int notificationId =
                getQuestNotificationId(
                        questId,
                        reminderType
                );

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        this,
                        notificationId,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT
                                |
                                PendingIntent.FLAG_IMMUTABLE
                );

        if (
                triggerTime <=
                        System.currentTimeMillis()
        ) {
            return;
        }

        if (
                android.os.Build.VERSION.SDK_INT >=
                        android.os.Build.VERSION_CODES.S
        ) {

            if (
                    alarmManager.canScheduleExactAlarms()
            ) {

                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                );

            } else {

                alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                );
            }

        } else {

            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
            );
        }
    }

    // ==========================================
    // DEADLINE CHECK
    // ==========================================

    private void scheduleQuestDeadlineCheck(
            long questId,
            String title,
            String deadline,
            int xp) {

        cancelQuestDeadlineCheck(
                questId
        );

        Calendar deadlineCalendar =
                parseDeadline(
                        deadline
                );

        if (deadlineCalendar == null) {
            return;
        }

        clearTime(
                deadlineCalendar
        );

        deadlineCalendar.add(
                Calendar.DAY_OF_MONTH,
                1
        );

        deadlineCalendar.set(
                Calendar.HOUR_OF_DAY,
                0
        );

        deadlineCalendar.set(
                Calendar.MINUTE,
                1
        );

        deadlineCalendar.set(
                Calendar.SECOND,
                0
        );

        deadlineCalendar.set(
                Calendar.MILLISECOND,
                0
        );

        long triggerTime =
                deadlineCalendar.getTimeInMillis();

        if (
                triggerTime <=
                        System.currentTimeMillis()
        ) {
            return;
        }

        AlarmManager alarmManager =
                (AlarmManager)
                        getSystemService(
                                ALARM_SERVICE
                        );

        if (alarmManager == null) {
            return;
        }

        Intent intent =
                new Intent(
                        this,
                        NotificationReceiver.class
                );

        intent.putExtra(
                "notification_type",
                "QUEST_DEADLINE"
        );

        intent.putExtra(
                "USER_ID",
                userId
        );

        intent.putExtra(
                "QUEST_ID",
                questId
        );

        intent.putExtra(
                "title",
                title
        );

        intent.putExtra(
                "deadline",
                deadline
        );

        intent.putExtra(
                "xp",
                xp
        );

        int notificationId =
                getQuestDeadlineNotificationId(
                        questId
                );

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        this,
                        notificationId,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT
                                |
                                PendingIntent.FLAG_IMMUTABLE
                );

        if (
                android.os.Build.VERSION.SDK_INT >=
                        android.os.Build.VERSION_CODES.S
        ) {

            if (
                    alarmManager.canScheduleExactAlarms()
            ) {

                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                );

            } else {

                alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                );
            }

        } else {

            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
            );
        }
    }

    // ==========================================
    // CANCEL QUEST NOTIFICATIONS
    // ==========================================

    private void cancelQuestNotifications(
            long questId) {

        AlarmManager alarmManager =
                (AlarmManager)
                        getSystemService(
                                ALARM_SERVICE
                        );

        if (alarmManager == null) {
            return;
        }

        cancelQuestAlarm(
                alarmManager,
                questId,
                "MORNING"
        );

        cancelQuestAlarm(
                alarmManager,
                questId,
                "EVENING"
        );
    }

    private void cancelQuestAlarm(
            AlarmManager alarmManager,
            long questId,
            String reminderType) {

        int notificationId =
                getQuestNotificationId(
                        questId,
                        reminderType
                );

        Intent intent =
                new Intent(
                        this,
                        NotificationReceiver.class
                );

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        this,
                        notificationId,
                        intent,
                        PendingIntent.FLAG_NO_CREATE
                                |
                                PendingIntent.FLAG_IMMUTABLE
                );

        if (pendingIntent != null) {

            alarmManager.cancel(
                    pendingIntent
            );

            pendingIntent.cancel();
        }
    }

    // ==========================================
    // CANCEL DEADLINE CHECK
    // ==========================================

    private void cancelQuestDeadlineCheck(
            long questId) {

        AlarmManager alarmManager =
                (AlarmManager)
                        getSystemService(
                                ALARM_SERVICE
                        );

        if (alarmManager == null) {
            return;
        }

        int notificationId =
                getQuestDeadlineNotificationId(
                        questId
                );

        Intent intent =
                new Intent(
                        this,
                        NotificationReceiver.class
                );

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        this,
                        notificationId,
                        intent,
                        PendingIntent.FLAG_NO_CREATE
                                |
                                PendingIntent.FLAG_IMMUTABLE
                );

        if (pendingIntent != null) {

            alarmManager.cancel(
                    pendingIntent
            );

            pendingIntent.cancel();
        }
    }

    // ==========================================
    // PARSE DEADLINE
    // ==========================================

    private Calendar parseDeadline(
            String deadline) {

        try {

            SimpleDateFormat format =
                    new SimpleDateFormat(
                            "dd / MM / yyyy",
                            Locale.getDefault()
                    );

            format.setLenient(
                    false
            );

            java.util.Date date =
                    format.parse(
                            deadline
                    );

            if (date == null) {
                return null;
            }

            Calendar calendar =
                    Calendar.getInstance();

            calendar.setTime(
                    date
            );

            return calendar;

        } catch (Exception e) {

            return null;
        }
    }

    // ==========================================
    // CLEAR TIME
    // ==========================================

    private void clearTime(
            Calendar calendar) {

        calendar.set(
                Calendar.HOUR_OF_DAY,
                0
        );

        calendar.set(
                Calendar.MINUTE,
                0
        );

        calendar.set(
                Calendar.SECOND,
                0
        );

        calendar.set(
                Calendar.MILLISECOND,
                0
        );
    }

    // ==========================================
    // NOTIFICATION ID
    // ==========================================

    private int getQuestNotificationId(
            long questId,
            String reminderType) {

        int type;

        if (
                "MORNING".equals(
                        reminderType
                )
        ) {

            type = 1;

        } else {

            type = 2;
        }

        return (int)
                (
                        (questId * 10)
                                + type
                );
    }

    // ==========================================
    // DEADLINE NOTIFICATION ID
    // ==========================================

    private int getQuestDeadlineNotificationId(
            long questId) {

        return (int)
                (
                        (questId * 10)
                                + 3
                );
    }

    // ==========================================
    // BUTTON ANIMATION
    // ==========================================

    private void animateButton(
            View view) {

        ScaleAnimation animation =
                new ScaleAnimation(
                        1f,
                        0.94f,
                        1f,
                        0.94f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f
                );

        animation.setDuration(
                100
        );

        animation.setRepeatMode(
                ScaleAnimation.REVERSE
        );

        animation.setRepeatCount(
                1
        );

        view.startAnimation(
                animation
        );
    }
}
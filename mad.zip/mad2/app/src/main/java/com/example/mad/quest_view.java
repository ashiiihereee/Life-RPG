package com.example.mad;

import android.app.AlertDialog;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class quest_view extends AppCompatActivity {

    private long userId;
    private long questId;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private TextView txtQuestTitle;
    private TextView txtQuestCategory;
    private TextView txtQuestDescription;
    private TextView txtQuestDuration;
    private TextView txtQuestDeadline;
    private TextView txtQuestXP;
    private TextView txtQuestStatus;
    private TextView btnCompleteQuest;
    private TextView btnEditQuest;
    private TextView btnDeleteQuest;

    private boolean streakIncreasedToday = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_quest_view);


        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        questId =
                getIntent().getLongExtra(
                        "QUEST_ID",
                        -1
                );


        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();


        txtQuestTitle =
                findViewById(R.id.txtQuestTitle);

        txtQuestCategory =
                findViewById(R.id.txtQuestCategory);

        txtQuestDescription =
                findViewById(R.id.txtQuestDescription);

        txtQuestDuration =
                findViewById(R.id.txtQuestDuration);

        txtQuestDeadline =
                findViewById(R.id.txtQuestDeadline);

        txtQuestXP =
                findViewById(R.id.txtQuestXP);

        txtQuestStatus =
                findViewById(R.id.txtQuestStatus);

        btnCompleteQuest =
                findViewById(R.id.btnCompleteQuest);

        btnEditQuest =
                findViewById(R.id.btnEditQuest);

        btnDeleteQuest =
                findViewById(R.id.btnDeleteQuest);


        TextView btnBack =
                findViewById(R.id.btnBack);


        btnBack.setOnClickListener(
                view -> finish()
        );


        loadQuest();


        btnCompleteQuest.setOnClickListener(
                view -> completeQuest()
        );


        // ==========================================
        // EDIT QUEST
        // ==========================================

        btnEditQuest.setOnClickListener(
                view -> editQuest()
        );


        // ==========================================
        // DELETE QUEST
        // ==========================================

        btnDeleteQuest.setOnClickListener(
                view -> showDeleteConfirmation()
        );
    }


    // ==========================================
    // LOAD QUEST
    // ==========================================

    private void loadQuest() {

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "title",
                                "description",
                                "category",
                                "difficulty",
                                "duration",
                                "deadline",
                                "status",
                                "xp"
                        },
                        "quest_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(questId),
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (cursor.moveToFirst()) {

            String title =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "title"
                            )
                    );

            String description =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "description"
                            )
                    );

            String category =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "category"
                            )
                    );

            String difficulty =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "difficulty"
                            )
                    );

            String duration =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "duration"
                            )
                    );

            String deadline =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "deadline"
                            )
                    );

            String status =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "status"
                            )
                    );

            int xp =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "xp"
                            )
                    );


            txtQuestTitle.setText(
                    title
            );

            txtQuestCategory.setText(
                    category + " • " + difficulty
            );

            txtQuestDescription.setText(
                    description
            );

            txtQuestDuration.setText(
                    "⏱ " + duration
            );

            txtQuestDeadline.setText(
                    "📅 " + deadline
            );

            txtQuestXP.setText(
                    "⚡ " + xp + " XP"
            );

            txtQuestStatus.setText(
                    "Status: " + status
            );


            // ==========================================
            // COMPLETED QUEST
            // ==========================================

            if ("Completed".equalsIgnoreCase(status)) {

                btnCompleteQuest.setText(
                        "✓  QUEST COMPLETED"
                );

                btnCompleteQuest.setEnabled(false);

                btnCompleteQuest.setAlpha(
                        0.5f
                );


                // Completed quests cannot
                // be edited or deleted.

                btnEditQuest.setVisibility(
                        TextView.GONE
                );

                btnDeleteQuest.setVisibility(
                        TextView.GONE
                );
            }
        }


        cursor.close();
    }


    // ==========================================
    // EDIT QUEST
    // ==========================================

    private void editQuest() {

        Intent intent =
                new Intent(
                        quest_view.this,
                        quest_details.class
                );


        intent.putExtra(
                "USER_ID",
                userId
        );


        intent.putExtra(
                "QUEST_ID",
                questId
        );


        intent.putExtra(
                "EDIT_MODE",
                true
        );


        startActivity(intent);
    }


    // ==========================================
    // DELETE CONFIRMATION
    // ==========================================

    private void showDeleteConfirmation() {

        new AlertDialog.Builder(this)

                .setTitle(
                        "Delete Quest?"
                )

                .setMessage(
                        "Are you sure you want to delete this quest?\n\n" +
                                "This action cannot be undone."
                )

                .setNegativeButton(
                        "CANCEL",
                        null
                )

                .setPositiveButton(
                        "DELETE",
                        (dialog, which) ->
                                deleteQuest()
                )

                .show();
    }


    // ==========================================
    // DELETE QUEST
    // ==========================================

    private void deleteQuest() {

        int rowsDeleted =
                db.delete(
                        "quests",
                        "quest_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(questId),
                                String.valueOf(userId)
                        }
                );


        if (rowsDeleted > 0) {

            Toast.makeText(
                    this,
                    "Quest deleted.",
                    Toast.LENGTH_SHORT
            ).show();


            finish();

        } else {

            Toast.makeText(
                    this,
                    "Could not delete quest.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // ==========================================
    // COMPLETE QUEST
    // ==========================================

    private void completeQuest() {

        int questXP = 0;

        String questCategory = "";

        String questDifficulty = "";

        String questStatus = "";


        // ==========================================
        // GET QUEST
        // ==========================================

        Cursor questCursor =
                db.query(
                        "quests",
                        new String[]{
                                "xp",
                                "category",
                                "difficulty",
                                "status"
                        },
                        "quest_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(questId),
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (questCursor.moveToFirst()) {

            questXP =
                    questCursor.getInt(
                            questCursor.getColumnIndexOrThrow(
                                    "xp"
                            )
                    );

            questCategory =
                    questCursor.getString(
                            questCursor.getColumnIndexOrThrow(
                                    "category"
                            )
                    );

            questDifficulty =
                    questCursor.getString(
                            questCursor.getColumnIndexOrThrow(
                                    "difficulty"
                            )
                    );

            questStatus =
                    questCursor.getString(
                            questCursor.getColumnIndexOrThrow(
                                    "status"
                            )
                    );

        } else {

            questCursor.close();

            Toast.makeText(
                    this,
                    "Quest not found.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        questCursor.close();


        // ==========================================
        // PREVENT DOUBLE COMPLETION
        // ==========================================

        if ("Completed".equalsIgnoreCase(questStatus)) {

            Toast.makeText(
                    this,
                    "Quest already completed!",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        // ==========================================
        // CALCULATE COIN REWARD
        // ==========================================

        int coinReward = 0;


        if ("Easy".equalsIgnoreCase(questDifficulty)) {

            coinReward = 10;

        } else if ("Medium".equalsIgnoreCase(questDifficulty)) {

            coinReward = 20;

        } else if ("Hard".equalsIgnoreCase(questDifficulty)) {

            coinReward = 30;

        } else if ("Epic".equalsIgnoreCase(questDifficulty)) {

            coinReward = 50;
        }


        // ==========================================
        // GET PLAYER DATA
        // ==========================================

        int currentXP = 0;

        int currentLevel = 1;


        Cursor userCursor =
                db.query(
                        "users",
                        new String[]{
                                "xp",
                                "level"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (userCursor.moveToFirst()) {

            currentXP =
                    userCursor.getInt(
                            userCursor.getColumnIndexOrThrow(
                                    "xp"
                            )
                    );

            currentLevel =
                    userCursor.getInt(
                            userCursor.getColumnIndexOrThrow(
                                    "level"
                            )
                    );

        } else {

            userCursor.close();

            Toast.makeText(
                    this,
                    "Player not found.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        userCursor.close();


        // ==========================================
        // CALCULATE XP
        // ==========================================

        int newXP =
                currentXP + questXP;


        int newLevel =
                calculateLevel(newXP);


        // ==========================================
        // UPDATE USER XP + LEVEL
        // ==========================================

        ContentValues userValues =
                new ContentValues();


        userValues.put(
                "xp",
                newXP
        );


        userValues.put(
                "level",
                newLevel
        );


        int userRowsUpdated =
                db.update(
                        "users",
                        userValues,
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );


        if (userRowsUpdated == 0) {

            Toast.makeText(
                    this,
                    "Could not update player.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        // ==========================================
        // UPDATE CHARACTER STAT
        // ==========================================

        String statColumn = "";


        if (questCategory.equalsIgnoreCase("Study")) {

            statColumn = "intelligence";

        } else if (questCategory.equalsIgnoreCase("Fitness")) {

            statColumn = "strength";

        } else if (questCategory.equalsIgnoreCase("Health")) {

            statColumn = "health";

        } else if (questCategory.equalsIgnoreCase("Personal")) {

            statColumn = "discipline";

        } else if (questCategory.equalsIgnoreCase("Work")) {

            statColumn = "discipline";

        } else if (questCategory.equalsIgnoreCase("Creativity")) {

            statColumn = "creativity";
        }


        boolean statUpdated = false;


        if (!statColumn.isEmpty()) {

            db.execSQL(
                    "INSERT OR IGNORE INTO stats (user_id) VALUES (?)",
                    new String[]{
                            String.valueOf(userId)
                    }
            );


            Cursor statCursor =
                    db.rawQuery(
                            "SELECT " +
                                    statColumn +
                                    " FROM stats WHERE user_id = ?",
                            new String[]{
                                    String.valueOf(userId)
                            }
                    );


            if (statCursor.moveToFirst()) {

                int currentStat =
                        statCursor.getInt(
                                statCursor.getColumnIndexOrThrow(
                                        statColumn
                                )
                        );


                statCursor.close();


                ContentValues statValues =
                        new ContentValues();


                statValues.put(
                        statColumn,
                        currentStat + 1
                );


                int statRowsUpdated =
                        db.update(
                                "stats",
                                statValues,
                                "user_id = ?",
                                new String[]{
                                        String.valueOf(userId)
                                }
                        );


                if (statRowsUpdated > 0) {

                    statUpdated = true;
                }

            } else {

                statCursor.close();
            }
        }


        // ==========================================
        // MARK QUEST COMPLETED
        // ==========================================

        String completedDate =
                new SimpleDateFormat(
                        "dd / MM / yyyy",
                        Locale.getDefault()
                ).format(
                        Calendar.getInstance().getTime()
                );


        ContentValues questValues =
                new ContentValues();


        questValues.put(
                "status",
                "Completed"
        );


        questValues.put(
                "completed_date",
                completedDate
        );


        int questRowsUpdated =
                db.update(
                        "quests",
                        questValues,
                        "quest_id = ? AND user_id = ? AND status != 'Completed'",
                        new String[]{
                                String.valueOf(questId),
                                String.valueOf(userId)
                        }
                );


        // ==========================================
        // QUEST COMPLETED SUCCESSFULLY
        // ==========================================

        int currentStreak = 0;

        String unlockedAchievements = "";


        if (questRowsUpdated > 0) {

            // ==========================================
            // ADD COINS
            // ==========================================

            if (coinReward > 0) {

                db.execSQL(
                        "UPDATE users SET coins = coins + ? WHERE user_id = ?",
                        new String[]{
                                String.valueOf(coinReward),
                                String.valueOf(userId)
                        }
                );
            }


            // ==========================================
            // CANCEL QUEST NOTIFICATIONS
            // ==========================================

            cancelQuestNotifications();


            currentStreak =
                    updateStreak();


            createDefaultAchievements();


            unlockedAchievements =
                    checkAchievements();
        }


        final int finalStreak =
                currentStreak;


        final String finalUnlockedAchievements =
                unlockedAchievements;


        // ==========================================
        // SHOW RESULT
        // ==========================================

        if (questRowsUpdated > 0) {

            String message =
                    "+" +
                            questXP +
                            " XP earned!";


            if (coinReward > 0) {

                message =
                        message +
                                "\n🪙 +" +
                                coinReward +
                                " Coins earned!";
            }


            if (statUpdated) {

                message =
                        message +
                                "\n" +
                                questCategory +
                                " stat increased!";
            }


            Toast.makeText(
                    this,
                    message,
                    Toast.LENGTH_SHORT
            ).show();


            // ==========================================
            // ACHIEVEMENT TOAST
            // ==========================================

            if (!finalUnlockedAchievements.isEmpty()) {

                new Handler().postDelayed(
                        () -> {

                            Toast.makeText(
                                    quest_view.this,
                                    "🏆 Achievement Unlocked!\n" +
                                            finalUnlockedAchievements,
                                    Toast.LENGTH_LONG
                            ).show();

                        },
                        700
                );
            }


            // ==========================================
            // STREAK TOAST
            // ==========================================

            if (streakIncreasedToday) {

                new Handler().postDelayed(
                        () -> {

                            Toast.makeText(
                                    quest_view.this,
                                    "🔥 Streak: " +
                                            finalStreak +
                                            " day" +
                                            (
                                                    finalStreak == 1
                                                            ? ""
                                                            : "s"
                                            ) +
                                            "!",
                                    Toast.LENGTH_SHORT
                            ).show();

                        },
                        1500
                );
            }


            // ==========================================
            // LEVEL UP
            // ==========================================

            if (newLevel > currentLevel) {

                new Handler().postDelayed(
                        () -> {

                            Toast.makeText(
                                    quest_view.this,
                                    "🎉 LEVEL UP!\n" +
                                            "You are now Level " +
                                            newLevel +
                                            "!",
                                    Toast.LENGTH_LONG
                            ).show();

                        },
                        2300
                );


                new Handler().postDelayed(
                        () -> finish(),
                        4500
                );

            } else {

                new Handler().postDelayed(
                        () -> finish(),
                        3200
                );
            }

        } else {

            Toast.makeText(
                    this,
                    "Could not complete quest.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }


    // ==========================================
    // CANCEL QUEST NOTIFICATIONS
    // ==========================================

    private void cancelQuestNotifications() {

        AlarmManager alarmManager =
                (AlarmManager)
                        getSystemService(
                                ALARM_SERVICE
                        );


        if (alarmManager == null) {
            return;
        }


        cancelQuestAlarm(
                alarmManager,
                "MORNING"
        );


        cancelQuestAlarm(
                alarmManager,
                "EVENING"
        );
    }


    // ==========================================
    // CANCEL INDIVIDUAL QUEST ALARM
    // ==========================================

    private void cancelQuestAlarm(
            AlarmManager alarmManager,
            String reminderType) {

        int notificationId =
                getQuestNotificationId(
                        questId,
                        reminderType
                );


        Intent intent =
                new Intent(
                        this,
                        NotificationReceiver.class
                );


        intent.putExtra(
                "notification_type",
                "QUEST"
        );


        intent.putExtra(
                "USER_ID",
                userId
        );


        intent.putExtra(
                "QUEST_ID",
                questId
        );


        intent.putExtra(
                "REMINDER_TYPE",
                reminderType
        );


        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        this,
                        notificationId,
                        intent,
                        PendingIntent.FLAG_NO_CREATE
                                |
                                PendingIntent.FLAG_IMMUTABLE
                );


        if (pendingIntent != null) {

            alarmManager.cancel(
                    pendingIntent
            );

            pendingIntent.cancel();
        }
    }


    // ==========================================
    // QUEST NOTIFICATION ID
    // ==========================================

    private int getQuestNotificationId(
            long questId,
            String reminderType) {

        int type =
                "MORNING".equals(
                        reminderType
                )
                        ? 1
                        : 2;


        return (int)
                (
                        (questId * 10)
                                +
                                type
                );
    }


    // ==========================================
    // CREATE DEFAULT ACHIEVEMENTS
    // ==========================================

    private void createDefaultAchievements() {

        String[] keys = {
                "first_quest",
                "quest_novice",
                "on_fire",
                "dedicated",
                "xp_hunter",
                "level_up",
                "veteran",
                "legend"
        };


        String[] titles = {
                "FIRST QUEST",
                "QUEST NOVICE",
                "ON FIRE",
                "DEDICATED",
                "XP HUNTER",
                "LEVEL UP",
                "VETERAN",
                "LEGEND"
        };


        String[] descriptions = {
                "Complete your first quest.",
                "Complete 5 quests.",
                "Reach a 3-day streak.",
                "Reach a 7-day streak.",
                "Earn 500 total XP.",
                "Reach Level 5.",
                "Complete 25 quests.",
                "Earn 1000 total XP."
        };


        for (int i = 0; i < keys.length; i++) {

            Cursor cursor =
                    db.query(
                            "achievements",
                            new String[]{
                                    "achievement_id"
                            },
                            "user_id = ? AND achievement_key = ?",
                            new String[]{
                                    String.valueOf(userId),
                                    keys[i]
                            },
                            null,
                            null,
                            null
                    );


            boolean exists =
                    cursor.moveToFirst();


            cursor.close();


            if (!exists) {

                ContentValues values =
                        new ContentValues();


                values.put(
                        "user_id",
                        userId
                );


                values.put(
                        "achievement_key",
                        keys[i]
                );


                values.put(
                        "title",
                        titles[i]
                );


                values.put(
                        "description",
                        descriptions[i]
                );


                values.put(
                        "unlocked",
                        0
                );


                db.insert(
                        "achievements",
                        null,
                        values
                );
            }
        }
    }


    // ==========================================
    // UPDATE STREAK
    // ==========================================

    private int updateStreak() {

        int currentStreak = 0;

        int bestStreak = 0;

        String lastCompletedDate = null;


        streakIncreasedToday = false;


        db.execSQL(
                "INSERT OR IGNORE INTO streaks (user_id) VALUES (?)",
                new String[]{
                        String.valueOf(userId)
                }
        );


        Cursor streakCursor =
                db.query(
                        "streaks",
                        new String[]{
                                "current_streak",
                                "best_streak",
                                "last_completed_date"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (streakCursor.moveToFirst()) {

            currentStreak =
                    streakCursor.getInt(
                            streakCursor.getColumnIndexOrThrow(
                                    "current_streak"
                            )
                    );

            bestStreak =
                    streakCursor.getInt(
                            streakCursor.getColumnIndexOrThrow(
                                    "best_streak"
                            )
                    );

            lastCompletedDate =
                    streakCursor.getString(
                            streakCursor.getColumnIndexOrThrow(
                                    "last_completed_date"
                            )
                    );
        }


        streakCursor.close();


        SimpleDateFormat dateFormat =
                new SimpleDateFormat(
                        "yyyy-MM-dd",
                        Locale.getDefault()
                );


        dateFormat.setLenient(false);


        Calendar today =
                Calendar.getInstance();


        String todayDate =
                dateFormat.format(
                        today.getTime()
                );


        if (lastCompletedDate == null ||
                lastCompletedDate.isEmpty()) {

            currentStreak = 1;

            streakIncreasedToday = true;

        } else if (lastCompletedDate.equals(todayDate)) {

            streakIncreasedToday = false;

        } else {

            Calendar yesterday =
                    Calendar.getInstance();


            yesterday.add(
                    Calendar.DAY_OF_YEAR,
                    -1
            );


            String yesterdayDate =
                    dateFormat.format(
                            yesterday.getTime()
                    );


            if (lastCompletedDate.equals(yesterdayDate)) {

                currentStreak =
                        currentStreak + 1;

                streakIncreasedToday = true;

            } else {

                currentStreak = 1;

                streakIncreasedToday = true;
            }
        }


        if (currentStreak > bestStreak) {

            bestStreak =
                    currentStreak;
        }


        ContentValues streakValues =
                new ContentValues();


        streakValues.put(
                "current_streak",
                currentStreak
        );


        streakValues.put(
                "best_streak",
                bestStreak
        );


        streakValues.put(
                "last_completed_date",
                todayDate
        );


        db.update(
                "streaks",
                streakValues,
                "user_id = ?",
                new String[]{
                        String.valueOf(userId)
                }
        );


        return currentStreak;
    }


    // ==========================================
    // CHECK ACHIEVEMENTS
    // ==========================================

    private String checkAchievements() {

        int completedQuests = 0;

        int totalXP = 0;

        int playerLevel = 1;

        int currentStreak = 0;


        StringBuilder unlockedAchievements =
                new StringBuilder();


        Cursor userCursor =
                db.query(
                        "users",
                        new String[]{
                                "xp",
                                "level"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (userCursor.moveToFirst()) {

            totalXP =
                    userCursor.getInt(
                            userCursor.getColumnIndexOrThrow(
                                    "xp"
                            )
                    );

            playerLevel =
                    userCursor.getInt(
                            userCursor.getColumnIndexOrThrow(
                                    "level"
                            )
                    );
        }


        userCursor.close();


        Cursor questCursor =
                db.rawQuery(
                        "SELECT COUNT(*) FROM quests " +
                                "WHERE user_id = ? " +
                                "AND status = ?",
                        new String[]{
                                String.valueOf(userId),
                                "Completed"
                        }
                );


        if (questCursor.moveToFirst()) {

            completedQuests =
                    questCursor.getInt(0);
        }


        questCursor.close();


        Cursor streakCursor =
                db.query(
                        "streaks",
                        new String[]{
                                "current_streak"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );


        if (streakCursor.moveToFirst()) {

            currentStreak =
                    streakCursor.getInt(
                            streakCursor.getColumnIndexOrThrow(
                                    "current_streak"
                            )
                    );
        }


        streakCursor.close();


        // ==========================================
        // FIRST QUEST
        // ==========================================

        if (completedQuests >= 1 &&
                unlockAchievement("first_quest")) {

            addUnlockedAchievement(
                    unlockedAchievements,
                    "FIRST QUEST"
            );
        }


        // ==========================================
        // QUEST NOVICE
        // ==========================================

        if (completedQuests >= 5 &&
                unlockAchievement("quest_novice")) {

            addUnlockedAchievement(
                    unlockedAchievements,
                    "QUEST NOVICE"
            );
        }


        // ==========================================
        // ON FIRE
        // ==========================================

        if (currentStreak >= 3 &&
                unlockAchievement("on_fire")) {

            addUnlockedAchievement(
                    unlockedAchievements,
                    "ON FIRE"
            );
        }


        // ==========================================
        // DEDICATED
        // ==========================================

        if (currentStreak >= 7 &&
                unlockAchievement("dedicated")) {

            addUnlockedAchievement(
                    unlockedAchievements,
                    "DEDICATED"
            );
        }


        // ==========================================
        // XP HUNTER
        // ==========================================

        if (totalXP >= 500 &&
                unlockAchievement("xp_hunter")) {

            addUnlockedAchievement(
                    unlockedAchievements,
                    "XP HUNTER"
            );
        }


        // ==========================================
        // LEVEL UP
        // ==========================================

        if (playerLevel >= 5 &&
                unlockAchievement("level_up")) {

            addUnlockedAchievement(
                    unlockedAchievements,
                    "LEVEL UP"
            );
        }


        // ==========================================
        // VETERAN
        // ==========================================

        if (completedQuests >= 25 &&
                unlockAchievement("veteran")) {

            addUnlockedAchievement(
                    unlockedAchievements,
                    "VETERAN"
            );
        }


        // ==========================================
        // LEGEND
        // ==========================================

        if (totalXP >= 1000 &&
                unlockAchievement("legend")) {

            addUnlockedAchievement(
                    unlockedAchievements,
                    "LEGEND"
            );
        }


        return unlockedAchievements.toString();
    }


    // ==========================================
    // ADD ACHIEVEMENT TO TOAST
    // ==========================================

    private void addUnlockedAchievement(
            StringBuilder builder,
            String achievementName) {

        if (builder.length() > 0) {

            builder.append("\n");
        }


        builder.append(
                "• " +
                        achievementName
        );
    }


    // ==========================================
    // UNLOCK ACHIEVEMENT
    // ==========================================

    private boolean unlockAchievement(
            String achievementKey) {

        ContentValues values =
                new ContentValues();


        values.put(
                "unlocked",
                1
        );


        values.put(
                "unlocked_date",
                new SimpleDateFormat(
                        "dd / MM / yyyy",
                        Locale.getDefault()
                ).format(
                        Calendar.getInstance().getTime()
                )
        );


        int rowsUpdated =
                db.update(
                        "achievements",
                        values,
                        "user_id = ? " +
                                "AND achievement_key = ? " +
                                "AND unlocked = 0",
                        new String[]{
                                String.valueOf(userId),
                                achievementKey
                        }
                );


        return rowsUpdated > 0;
    }


    // ==========================================
    // CALCULATE LEVEL
    // ==========================================

    private int calculateLevel(int xp) {

        if (xp >= 5850) {

            return 10;

        } else if (xp >= 4800) {

            return 9;

        } else if (xp >= 3850) {

            return 8;

        } else if (xp >= 3000) {

            return 7;

        } else if (xp >= 2250) {

            return 6;

        } else if (xp >= 1600) {

            return 5;

        } else if (xp >= 1050) {

            return 4;

        } else if (xp >= 600) {

            return 3;

        } else if (xp >= 250) {

            return 2;

        } else {

            return 1;
        }
    }
}
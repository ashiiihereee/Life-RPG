package com.example.mad;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class home extends AppCompatActivity {

    private TextView txtSmallGreeting;
    private TextView txtPlayerName;
    private TextView txtProfile;

    private TextView txtLevel;
    private TextView txtXP;
    private ProgressBar xpProgress;

    private TextView txtStreak;
    private TextView txtBestStreak;

    private LinearLayout questCard;
    private LinearLayout challengeCard;
    private LinearLayout goalCard;
    private LinearLayout galleryCard;
    private LinearLayout progressCard;
    private LinearLayout calendarCard;
    private LinearLayout lifeMapCard;
    private LinearLayout knowledgeCard;
    private LinearLayout dataExportCard;
    private LinearLayout achievementCard;
    private LinearLayout shopCard;

    private TextView txtLogout;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private long userId;
    private String playerName;

    private static final String PREFS_NAME = "LifeRPGSession";
    private static final String KEY_REMEMBER_ME = "remember_me";
    private static final String KEY_USER_ID = "remembered_user_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home);

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getReadableDatabase();

        txtSmallGreeting =
                findViewById(R.id.txtSmallGreeting);

        txtPlayerName =
                findViewById(R.id.txtPlayerName);

        txtProfile =
                findViewById(R.id.txtProfile);

        txtLevel =
                findViewById(R.id.txtLevel);

        txtXP =
                findViewById(R.id.txtXP);

        xpProgress =
                findViewById(R.id.xpProgress);

        txtStreak =
                findViewById(R.id.txtStreak);

        txtBestStreak =
                findViewById(R.id.txtBestStreak);

        questCard =
                findViewById(R.id.questCard);

        goalCard =
                findViewById(R.id.goalCard);

        galleryCard =
                findViewById(R.id.galleryCard);

        progressCard =
                findViewById(R.id.progressCard);

        calendarCard =
                findViewById(R.id.calendarCard);

        lifeMapCard =
                findViewById(R.id.lifeMapCard);

        knowledgeCard =
                findViewById(R.id.knowledgeCard);

        dataExportCard =
                findViewById(R.id.dataExportCard);

        achievementCard =
                findViewById(R.id.achievementCard);

        shopCard =
                findViewById(R.id.shopCard);

        challengeCard =
                findViewById(R.id.challengeCard);

        txtLogout =
                findViewById(R.id.txtLogout);

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        if (userId == -1) {

            Intent intent =
                    new Intent(
                            home.this,
                            MainActivity.class
                    );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);

            finish();

            return;
        }

        loadUserData();

        loadStreakData();

        animatePage();

        // PROFILE

        txtProfile.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            profile.class
                    );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // QUEST ROADMAP

        questCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            roadmap.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // GOALS

        goalCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            goal_tracker.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // GALLERY / LIFE VAULT

        galleryCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            data_export.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // PROGRESS

        progressCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            progress.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // LIFE CALENDAR

        calendarCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            calender.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // LIFE MAP

        lifeMapCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            lifemap.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // KNOWLEDGE VAULT

        knowledgeCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            knowledge.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // DATA EXPORT

        dataExportCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            filehandling.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // ACHIEVEMENTS

        achievementCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            achievement.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // RPG SHOP

        shopCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            shop.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // CHALLENGES

        challengeCard.setOnClickListener(view -> {

            animateClick(view);

            Intent intent =
                    new Intent(
                            home.this,
                            challenges.class
                    );

            intent.putExtra(
                    "PLAYER_NAME",
                    playerName
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            startActivity(intent);
        });

        // LOGOUT

        txtLogout.setOnClickListener(view -> {

            clearRememberedSession();

            Intent intent =
                    new Intent(
                            home.this,
                            MainActivity.class
                    );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);

            finish();
        });
    }

    private void loadUserData() {

        Cursor cursor =
                db.query(
                        "users",
                        new String[]{
                                "name",
                                "level",
                                "xp",
                                "coins"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (cursor.moveToFirst()) {

            playerName =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "name"
                            )
                    );

            int level =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "level"
                            )
                    );

            int xp =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "xp"
                            )
                    );

            txtSmallGreeting.setText(
                    "WELCOME BACK,"
            );

            txtPlayerName.setText(
                    playerName
            );

            String initial =
                    playerName
                            .trim()
                            .substring(0, 1)
                            .toUpperCase();

            txtProfile.setText(
                    initial
            );

            txtLevel.setText(
                    "LEVEL " +
                            String.format(
                                    "%02d",
                                    level
                            )
            );

            int startXP =
                    getLevelStartXP(level);

            int nextXP =
                    getNextLevelXP(level);

            int currentLevelXP =
                    xp - startXP;

            int requiredLevelXP =
                    nextXP - startXP;

            if (level >= 10) {

                currentLevelXP =
                        xp - startXP;

                requiredLevelXP = 1;
            }

            if (currentLevelXP < 0) {
                currentLevelXP = 0;
            }

            if (currentLevelXP > requiredLevelXP) {
                currentLevelXP = requiredLevelXP;
            }

            txtXP.setText(
                    currentLevelXP +
                            " / " +
                            (nextXP - startXP) +
                            " XP"
            );

            xpProgress.setMax(
                    Math.max(
                            requiredLevelXP,
                            1
                    )
            );

            xpProgress.setProgress(
                    currentLevelXP
            );
        }

        cursor.close();
    }

    private void loadStreakData() {

        int currentStreak = 0;

        int bestStreak = 0;

        Cursor cursor =
                db.query(
                        "streaks",
                        new String[]{
                                "current_streak",
                                "best_streak"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (cursor.moveToFirst()) {

            currentStreak =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "current_streak"
                            )
                    );

            bestStreak =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "best_streak"
                            )
                    );
        }

        cursor.close();

        txtStreak.setText(
                currentStreak +
                        " DAY" +
                        (
                                currentStreak == 1
                                        ? ""
                                        : "S"
                        )
        );

        txtBestStreak.setText(
                "BEST: " +
                        bestStreak
        );
    }

    private int getLevelStartXP(
            int level) {

        if (level >= 10) return 5850;
        else if (level == 9) return 4800;
        else if (level == 8) return 3850;
        else if (level == 7) return 3000;
        else if (level == 6) return 2250;
        else if (level == 5) return 1600;
        else if (level == 4) return 1050;
        else if (level == 3) return 600;
        else if (level == 2) return 250;
        else return 0;
    }

    private int getNextLevelXP(
            int level) {

        if (level >= 10) return 5850;
        else if (level == 9) return 5850;
        else if (level == 8) return 4800;
        else if (level == 7) return 3850;
        else if (level == 6) return 3000;
        else if (level == 5) return 2250;
        else if (level == 4) return 1600;
        else if (level == 3) return 1050;
        else if (level == 2) return 600;
        else return 250;
    }

    @Override
    protected void onResume() {

        super.onResume();

        if (
                db != null &&
                        userId != -1
        ) {

            loadUserData();

            loadStreakData();
        }
    }

    private void animatePage() {

        View content =
                findViewById(
                        R.id.homeContent
                );

        AlphaAnimation fade =
                new AlphaAnimation(
                        0.0f,
                        1.0f
                );

        fade.setDuration(700);

        content.startAnimation(
                fade
        );
    }

    private void animateClick(
            View view) {

        ScaleAnimation animation =
                new ScaleAnimation(
                        1.0f,
                        0.96f,
                        1.0f,
                        0.96f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f,
                        ScaleAnimation.RELATIVE_TO_SELF,
                        0.5f
                );

        animation.setDuration(100);

        animation.setRepeatMode(
                ScaleAnimation.REVERSE
        );

        animation.setRepeatCount(1);

        view.startAnimation(
                animation
        );
    }

    private void clearRememberedSession() {

        getSharedPreferences(
                PREFS_NAME,
                MODE_PRIVATE
        )
                .edit()
                .remove(KEY_REMEMBER_ME)
                .remove(KEY_USER_ID)
                .apply();
    }
}
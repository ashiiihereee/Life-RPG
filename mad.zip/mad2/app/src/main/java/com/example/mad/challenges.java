package com.example.mad;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class challenges extends AppCompatActivity {

    private long userId;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    private LinearLayout dailyContainer;
    private LinearLayout weeklyContainer;

    private TextView txtDailyDate;
    private TextView txtWeeklyDate;
    private TextView btnBack;

    private final String DATE_FORMAT = "dd / MM / yyyy";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_challenges);

        userId =
                getIntent().getLongExtra(
                        "USER_ID",
                        -1
                );

        if (userId == -1) {

            finish();

            return;
        }

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();

        dailyContainer =
                findViewById(R.id.dailyContainer);

        weeklyContainer =
                findViewById(R.id.weeklyContainer);

        txtDailyDate =
                findViewById(R.id.txtDailyDate);

        txtWeeklyDate =
                findViewById(R.id.txtWeeklyDate);

        btnBack =
                findViewById(R.id.btnBack);

        btnBack.setOnClickListener(
                view -> finish()
        );

        createChallengeTable();

        loadChallenges();
    }


    // ==========================================
    // CREATE CHALLENGE TABLE
    // ==========================================

    private void createChallengeTable() {

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS challenge_claims (" +
                        "claim_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "challenge_type TEXT NOT NULL, " +
                        "challenge_key TEXT NOT NULL, " +
                        "period TEXT NOT NULL, " +
                        "claimed_date TEXT NOT NULL, " +
                        "reward INTEGER DEFAULT 0, " +
                        "UNIQUE(user_id, challenge_type, challenge_key, period)" +
                        ")"
        );
    }


    // ==========================================
    // LOAD CHALLENGES
    // ==========================================

    private void loadChallenges() {

        dailyContainer.removeAllViews();

        weeklyContainer.removeAllViews();

        String today =
                getTodayDate();

        String weekStart =
                getWeekStartDate();

        String weekEnd =
                getWeekEndDate();

        txtDailyDate.setText(
                today
        );

        txtWeeklyDate.setText(
                weekStart +
                        " - " +
                        weekEnd
        );


        // ==========================================
        // DAILY
        // ==========================================

        addDailyChallenge(
                "complete_1",
                "COMPLETE 1 QUEST",
                "Complete at least 1 quest today.",
                1,
                10,
                1
        );

        addDailyChallenge(
                "complete_2",
                "COMPLETE 2 QUESTS",
                "Complete 2 quests today.",
                2,
                15,
                2
        );

        addDailyChallenge(
                "earn_50_xp",
                "XP HUNTER",
                "Earn 50 XP from completed quests today.",
                50,
                10,
                3
        );

        addDailyChallenge(
                "hard_epic",
                "RISE TO THE CHALLENGE",
                "Complete 1 Hard or Epic quest today.",
                1,
                15,
                4
        );


        // ==========================================
        // WEEKLY
        // ==========================================

        addWeeklyChallenge(
                "complete_5",
                "QUEST WARRIOR",
                "Complete 5 quests this week.",
                5,
                30,
                1
        );

        addWeeklyChallenge(
                "complete_10",
                "QUEST MACHINE",
                "Complete 10 quests this week.",
                10,
                50,
                2
        );

        addWeeklyChallenge(
                "earn_250_xp",
                "XP CHAMPION",
                "Earn 250 XP this week.",
                250,
                40,
                3
        );

        addWeeklyChallenge(
                "hard_epic_2",
                "ELITE CHALLENGE",
                "Complete 2 Hard or Epic quests this week.",
                2,
                40,
                4
        );

        addWeeklyChallenge(
                "five_days",
                "CONSISTENCY KING",
                "Complete quests on 5 different days this week.",
                5,
                50,
                5
        );
    }


    // ==========================================
    // ADD DAILY CHALLENGE
    // ==========================================

    private void addDailyChallenge(
            String key,
            String title,
            String description,
            int target,
            int reward,
            int type) {

        String period =
                getTodayDate();

        int progress =
                getDailyProgress(
                        type
                );

        boolean claimed =
                isClaimed(
                        "DAILY",
                        key,
                        period
                );

        View card =
                createChallengeCard(
                        "DAILY",
                        key,
                        title,
                        description,
                        progress,
                        target,
                        reward,
                        claimed
                );

        dailyContainer.addView(card);
    }


    // ==========================================
    // ADD WEEKLY CHALLENGE
    // ==========================================

    private void addWeeklyChallenge(
            String key,
            String title,
            String description,
            int target,
            int reward,
            int type) {

        String period =
                getWeekStartDate();

        int progress =
                getWeeklyProgress(
                        type
                );

        boolean claimed =
                isClaimed(
                        "WEEKLY",
                        key,
                        period
                );

        View card =
                createChallengeCard(
                        "WEEKLY",
                        key,
                        title,
                        description,
                        progress,
                        target,
                        reward,
                        claimed
                );

        weeklyContainer.addView(card);
    }


    // ==========================================
    // CREATE CHALLENGE CARD
    // ==========================================

    private View createChallengeCard(
            String challengeType,
            String key,
            String title,
            String description,
            int progress,
            int target,
            int reward,
            boolean claimed) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL
        );

        card.setPadding(
                18,
                18,
                18,
                18
        );

        card.setBackgroundColor(
                Color.parseColor(
                        "#D91A142E"
                )
        );

        card.setElevation(
                7
        );


        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        cardParams.setMargins(
                0,
                0,
                0,
                10
        );

        card.setLayoutParams(
                cardParams
        );


        // ==========================================
        // TITLE ROW
        // ==========================================

        LinearLayout titleRow =
                new LinearLayout(this);

        titleRow.setOrientation(
                LinearLayout.HORIZONTAL
        );

        titleRow.setGravity(
                Gravity.CENTER_VERTICAL
        );


        TextView titleView =
                new TextView(this);

        titleView.setText(
                title
        );

        titleView.setTextColor(
                Color.WHITE
        );

        titleView.setTextSize(
                14
        );

        titleView.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );


        LinearLayout.LayoutParams titleParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                );

        titleView.setLayoutParams(
                titleParams
        );


        TextView rewardView =
                new TextView(this);

        rewardView.setText(
                "🪙 +" +
                        reward
        );

        rewardView.setTextColor(
                Color.parseColor(
                        "#ECA9DF"
                )
        );

        rewardView.setTextSize(
                11
        );

        rewardView.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );


        titleRow.addView(
                titleView
        );

        titleRow.addView(
                rewardView
        );

        card.addView(
                titleRow
        );


        // ==========================================
        // DESCRIPTION
        // ==========================================

        TextView descriptionView =
                new TextView(this);

        descriptionView.setText(
                description
        );

        descriptionView.setTextColor(
                Color.parseColor(
                        "#AFA2BB"
                )
        );

        descriptionView.setTextSize(
                10
        );

        LinearLayout.LayoutParams descriptionParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        descriptionParams.setMargins(
                0,
                5,
                0,
                0
        );

        descriptionView.setLayoutParams(
                descriptionParams
        );

        card.addView(
                descriptionView
        );


        // ==========================================
        // PROGRESS
        // ==========================================

        int safeProgress =
                Math.min(
                        Math.max(progress, 0),
                        target
                );


        TextView progressView =
                new TextView(this);

        progressView.setText(
                safeProgress +
                        " / " +
                        target
        );

        progressView.setTextColor(
                Color.WHITE
        );

        progressView.setTextSize(
                11
        );

        progressView.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        LinearLayout.LayoutParams progressParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        progressParams.setMargins(
                0,
                12,
                0,
                0
        );

        progressView.setLayoutParams(
                progressParams
        );

        card.addView(
                progressView
        );


        // ==========================================
        // PROGRESS BAR
        // ==========================================

        android.widget.ProgressBar progressBar =
                new android.widget.ProgressBar(
                        this,
                        null,
                        android.R.attr.progressBarStyleHorizontal
                );

        progressBar.setMax(
                target
        );

        progressBar.setProgress(
                safeProgress
        );

        progressBar.setProgressTintList(
                android.content.res.ColorStateList.valueOf(
                        Color.parseColor(
                                "#E5A5DC"
                        )
                )
        );

        progressBar.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(
                        Color.parseColor(
                                "#3A3048"
                        )
                )
        );

        LinearLayout.LayoutParams barParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        8
                );

        barParams.setMargins(
                0,
                7,
                0,
                0
        );

        progressBar.setLayoutParams(
                barParams
        );

        card.addView(
                progressBar
        );


        // ==========================================
        // CLAIM BUTTON
        // ==========================================

        Button claimButton =
                new Button(this);

        LinearLayout.LayoutParams buttonParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        48
                );

        buttonParams.setMargins(
                0,
                13,
                0,
                0
        );

        claimButton.setLayoutParams(
                buttonParams
        );


        if (claimed) {

            claimButton.setText(
                    "✓  REWARD CLAIMED"
            );

            claimButton.setEnabled(
                    false
            );

            claimButton.setAlpha(
                    0.5f
            );

        } else if (safeProgress >= target) {

            claimButton.setText(
                    "CLAIM +" +
                            reward +
                            " COINS"
            );

            claimButton.setTextColor(
                    Color.WHITE
            );

            claimButton.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(
                            Color.parseColor(
                                    "#C77BD9"
                            )
                    )
            );

            claimButton.setOnClickListener(
                    view -> claimReward(
                            challengeType,
                            key,
                            reward
                    )
            );

        } else {

            claimButton.setText(
                    "IN PROGRESS"
            );

            claimButton.setEnabled(
                    false
            );

            claimButton.setAlpha(
                    0.45f
            );
        }


        card.addView(
                claimButton
        );


        return card;
    }


    // ==========================================
    // DAILY PROGRESS
    // ==========================================

    private int getDailyProgress(
            int type) {

        String today =
                getTodayDate();

        int result = 0;


        if (type == 1) {

            result =
                    getQuestCountForPeriod(
                            today,
                            today
                    );

        } else if (type == 2) {

            result =
                    getQuestCountForPeriod(
                            today,
                            today
                    );

        } else if (type == 3) {

            result =
                    getXPForPeriod(
                            today,
                            today
                    );

        } else if (type == 4) {

            result =
                    getHardEpicCountForPeriod(
                            today,
                            today
                    );
        }


        return result;
    }


    // ==========================================
    // WEEKLY PROGRESS
    // ==========================================

    private int getWeeklyProgress(
            int type) {

        String start =
                getWeekStartDate();

        String end =
                getWeekEndDate();

        int result = 0;


        if (type == 1) {

            result =
                    getQuestCountForPeriod(
                            start,
                            end
                    );

        } else if (type == 2) {

            result =
                    getQuestCountForPeriod(
                            start,
                            end
                    );

        } else if (type == 3) {

            result =
                    getXPForPeriod(
                            start,
                            end
                    );

        } else if (type == 4) {

            result =
                    getHardEpicCountForPeriod(
                            start,
                            end
                    );

        } else if (type == 5) {

            result =
                    getDifferentCompletionDays(
                            start,
                            end
                    );
        }


        return result;
    }


    // ==========================================
    // QUEST COUNT
    // ==========================================

    private int getQuestCountForPeriod(
            String startDate,
            String endDate) {

        int count = 0;

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "completed_date"
                        },
                        "user_id = ? AND status = ?",
                        new String[]{
                                String.valueOf(userId),
                                "Completed"
                        },
                        null,
                        null,
                        null
                );


        while (cursor.moveToNext()) {

            String completedDate =
                    cursor.getString(0);

            if (isDateInRange(
                    completedDate,
                    startDate,
                    endDate
            )) {

                count++;
            }
        }


        cursor.close();

        return count;
    }


    // ==========================================
    // XP
    // ==========================================

    private int getXPForPeriod(
            String startDate,
            String endDate) {

        int totalXP = 0;

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "completed_date",
                                "xp"
                        },
                        "user_id = ? AND status = ?",
                        new String[]{
                                String.valueOf(userId),
                                "Completed"
                        },
                        null,
                        null,
                        null
                );


        while (cursor.moveToNext()) {

            String completedDate =
                    cursor.getString(0);

            if (isDateInRange(
                    completedDate,
                    startDate,
                    endDate
            )) {

                totalXP +=
                        cursor.getInt(1);
            }
        }


        cursor.close();

        return totalXP;
    }


    // ==========================================
    // HARD / EPIC
    // ==========================================

    private int getHardEpicCountForPeriod(
            String startDate,
            String endDate) {

        int count = 0;

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "completed_date",
                                "difficulty"
                        },
                        "user_id = ? AND status = ?",
                        new String[]{
                                String.valueOf(userId),
                                "Completed"
                        },
                        null,
                        null,
                        null
                );


        while (cursor.moveToNext()) {

            String completedDate =
                    cursor.getString(0);

            String difficulty =
                    cursor.getString(1);

            if (isDateInRange(
                    completedDate,
                    startDate,
                    endDate
            )) {

                if (
                        "Hard".equalsIgnoreCase(
                                difficulty
                        )
                                ||
                                "Epic".equalsIgnoreCase(
                                        difficulty
                                )
                ) {

                    count++;
                }
            }
        }


        cursor.close();

        return count;
    }


    // ==========================================
    // DIFFERENT COMPLETION DAYS
    // ==========================================

    private int getDifferentCompletionDays(
            String startDate,
            String endDate) {

        java.util.HashSet<String> dates =
                new java.util.HashSet<>();

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "completed_date"
                        },
                        "user_id = ? AND status = ?",
                        new String[]{
                                String.valueOf(userId),
                                "Completed"
                        },
                        null,
                        null,
                        null
                );


        while (cursor.moveToNext()) {

            String completedDate =
                    cursor.getString(0);

            if (isDateInRange(
                    completedDate,
                    startDate,
                    endDate
            )) {

                dates.add(
                        completedDate
                );
            }
        }


        cursor.close();

        return dates.size();
    }


    // ==========================================
    // CHECK CLAIMED
    // ==========================================

    private boolean isClaimed(
            String type,
            String key,
            String period) {

        Cursor cursor =
                db.query(
                        "challenge_claims",
                        new String[]{
                                "claim_id"
                        },
                        "user_id = ? " +
                                "AND challenge_type = ? " +
                                "AND challenge_key = ? " +
                                "AND period = ?",
                        new String[]{
                                String.valueOf(userId),
                                type,
                                key,
                                period
                        },
                        null,
                        null,
                        null
                );


        boolean claimed =
                cursor.moveToFirst();


        cursor.close();

        return claimed;
    }


    // ==========================================
    // CLAIM REWARD
    // ==========================================

    private void claimReward(
            String type,
            String key,
            int reward) {

        String period =
                "DAILY".equals(type)
                        ? getTodayDate()
                        : getWeekStartDate();


        if (isClaimed(
                type,
                key,
                period
        )) {

            Toast.makeText(
                    this,
                    "Reward already claimed!",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }


        db.beginTransaction();

        try {

            db.execSQL(
                    "UPDATE users " +
                            "SET coins = coins + ? " +
                            "WHERE user_id = ?",
                    new String[]{
                            String.valueOf(reward),
                            String.valueOf(userId)
                    }
            );


            ContentValues values =
                    new ContentValues();

            values.put(
                    "user_id",
                    userId
            );

            values.put(
                    "challenge_type",
                    type
            );

            values.put(
                    "challenge_key",
                    key
            );

            values.put(
                    "period",
                    period
            );

            values.put(
                    "claimed_date",
                    getTodayDate()
            );

            values.put(
                    "reward",
                    reward
            );


            long result =
                    db.insert(
                            "challenge_claims",
                            null,
                            values
                    );


            if (result == -1) {

                throw new Exception(
                        "Claim insert failed"
                );
            }


            db.setTransactionSuccessful();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Could not claim reward.",
                    Toast.LENGTH_SHORT
            ).show();

            return;

        } finally {

            db.endTransaction();
        }


        Toast.makeText(
                this,
                "🪙 +" +
                        reward +
                        " Coins earned!",
                Toast.LENGTH_SHORT
        ).show();


        loadChallenges();
    }


    // ==========================================
    // DATE CHECK
    // ==========================================

    private boolean isDateInRange(
            String date,
            String start,
            String end) {

        if (
                date == null ||
                        date.trim().isEmpty()
        ) {

            return false;
        }


        try {

            SimpleDateFormat format =
                    new SimpleDateFormat(
                            DATE_FORMAT,
                            Locale.getDefault()
                    );

            format.setLenient(false);


            Calendar target =
                    Calendar.getInstance();

            Calendar startCalendar =
                    Calendar.getInstance();

            Calendar endCalendar =
                    Calendar.getInstance();


            target.setTime(
                    format.parse(date)
            );

            startCalendar.setTime(
                    format.parse(start)
            );

            endCalendar.setTime(
                    format.parse(end)
            );


            clearTime(target);

            clearTime(startCalendar);

            clearTime(endCalendar);


            return !target.before(startCalendar)
                    &&
                    !target.after(endCalendar);

        } catch (Exception e) {

            return false;
        }
    }


    // ==========================================
    // TODAY
    // ==========================================

    private String getTodayDate() {

        return new SimpleDateFormat(
                DATE_FORMAT,
                Locale.getDefault()
        ).format(
                Calendar.getInstance().getTime()
        );
    }


    // ==========================================
    // WEEK START - MONDAY
    // ==========================================

    private String getWeekStartDate() {

        Calendar calendar =
                Calendar.getInstance();

        calendar.set(
                Calendar.DAY_OF_WEEK,
                Calendar.MONDAY
        );

        return new SimpleDateFormat(
                DATE_FORMAT,
                Locale.getDefault()
        ).format(
                calendar.getTime()
        );
    }


    // ==========================================
    // WEEK END - SUNDAY
    // ==========================================

    private String getWeekEndDate() {

        Calendar calendar =
                Calendar.getInstance();

        calendar.set(
                Calendar.DAY_OF_WEEK,
                Calendar.MONDAY
        );

        calendar.add(
                Calendar.DAY_OF_YEAR,
                6
        );

        return new SimpleDateFormat(
                DATE_FORMAT,
                Locale.getDefault()
        ).format(
                calendar.getTime()
        );
    }


    // ==========================================
    // CLEAR TIME
    // ==========================================

    private void clearTime(
            Calendar calendar) {

        calendar.set(
                Calendar.HOUR_OF_DAY,
                0
        );

        calendar.set(
                Calendar.MINUTE,
                0
        );

        calendar.set(
                Calendar.SECOND,
                0
        );

        calendar.set(
                Calendar.MILLISECOND,
                0
        );
    }


    @Override
    protected void onResume() {

        super.onResume();

        if (
                db != null &&
                        userId != -1
        ) {

            loadChallenges();
        }
    }


    @Override
    protected void onDestroy() {

        super.onDestroy();

        if (db != null) {

            db.close();
        }

        if (dbHelper != null) {

            dbHelper.close();
        }
    }
}
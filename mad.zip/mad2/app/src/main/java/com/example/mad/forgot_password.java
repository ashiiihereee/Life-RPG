package com.example.mad;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class forgot_password extends AppCompatActivity {

    private EditText edtEmail;
    private EditText edtNewPassword;
    private EditText edtConfirmPassword;

    private Button btnResetPassword;
    private TextView txtBackLogin;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_forgot_password
        );

        dbHelper =
                new DatabaseHelper(this);

        db =
                dbHelper.getWritableDatabase();

        edtEmail =
                findViewById(
                        R.id.edtResetEmail
                );

        edtNewPassword =
                findViewById(
                        R.id.edtNewPassword
                );

        edtConfirmPassword =
                findViewById(
                        R.id.edtConfirmPassword
                );

        btnResetPassword =
                findViewById(
                        R.id.btnResetPassword
                );

        txtBackLogin =
                findViewById(
                        R.id.txtBackLogin
                );

        styleInput(edtEmail);
        styleInput(edtNewPassword);
        styleInput(edtConfirmPassword);

        String emailFromLogin =
                getIntent().getStringExtra(
                        "EMAIL"
                );

        if (emailFromLogin != null &&
                !emailFromLogin.trim().isEmpty()) {

            edtEmail.setText(
                    emailFromLogin
            );
        }

        btnResetPassword.setOnClickListener(
                v -> resetPassword()
        );

        txtBackLogin.setOnClickListener(
                v -> finish()
        );
    }

    private void resetPassword() {

        String email =
                edtEmail.getText()
                        .toString()
                        .trim();

        String newPassword =
                edtNewPassword.getText()
                        .toString()
                        .trim();

        String confirmPassword =
                edtConfirmPassword.getText()
                        .toString()
                        .trim();

        if (TextUtils.isEmpty(email)) {

            edtEmail.setError(
                    "Enter your email"
            );

            edtEmail.requestFocus();

            return;
        }

        if (!Patterns.EMAIL_ADDRESS
                .matcher(email)
                .matches()) {

            edtEmail.setError(
                    "Enter a valid email"
            );

            edtEmail.requestFocus();

            return;
        }

        if (TextUtils.isEmpty(newPassword)) {

            edtNewPassword.setError(
                    "Enter a new password"
            );

            edtNewPassword.requestFocus();

            return;
        }

        if (TextUtils.isEmpty(confirmPassword)) {

            edtConfirmPassword.setError(
                    "Confirm your new password"
            );

            edtConfirmPassword.requestFocus();

            return;
        }

        if (!newPassword.equals(confirmPassword)) {

            edtConfirmPassword.setError(
                    "Passwords do not match"
            );

            edtConfirmPassword.requestFocus();

            Toast.makeText(
                    this,
                    "Passwords do not match",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        Cursor cursor =
                db.query(
                        "users",
                        new String[]{
                                "user_id"
                        },
                        "email = ?",
                        new String[]{
                                email
                        },
                        null,
                        null,
                        null
                );

        if (!cursor.moveToFirst()) {

            cursor.close();

            Toast.makeText(
                    this,
                    "No account found with this email",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        long userId =
                cursor.getLong(
                        cursor.getColumnIndexOrThrow(
                                "user_id"
                        )
                );

        cursor.close();

        ContentValues values =
                new ContentValues();

        values.put(
                "password",
                newPassword
        );

        int rowsUpdated =
                db.update(
                        "users",
                        values,
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        if (rowsUpdated > 0) {

            getSharedPreferences(
                    "LifeRPGSession",
                    MODE_PRIVATE
            )
                    .edit()
                    .clear()
                    .apply();

            Toast.makeText(
                    this,
                    "Password updated successfully!",
                    Toast.LENGTH_LONG
            ).show();

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Password update failed",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void styleInput(
            EditText editText) {

        GradientDrawable normalBorder =
                new GradientDrawable();

        normalBorder.setColor(
                Color.TRANSPARENT
        );

        normalBorder.setCornerRadius(
                18
        );

        normalBorder.setStroke(
                2,
                Color.parseColor(
                        "#5B4B7A"
                )
        );

        editText.setBackground(
                normalBorder
        );

        editText.setOnFocusChangeListener(
                (v, hasFocus) -> {

                    GradientDrawable border =
                            new GradientDrawable();

                    border.setColor(
                            Color.TRANSPARENT
                    );

                    border.setCornerRadius(
                            18
                    );

                    if (hasFocus) {

                        border.setStroke(
                                3,
                                Color.parseColor(
                                        "#A78BFA"
                                )
                        );

                    } else {

                        border.setStroke(
                                2,
                                Color.parseColor(
                                        "#5B4B7A"
                                )
                        );
                    }

                    editText.setBackground(
                            border
                    );
                }
        );
    }
}
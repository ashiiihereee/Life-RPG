package com.example.mad;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.core.app.NotificationCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class NotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        NotificationHelper.createNotificationChannel(context);

        String notificationType =
                intent.getStringExtra("notification_type");

        if ("QUEST".equals(notificationType)) {

            handleQuestNotification(
                    context,
                    intent
            );

            return;
        }

        if ("QUEST_DEADLINE".equals(notificationType)) {

            handleQuestDeadline(
                    context,
                    intent
            );

            return;
        }

        handleNormalNotification(
                context,
                intent
        );
    }

    // ==========================================
    // NORMAL NOTIFICATION
    // ==========================================

    private void handleNormalNotification(
            Context context,
            Intent intent) {

        String title =
                intent.getStringExtra("title");

        String message =
                intent.getStringExtra("message");

        if (title == null || title.isEmpty()) {

            title = "Life RPG";
        }

        if (message == null || message.isEmpty()) {

            message =
                    "You have a quest waiting for you!";
        }

        showNotification(
                context,
                title,
                message
        );
    }

    // ==========================================
    // QUEST NOTIFICATION
    // ==========================================

    private void handleQuestNotification(
            Context context,
            Intent intent) {

        long userId =
                intent.getLongExtra(
                        "USER_ID",
                        -1
                );

        long questId =
                intent.getLongExtra(
                        "QUEST_ID",
                        -1
                );

        String reminderType =
                intent.getStringExtra(
                        "REMINDER_TYPE"
                );

        if (
                userId == -1 ||
                        questId == -1 ||
                        reminderType == null
        ) {
            return;
        }

        DatabaseHelper dbHelper =
                new DatabaseHelper(context);

        SQLiteDatabase db =
                dbHelper.getReadableDatabase();

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "title",
                                "xp",
                                "deadline",
                                "status"
                        },
                        "quest_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(questId),
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (!cursor.moveToFirst()) {

            cursor.close();
            db.close();

            return;
        }

        String title =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "title"
                        )
                );

        int xp =
                cursor.getInt(
                        cursor.getColumnIndexOrThrow(
                                "xp"
                        )
                );

        String deadline =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "deadline"
                        )
                );

        String status =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "status"
                        )
                );

        cursor.close();

        // ==========================================
        // COMPLETED OR MISSED QUEST
        // ==========================================

        if (
                "Completed".equalsIgnoreCase(status)
                        ||
                        "Missed".equalsIgnoreCase(status)
        ) {

            cancelQuestNotifications(
                    context,
                    questId
            );

            db.close();

            return;
        }

        // ==========================================
        // CHECK DEADLINE
        // ==========================================

        Calendar today =
                Calendar.getInstance();

        Calendar deadlineCalendar =
                parseDeadline(
                        deadline
                );

        if (deadlineCalendar == null) {

            db.close();

            return;
        }

        clearTime(today);
        clearTime(deadlineCalendar);

        if (
                today.after(
                        deadlineCalendar
                )
        ) {

            cancelQuestNotifications(
                    context,
                    questId
            );

            db.close();

            return;
        }

        // ==========================================
        // GET PLAYER STREAK
        // ==========================================

        int currentStreak =
                getCurrentStreak(
                        db,
                        userId
                );

        // ==========================================
        // BUILD MESSAGE
        // ==========================================

        String notificationTitle =
                "⚔️ Quest Reminder";

        String notificationMessage;

        boolean deadlineToday =
                isSameDate(
                        today,
                        deadlineCalendar
                );

        if (deadlineToday) {

            notificationTitle =
                    "🚨 Quest Deadline!";

            String[] messages = {

                    "\"" + title +
                            "\" is due today! Earn " +
                            xp +
                            " XP by completing it.",

                    "Your quest \"" +
                            title +
                            "\" expires today. Time to earn " +
                            xp +
                            " XP!",

                    "⚔️ Final day! Complete \"" +
                            title +
                            "\" and claim " +
                            xp +
                            " XP."

            };

            notificationMessage =
                    messages[
                            new Random().nextInt(
                                    messages.length
                            )
                            ];

        } else if (
                currentStreak >= 3
        ) {

            String[] messages = {

                    "🔥 " +
                            currentStreak +
                            "-day streak! Don't break it. Complete \"" +
                            title +
                            "\" for " +
                            xp +
                            " XP.",

                    "🔥 Your streak is alive! \"" +
                            title +
                            "\" is waiting for you.",

                    "⚔️ Keep the streak going! Complete \"" +
                            title +
                            "\" and earn " +
                            xp +
                            " XP."

            };

            notificationMessage =
                    messages[
                            new Random().nextInt(
                                    messages.length
                            )
                            ];

        } else {

            String[] messages = {

                    "⚔️ \"" +
                            title +
                            "\" is waiting for you. Complete it to earn " +
                            xp +
                            " XP.",

                    "💪 One quest at a time. Complete \"" +
                            title +
                            "\" and level up.",

                    "🎮 Your next XP is waiting. Complete \"" +
                            title +
                            "\".",

                    "🔥 Don't let your quest sit there! \"" +
                            title +
                            "\" is waiting."

            };

            notificationMessage =
                    messages[
                            new Random().nextInt(
                                    messages.length
                            )
                            ];
        }

        showNotification(
                context,
                notificationTitle,
                notificationMessage
        );

        db.close();

        // ==========================================
        // SCHEDULE NEXT REMINDER
        // ==========================================

        scheduleNextQuestReminder(
                context,
                userId,
                questId,
                title,
                deadline,
                xp,
                reminderType
        );
    }

    // ==========================================
    // QUEST DEADLINE
    // ==========================================

    private void handleQuestDeadline(
            Context context,
            Intent intent) {

        long userId =
                intent.getLongExtra(
                        "USER_ID",
                        -1
                );

        long questId =
                intent.getLongExtra(
                        "QUEST_ID",
                        -1
                );

        if (
                userId == -1 ||
                        questId == -1
        ) {
            return;
        }

        DatabaseHelper dbHelper =
                new DatabaseHelper(context);

        SQLiteDatabase db =
                dbHelper.getWritableDatabase();

        Cursor cursor =
                db.query(
                        "quests",
                        new String[]{
                                "title",
                                "difficulty",
                                "status"
                        },
                        "quest_id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(questId),
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        if (!cursor.moveToFirst()) {

            cursor.close();
            db.close();

            return;
        }

        String title =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "title"
                        )
                );

        String difficulty =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "difficulty"
                        )
                );

        String status =
                cursor.getString(
                        cursor.getColumnIndexOrThrow(
                                "status"
                        )
                );

        cursor.close();

        // ==========================================
        // ALREADY COMPLETED
        // ==========================================

        if ("Completed".equalsIgnoreCase(status)) {

            cancelQuestNotifications(
                    context,
                    questId
            );

            cancelQuestDeadlineCheck(
                    context,
                    questId
            );

            db.close();

            return;
        }

        // ==========================================
        // ALREADY MISSED
        // ==========================================

        if ("Missed".equalsIgnoreCase(status)) {

            cancelQuestNotifications(
                    context,
                    questId
            );

            cancelQuestDeadlineCheck(
                    context,
                    questId
            );

            db.close();

            return;
        }

        // ==========================================
        // CALCULATE PENALTY
        // ==========================================

        int penalty = 0;

        if ("Easy".equalsIgnoreCase(difficulty)) {

            penalty = 5;

        } else if ("Medium".equalsIgnoreCase(difficulty)) {

            penalty = 10;

        } else if ("Hard".equalsIgnoreCase(difficulty)) {

            penalty = 15;

        } else if ("Epic".equalsIgnoreCase(difficulty)) {

            penalty = 20;
        }

        // ==========================================
        // MARK QUEST MISSED
        // ==========================================

        ContentValues values =
                new ContentValues();

        values.put(
                "status",
                "Missed"
        );

        int rowsUpdated =
                db.update(
                        "quests",
                        values,
                        "quest_id = ? AND user_id = ? " +
                                "AND status != 'Completed' " +
                                "AND status != 'Missed'",
                        new String[]{
                                String.valueOf(questId),
                                String.valueOf(userId)
                        }
                );

        // ==========================================
        // APPLY PENALTY ONLY ON FIRST MISS
        // ==========================================

        if (rowsUpdated > 0 && penalty > 0) {

            db.execSQL(
                    "UPDATE users " +
                            "SET coins = CASE " +
                            "WHEN coins >= ? THEN coins - ? " +
                            "ELSE 0 END " +
                            "WHERE user_id = ?",
                    new String[]{
                            String.valueOf(penalty),
                            String.valueOf(penalty),
                            String.valueOf(userId)
                    }
            );
        }

        db.close();

        // ==========================================
        // CANCEL ALL QUEST ALARMS
        // ==========================================

        cancelQuestNotifications(
                context,
                questId
        );

        cancelQuestDeadlineCheck(
                context,
                questId
        );

        // ==========================================
        // QUEST MISSED NOTIFICATION
        // ==========================================

        if (rowsUpdated > 0) {

            String notificationMessage;

            if (penalty > 0) {

                notificationMessage =
                        "\"" +
                                title +
                                "\" was missed. " +
                                penalty +
                                " coins were deducted.";

            } else {

                notificationMessage =
                        "\"" +
                                title +
                                "\" was missed.";
            }

            showNotification(
                    context,
                    "❌ Quest Missed",
                    notificationMessage
            );
        }
    }

    // ==========================================
    // SHOW NOTIFICATION
    // ==========================================

    private void showNotification(
            Context context,
            String title,
            String message) {

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(
                        context,
                        NotificationHelper.CHANNEL_ID
                )
                        .setSmallIcon(
                                android.R.drawable.ic_dialog_info
                        )
                        .setContentTitle(
                                title
                        )
                        .setContentText(
                                message
                        )
                        .setPriority(
                                NotificationCompat.PRIORITY_HIGH
                        )
                        .setAutoCancel(
                                true
                        )
                        .setVibrate(
                                new long[]{
                                        0,
                                        500,
                                        200,
                                        500
                                }
                        );

        NotificationManager manager =
                (NotificationManager)
                        context.getSystemService(
                                Context.NOTIFICATION_SERVICE
                        );

        if (manager != null) {

            int notificationId =
                    (int)
                            System.currentTimeMillis();

            manager.notify(
                    notificationId,
                    builder.build()
            );
        }
    }

    // ==========================================
    // SCHEDULE NEXT QUEST REMINDER
    // ==========================================

    private void scheduleNextQuestReminder(
            Context context,
            long userId,
            long questId,
            String title,
            String deadline,
            int xp,
            String reminderType) {

        Calendar next =
                Calendar.getInstance();

        if ("MORNING".equals(reminderType)) {

            next.add(
                    Calendar.DAY_OF_MONTH,
                    1
            );

            next.set(
                    Calendar.HOUR_OF_DAY,
                    9
            );

            next.set(
                    Calendar.MINUTE,
                    0
            );

            next.set(
                    Calendar.SECOND,
                    0
            );

            next.set(
                    Calendar.MILLISECOND,
                    0
            );

        } else {

            next.add(
                    Calendar.DAY_OF_MONTH,
                    1
            );

            next.set(
                    Calendar.HOUR_OF_DAY,
                    18
            );

            next.set(
                    Calendar.MINUTE,
                    0
            );

            next.set(
                    Calendar.SECOND,
                    0
            );

            next.set(
                    Calendar.MILLISECOND,
                    0
            );
        }

        Calendar deadlineCalendar =
                parseDeadline(
                        deadline
                );

        if (deadlineCalendar == null) {
            return;
        }

        clearTime(
                deadlineCalendar
        );

        Calendar nextDate =
                Calendar.getInstance();

        nextDate.setTimeInMillis(
                next.getTimeInMillis()
        );

        clearTime(
                nextDate
        );

        if (
                nextDate.after(
                        deadlineCalendar
                )
        ) {
            return;
        }

        scheduleQuestAlarm(
                context,
                userId,
                questId,
                title,
                deadline,
                xp,
                reminderType,
                next.getTimeInMillis()
        );
    }

    // ==========================================
    // SCHEDULE QUEST ALARM
    // ==========================================

    private void scheduleQuestAlarm(
            Context context,
            long userId,
            long questId,
            String title,
            String deadline,
            int xp,
            String reminderType,
            long triggerTime) {

        AlarmManager alarmManager =
                (AlarmManager)
                        context.getSystemService(
                                Context.ALARM_SERVICE
                        );

        if (alarmManager == null) {
            return;
        }

        Intent intent =
                new Intent(
                        context,
                        NotificationReceiver.class
                );

        intent.putExtra(
                "notification_type",
                "QUEST"
        );

        intent.putExtra(
                "USER_ID",
                userId
        );

        intent.putExtra(
                "QUEST_ID",
                questId
        );

        intent.putExtra(
                "title",
                title
        );

        intent.putExtra(
                "deadline",
                deadline
        );

        intent.putExtra(
                "xp",
                xp
        );

        intent.putExtra(
                "REMINDER_TYPE",
                reminderType
        );

        int notificationId =
                getQuestNotificationId(
                        questId,
                        reminderType
                );

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        context,
                        notificationId,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT
                                |
                                PendingIntent.FLAG_IMMUTABLE
                );

        if (
                android.os.Build.VERSION.SDK_INT >=
                        android.os.Build.VERSION_CODES.S
        ) {

            if (
                    alarmManager.canScheduleExactAlarms()
            ) {

                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                );

            } else {

                alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                );
            }

        } else {

            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
            );
        }
    }

    // ==========================================
    // CANCEL QUEST NOTIFICATIONS
    // ==========================================

    private void cancelQuestNotifications(
            Context context,
            long questId) {

        AlarmManager alarmManager =
                (AlarmManager)
                        context.getSystemService(
                                Context.ALARM_SERVICE
                        );

        if (alarmManager == null) {
            return;
        }

        cancelQuestAlarm(
                context,
                alarmManager,
                questId,
                "MORNING"
        );

        cancelQuestAlarm(
                context,
                alarmManager,
                questId,
                "EVENING"
        );
    }

    private void cancelQuestAlarm(
            Context context,
            AlarmManager alarmManager,
            long questId,
            String reminderType) {

        int notificationId =
                getQuestNotificationId(
                        questId,
                        reminderType
                );

        Intent intent =
                new Intent(
                        context,
                        NotificationReceiver.class
                );

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        context,
                        notificationId,
                        intent,
                        PendingIntent.FLAG_NO_CREATE
                                |
                                PendingIntent.FLAG_IMMUTABLE
                );

        if (pendingIntent != null) {

            alarmManager.cancel(
                    pendingIntent
            );

            pendingIntent.cancel();
        }
    }

    // ==========================================
    // CANCEL DEADLINE CHECK
    // ==========================================

    private void cancelQuestDeadlineCheck(
            Context context,
            long questId) {

        AlarmManager alarmManager =
                (AlarmManager)
                        context.getSystemService(
                                Context.ALARM_SERVICE
                        );

        if (alarmManager == null) {
            return;
        }

        int notificationId =
                getQuestDeadlineNotificationId(
                        questId
                );

        Intent intent =
                new Intent(
                        context,
                        NotificationReceiver.class
                );

        PendingIntent pendingIntent =
                PendingIntent.getBroadcast(
                        context,
                        notificationId,
                        intent,
                        PendingIntent.FLAG_NO_CREATE
                                |
                                PendingIntent.FLAG_IMMUTABLE
                );

        if (pendingIntent != null) {

            alarmManager.cancel(
                    pendingIntent
            );

            pendingIntent.cancel();
        }
    }

    // ==========================================
    // GET STREAK
    // ==========================================

    private int getCurrentStreak(
            SQLiteDatabase db,
            long userId) {

        Cursor cursor =
                db.query(
                        "streaks",
                        new String[]{
                                "current_streak"
                        },
                        "user_id = ?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        int streak = 0;

        if (cursor.moveToFirst()) {

            streak =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    "current_streak"
                            )
                    );
        }

        cursor.close();

        return streak;
    }

    // ==========================================
    // PARSE DEADLINE
    // ==========================================

    private Calendar parseDeadline(
            String deadline) {

        try {

            SimpleDateFormat format =
                    new SimpleDateFormat(
                            "dd / MM / yyyy",
                            Locale.getDefault()
                    );

            format.setLenient(false);

            Date date =
                    format.parse(
                            deadline
                    );

            if (date == null) {
                return null;
            }

            Calendar calendar =
                    Calendar.getInstance();

            calendar.setTime(
                    date
            );

            return calendar;

        } catch (Exception e) {

            return null;
        }
    }

    // ==========================================
    // CLEAR TIME
    // ==========================================

    private void clearTime(
            Calendar calendar) {

        calendar.set(
                Calendar.HOUR_OF_DAY,
                0
        );

        calendar.set(
                Calendar.MINUTE,
                0
        );

        calendar.set(
                Calendar.SECOND,
                0
        );

        calendar.set(
                Calendar.MILLISECOND,
                0
        );
    }

    // ==========================================
    // SAME DATE
    // ==========================================

    private boolean isSameDate(
            Calendar first,
            Calendar second) {

        return first.get(
                Calendar.YEAR
        ) == second.get(
                Calendar.YEAR
        )
                &&
                first.get(
                        Calendar.DAY_OF_YEAR
                ) == second.get(
                        Calendar.DAY_OF_YEAR
                );
    }

    // ==========================================
    // NOTIFICATION ID
    // ==========================================

    private int getQuestNotificationId(
            long questId,
            String reminderType) {

        int type;

        if ("MORNING".equals(reminderType)) {

            type = 1;

        } else {

            type = 2;
        }

        return (int)
                (
                        (questId * 10)
                                + type
                );
    }

    // ==========================================
    // DEADLINE NOTIFICATION ID
    // ==========================================

    private int getQuestDeadlineNotificationId(
            long questId) {

        return (int)
                (
                        (questId * 10)
                                + 3
                );
    }
}